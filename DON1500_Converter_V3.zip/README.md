# DON-1500 Converter v3.0

Android-додаток (Kotlin + Jetpack Compose) для підготовки модів/карт FS25 до FS26 Mobile.

## Збірка (GitHub Actions)
1. Створіть репозиторій на GitHub, завантажте ВСЕ з цього архіву (включно з папкою `.github`).
2. Вкладка **Actions → Build APK → Run workflow**.
3. Після завершення: внизу сторінки запуску **Artifacts → DON1500-Converter-debug-apk**.
4. Якщо збірка червона — скопіюйте текст помилки й надішліть Claude.
