@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale

private val ACTION_RE = Regex("(?m)^[ \\t]*ACTION:[ \\t]*(\\{.*\\})[ \\t]*$")
private fun stripActions(t: String) = ACTION_RE.replace(t, "").trimEnd()
private fun speakable(t: String) = stripActions(t).replace(Regex("(?s)```.*?```"), ".").replace(Regex("[*#`_]"), "")
private const val PATCH_HELP = "When the user attached a file (XML/i3D/Lua) you only receive an automatic local analysis (structure, errors, line snippets), not the whole file. Explain the problems briefly. To fix them output replacements, one block per change, exactly in this form: ```patch\nFIND: <exact single-line text fragment copied from a snippet>\nREPLACE: <new text>\n``` . FIND must occur verbatim on one line of the file. The user taps a button to apply them (a backup is created)."
private val SCREENS = setOf("files", "apk", "donors", "converter", "editor", "textures", "images", "errors", "results", "settings")

private fun actionLabel(json: String): String = try {
    val o = JSONObject(json)
    when (o.optString("do")) {
        "open" -> tr("Відкрити: ", "Открыть: ") + o.optString("screen")
        "analyze" -> tr("Аналіз", "Анализ")
        "convert" -> tr("Конвертувати", "Конвертировать")
        "texsize" -> tr("Розмір текстур: ", "Размер текстур: ") + o.optInt("value")
        "target" -> tr("Ціль: ", "Цель: ") + o.optString("value")
        else -> "?"
    }
} catch (e: Exception) { "?" }

@Composable
fun AiScreen(store: Store, onNav: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val profiles = remember { store.profiles() }
    var activeId by remember { mutableStateOf(store.activeProfile.ifEmpty { profiles.firstOrNull()?.id ?: "" }) }
    val prof = profiles.firstOrNull { it.id == activeId } ?: profiles.firstOrNull()
    var menu by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var attachReport by remember { mutableStateOf(false) }
    var attachFile by remember { mutableStateOf(false) }
    var speakAuto by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var pendingText by remember { mutableStateOf<String?>(null) }
    var imgDlg by remember { mutableStateOf(false) }
    var imgPrompt by remember { mutableStateOf("") }
    var imgModel by remember { mutableStateOf("") }
    var imgSize by remember { mutableStateOf(1024) }
    var imgFmt by remember { mutableStateOf("PNG") }
    val listState = rememberLazyListState()
    val tts = remember { arrayOfNulls<TextToSpeech>(1) }
    var ttsReady by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        tts[0] = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) { tts[0]?.setLanguage(Locale(if (Lang.uk) "uk" else "ru")); ttsReady = true }
        }
        onDispose { tts[0]?.stop(); tts[0]?.shutdown() }
    }
    fun speak(t: String) { if (ttsReady) tts[0]?.speak(speakable(t).take(3500), TextToSpeech.QUEUE_FLUSH, null, "ai") }

    fun system(): String {
        val r = Session.report
        val st = "App state: source=" + (Session.sourceFile?.name ?: "none") + "; target=" + store.target + "; textureLimit=" + store.maxTex +
            "; donorsFS26=" + DonorLib.list(ctx, "FS26").size + "; donorsFS23=" + DonorLib.list(ctx, "FS23").size +
            (if (r != null) "; lastReport: errors=${r.errors}, missing=${r.missing.size}, warnings=${r.warnings}" else "")
        return Ai.SYSTEM_CHAT + "\n" + PATCH_HELP + "\n" + st
    }

    fun doSend(text: String, withAttach: Boolean) {
        val p = prof ?: return
        if (busy) return
        var api = text
        var shown = text
        if (withAttach) {
            val sb = StringBuilder()
            if (attachReport && Session.reportText.isNotEmpty()) { sb.append("REPORT:\n").append(Session.reportText.take(12000)).append("\n\n"); shown += "\n📎 " + tr("звіт", "отчёт") }
            if (attachFile && Session.aiAttach.isNotEmpty()) { sb.append(Session.aiAttach.take(30000)).append("\n\n"); shown += "\n📎 " + Session.aiAttach.lineSequence().first().take(40) }
            api = sb.toString() + text
        }
        Session.chat.add(ChatMsg("user", shown, api))
        val idx = Session.chat.size
        Session.chat.add(ChatMsg("assistant", ""))
        val hist = Session.chat.take(idx).takeLast(12).map { it.role to it.api.take(40000) }
        val sys = system()
        busy = true; note = ""
        scope.launch {
            val sb = StringBuilder()
            val err = withContext(Dispatchers.IO) {
                try {
                    val m = Ai.chatStream(p.provider, p.key, p.model, sys, hist, p.baseUrl) { d -> sb.append(d); Session.chat[idx] = ChatMsg("assistant", sb.toString()) }
                    note = tr("Модель: ", "Модель: ") + m
                    null
                } catch (e: Exception) { e.message ?: "error" }
            }
            if (err != null) Session.chat[idx] = ChatMsg("assistant", (if (sb.isNotEmpty()) sb.toString() + "\n\n" else "") + "✖ " + err)
            busy = false
            if (err == null && speakAuto) speak(sb.toString())
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy || prof == null) return
        input = ""
        if ((attachReport && Session.reportText.isNotEmpty()) || (attachFile && Session.aiAttach.isNotEmpty())) pendingText = t else doSend(t, false)
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) send(t)
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; note = tr("Аналізую файл…", "Анализирую файл…")
            note = withContext(Dispatchers.IO) {
                try {
                    val dest = File(Fs.work(ctx), Fs.displayName(ctx, uri))
                    Fs.copyUri(ctx, uri, dest)
                    Session.aiFile = dest
                    Session.aiAttach = "FILE ${dest.name}:\n" + Insight.analyze(dest)
                    "✔ " + tr("Файл проаналізовано: ${dest.name} (${Fs.human(dest.length())}). Увімкнено 📎 — напишіть, що зробити.", "Файл проанализирован: ${dest.name} (${Fs.human(dest.length())}). Включено 📎 — напишите, что сделать.")
                } catch (e: Exception) { "✖ ${e.message}" }
            }
            attachFile = true; busy = false
        }
    }

    fun runAction(json: String) {
        try {
            val o = JSONObject(json)
            when (o.optString("do")) {
                "open" -> { val s = o.optString("screen"); if (s in SCREENS) onNav(s) else note = "✖ ?" }
                "analyze" -> { Session.pending = "analyze"; onNav("converter") }
                "convert" -> { Session.pending = "convert"; onNav("converter") }
                "texsize" -> { val v = o.optInt("value", 2048); if (v in setOf(0, 512, 1024, 2048, 4096)) { store.maxTex = v; note = "✔ " + tr("Розмір текстур: $v", "Размер текстур: $v") } }
                "target" -> { val v = o.optString("value"); if (v == "FS26" || v == "FS23") { store.target = v; note = "✔ " + tr("Ціль: $v", "Цель: $v") } }
                else -> note = "✖ ?"
            }
        } catch (e: Exception) { note = "✖ ${e.message}" }
    }

    val lastLen = Session.chat.lastOrNull()?.text?.length ?: 0
    LaunchedEffect(Session.chat.size, lastLen / 150) { if (Session.chat.isNotEmpty()) listState.scrollToItem(Session.chat.size - 1) }

    Frame(tr("AI-помічник", "AI-помощник"), onBack) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (prof == null) Text(tr("Немає ключа: Налаштування → AI-ключі → «+»", "Нет ключа: Настройки → AI-ключи → «+»"), Modifier.weight(1f), fontSize = 12.sp)
                else Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { menu = true }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("${prof.name} · ${prof.provider}", maxLines = 1, fontSize = 12.sp) }
                    DropdownMenu(menu, { menu = false }) {
                        profiles.forEach { p -> DropdownMenuItem(text = { Text("${p.name} · ${p.provider}") }, onClick = { activeId = p.id; store.activeProfile = p.id; menu = false }) }
                    }
                }
                IconButton(onClick = { speakAuto = !speakAuto }) { Icon(Icons.Filled.VolumeUp, null, tint = if (speakAuto) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
                IconButton(onClick = { Session.chat.clear(); note = "" }) { Icon(Icons.Filled.Delete, null) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(attachReport, { attachReport = !attachReport }, { Text(tr("📎 звіт", "📎 отчёт"), fontSize = 12.sp) })
                if (Session.aiAttach.isNotEmpty()) FilterChip(attachFile, { attachFile = !attachFile }, { Text("📎 " + Session.aiAttach.lineSequence().first().removePrefix("FILE ").take(22), fontSize = 12.sp) })
                AssistChip(onClick = { filePicker.launch(arrayOf("*/*")) }, label = { Text(tr("📎 файл XML/i3D…", "📎 файл XML/i3D…"), fontSize = 12.sp) })
                AssistChip(onClick = { imgDlg = true }, label = { Text(tr("🖼 створити картинку", "🖼 создать картинку"), fontSize = 12.sp) })
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), state = listState) {
                items(Session.chat.size) { i ->
                    val m = Session.chat[i]
                    val mine = m.role == "user"
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Card(Modifier.widthIn(max = 330.dp), colors = CardDefaults.cardColors(containerColor = if (mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(10.dp)) {
                                val shown = stripActions(m.text)
                                SelectionContainer { Text(if (shown.isEmpty() && !mine && busy && i == Session.chat.size - 1) "…" else shown, fontSize = 14.sp) }
                                if (!mine && m.text.isNotEmpty()) TextButton(onClick = { speak(m.text) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.height(28.dp)) { Text("🔊", fontSize = 14.sp) }
                            }
                        }
                    }
                }
            }
            val last = Session.chat.lastOrNull()
            if (last != null && last.role == "assistant" && !busy) {
                val acts = ACTION_RE.findAll(last.text).map { it.groupValues[1] }.toList()
                val patches = PatchTool.parse(last.text)
                val pf = Session.aiFile
                if (patches.isNotEmpty() && pf != null) Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Button(onClick = {
                        scope.launch {
                            busy = true
                            note = withContext(Dispatchers.IO) {
                                try {
                                    val r = PatchTool.apply(pf, patches)
                                    if (r.startsWith("✔")) { try { Fs.publish(ctx, pf, "text/plain", "ai_fixed") } catch (_: Exception) { } }
                                    r + (if (r.startsWith("✔")) "\n→ Download/DON1500/ai_fixed/${pf.name}" else "")
                                } catch (e: Exception) { "✖ ${e.message}" }
                            }
                            busy = false
                        }
                    }) { Text("🛠 " + tr("Застосувати виправлення (${patches.size})", "Применить исправления (${patches.size})"), fontSize = 12.sp) }
                }
                if (acts.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    acts.forEach { a -> Button(onClick = { runAction(a) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("▶ " + actionLabel(a), fontSize = 12.sp) } }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (note.isNotEmpty()) Text(note, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), maxLines = 5, placeholder = { Text(tr("Напишіть або надиктуйте…", "Напишите или надиктуйте…")) })
                IconButton(onClick = {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (Lang.uk) "uk-UA" else "ru-RU")
                    try { speech.launch(i) } catch (e: Exception) { note = "✖ " + tr("Розпізнавання мовлення недоступне на цьому пристрої", "Распознавание речи недоступно на этом устройстве") }
                }) { Icon(Icons.Filled.Mic, null) }
                IconButton(enabled = input.isNotBlank() && !busy && prof != null, onClick = { send(input) }) { Icon(Icons.Filled.Send, null, tint = MaterialTheme.colorScheme.primary) }
            }
        }
    }

    val pt = pendingText
    if (pt != null) AlertDialog(
        onDismissRequest = { pendingText = null },
        title = { Text(tr("Що буде передано до ${prof?.provider ?: "AI"}", "Что будет передано в ${prof?.provider ?: "AI"}")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                val preview = (if (attachReport && Session.reportText.isNotEmpty()) "REPORT:\n" + Session.reportText.take(1500) + "…\n\n" else "") +
                    (if (attachFile && Session.aiAttach.isNotEmpty()) Session.aiAttach.take(1500) + "…\n\n" else "") + pt
                Text(preview, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }
        },
        confirmButton = { TextButton(onClick = { pendingText = null; doSend(pt, true) }) { Text(tr("Дозволяю, надіслати", "Разрешаю, отправить")) } },
        dismissButton = { TextButton(onClick = { pendingText = null }) { Text(tr("Скасувати", "Отмена")) } }
    )

    if (imgDlg && prof != null) AlertDialog(
        onDismissRequest = { imgDlg = false },
        title = { Text(tr("Створити картинку (${prof.provider})", "Создать картинку (${prof.provider})")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(imgPrompt, { imgPrompt = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text(tr("Опис текстури/картинки", "Описание текстуры/картинки")) })
                OutlinedTextField(imgModel, { imgModel = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true, label = { Text(tr("Модель зображень (порожньо = типова)", "Модель изображений (пусто = типовая)")) })
                Row(Modifier.padding(top = 6.dp)) { listOf(512, 1024, 2048).forEach { s -> FilterChip(imgSize == s, { imgSize = s }, { Text("$s") }); Spacer(Modifier.width(4.dp)) } }
                Row { listOf("PNG", "DDS", "JPG").forEach { f -> FilterChip(imgFmt == f, { imgFmt = f }, { Text(f) }); Spacer(Modifier.width(4.dp)) } }
                Text(tr("На сервіс піде лише ваш опис. Результат — Download/DON1500/ai_images.", "На сервис уйдёт только ваше описание. Результат — Download/DON1500/ai_images."), fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = imgPrompt.isNotBlank(), onClick = {
                imgDlg = false
                scope.launch {
                    busy = true
                    val res = withContext(Dispatchers.IO) {
                        try {
                            val raw = Ai.image(prof.provider, prof.key, imgModel.trim(), prof.baseUrl, imgPrompt)
                            val img = ImageTools.load(raw, "x.png") ?: throw java.io.IOException(tr("Не вдалося прочитати створене зображення", "Не удалось прочитать созданное изображение"))
                            val out = ImageTools.encode(ImageTools.resize(img, imgSize, true), imgFmt)
                            val f = File(Fs.work(ctx), "ai_image_" + (System.currentTimeMillis() / 1000) + "." + imgFmt.lowercase())
                            f.writeBytes(out)
                            "✔ " + Fs.publish(ctx, f, "application/octet-stream", "ai_images")
                        } catch (e: Throwable) { "✖ ${e.message}" }
                    }
                    Session.chat.add(ChatMsg("assistant", res))
                    busy = false
                }
            }) { Text(tr("Створити", "Создать")) }
        },
        dismissButton = { TextButton(onClick = { imgDlg = false }) { Text(tr("Скасувати", "Отмена")) } }
    )
}
