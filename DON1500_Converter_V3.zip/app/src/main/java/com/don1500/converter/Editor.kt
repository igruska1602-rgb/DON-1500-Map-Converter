@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xml.sax.InputSource
import org.xml.sax.SAXParseException
import java.io.File
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

private fun checkXml(s: String): String? = try {
    DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(s.removePrefix("\uFEFF")))); null
} catch (e: SAXParseException) { "${e.lineNumber}:${e.columnNumber} ${e.message}" } catch (e: Exception) { e.message ?: "XML error" }

@Composable
fun EditorScreen(initial: File?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var file by remember { mutableStateOf(initial) }
    var text by remember { mutableStateOf("") }
    var orig by remember { mutableStateOf("") }
    var find by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    fun load(f: File) {
        if (f.length() > 3_000_000) { msg = "✖ " + tr("Файл завеликий для редактора (> 3 MB)", "Файл слишком большой для редактора (> 3 MB)"); return }
        file = f; text = f.readText(); orig = text; msg = ""
    }
    LaunchedEffect(initial) { initial?.let { load(it) } }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val f = File(Fs.work(ctx), Fs.displayName(ctx, uri))
            withContext(Dispatchers.IO) { Fs.copyUri(ctx, uri, f) }
            load(f)
        }
    }
    Frame(tr("XML / i3D редактор", "XML / i3D редактор"), onBack) {
        Column(Modifier.padding(horizontal = 10.dp).fillMaxSize()) {
            Text(file?.absolutePath ?: tr("Файл не відкрито", "Файл не открыт"), fontSize = 11.sp, maxLines = 2)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(tr("Відкрити", "Открыть"), fontSize = 12.sp) }
                OutlinedButton(onClick = { msg = checkXml(text)?.let { "✖ $it" } ?: ("✔ " + tr("XML коректний", "XML корректен")) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(tr("Перевірити XML", "Проверить XML"), fontSize = 12.sp) }
                OutlinedButton(onClick = {
                    val f = file ?: return@OutlinedButton
                    var root: File? = f.parentFile; var k = 0
                    while (root != null && !File(root, "modDesc.xml").exists() && k < 6) { root = root.parentFile; k++ }
                    val base = if (root != null && File(root, "modDesc.xml").exists()) root else f.parentFile
                    val bad = Converter.refsIn(text, f.extension.equals("xml", true)).filter { r ->
                        val a = File(base, r); val b = File(f.parentFile, r)
                        !a.exists() && !b.exists() && !(r.endsWith(".png") && File(base, r.dropLast(4) + ".dds").exists())
                    }.distinct()
                    msg = if (bad.isEmpty()) "✔ " + tr("Усі посилання знайдено", "Все ссылки найдены") else "✖ " + tr("Відсутні (${bad.size}):\n", "Отсутствуют (${bad.size}):\n") + bad.take(40).joinToString("\n")
                }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(tr("Посилання", "Ссылки"), fontSize = 12.sp) }
                Button(onClick = {
                    val f = file ?: return@Button
                    try {
                        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        if (f.exists()) f.copyTo(File(f.parentFile, f.name + ".bak_$ts"), overwrite = true)
                        f.writeText(text); orig = text; msg = "✔ " + tr("Збережено (резервна копія .bak створена)", "Сохранено (резервная копия .bak создана)")
                    } catch (e: Exception) { msg = "✖ ${e.message}" }
                }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(tr("Зберегти", "Сохранить"), fontSize = 12.sp) }
                OutlinedButton(onClick = {
                    val f = file ?: return@OutlinedButton
                    scope.launch { msg = withContext(Dispatchers.IO) { try { val t = File(Fs.work(ctx), f.name); t.writeText(text); "✔ " + Fs.publish(ctx, t, "text/plain") } catch (e: Exception) { "✖ ${e.message}" } } }
                }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("→ Download", fontSize = 12.sp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(find, { find = it }, Modifier.weight(1f), singleLine = true, label = { Text(tr("Знайти", "Найти"), fontSize = 11.sp) })
                OutlinedTextField(repl, { repl = it }, Modifier.weight(1f), singleLine = true, label = { Text(tr("Замінити", "Заменить"), fontSize = 11.sp) })
                TextButton(onClick = {
                    if (find.isNotEmpty()) { val n = text.split(find).size - 1; text = text.replace(find, repl); msg = tr("Замін: $n", "Замен: $n") }
                }) { Text("OK") }
            }
            val changed = if (text == orig) 0 else text.lines().zip(orig.lines()).count { it.first != it.second } + kotlin.math.abs(text.lines().size - orig.lines().size)
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            Text(tr("Змінено рядків: $changed", "Изменено строк: $changed"), fontSize = 11.sp)
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().weight(1f).padding(top = 4.dp),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp))
        }
    }
}
