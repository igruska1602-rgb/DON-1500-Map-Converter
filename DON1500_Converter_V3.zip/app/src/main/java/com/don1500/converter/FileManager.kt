@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

class PaneState(start: File) {
    var dir by mutableStateOf(start)
    var sel by mutableStateOf(setOf<String>())
    var sort by mutableStateOf(0) // 0 ім'я, 1 розмір, 2 дата
}

private val TEXT_EXT = setOf("xml", "lua", "txt", "log", "json", "i3d", "md", "ini", "cfg", "properties", "gradle", "yml")

private fun iconFor(f: File): ImageVector = if (f.isDirectory) Icons.Filled.Folder else when (f.extension.lowercase()) {
    "zip", "rar", "7z" -> Icons.Filled.FolderZip
    "xml", "lua", "txt", "log", "json", "md" -> Icons.Filled.Description
    "i3d", "shapes" -> Icons.Filled.ViewInAr
    "png", "jpg", "jpeg", "dds", "webp" -> Icons.Filled.Image
    "apk" -> Icons.Filled.Android
    else -> Icons.Filled.InsertDriveFile
}

private fun openExternal(ctx: android.content.Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, f.name))
}

private fun dirSize(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

private fun sha(f: File): String {
    val md = MessageDigest.getInstance("SHA-256"); val b = ByteArray(1 shl 16)
    f.inputStream().use { i -> while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
    return md.digest().joinToString("") { "%02x".format(it) }
}

@Composable
fun PaneView(p: PaneState, active: Boolean, tick: Int, filter: String, mod: Modifier, onActivate: () -> Unit, onOpenFile: (File) -> Unit, onLongPress: (File) -> Unit, haptic: HapticFeedback) {
    val raw = remember(p.dir, tick) { p.dir.listFiles() }
    val rows = remember(raw, filter, p.sort) {
        (raw?.toList() ?: emptyList()).filter { filter.isBlank() || it.name.contains(filter, true) }
            .sortedWith(compareBy<File>({ !it.isDirectory }).thenComparator { a, b ->
                when (p.sort) { 1 -> b.length().compareTo(a.length()); 2 -> b.lastModified().compareTo(a.lastModified()); else -> a.name.compareTo(b.name, true) }
            })
    }
    val df = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US) }
    Column(mod.padding(3.dp).border(2.dp, if (active) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(10.dp)).clickable { onActivate() }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onActivate(); p.dir.parentFile?.let { p.dir = it; p.sel = emptySet() } }, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.ArrowUpward, null) }
            Text(p.dir.absolutePath, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { p.sort = (p.sort + 1) % 3 }, contentPadding = PaddingValues(4.dp)) { Text(listOf("A-Z", "Size", "Date")[p.sort], fontSize = 11.sp) }
        }
        if (raw == null) {
            InfoHint(tr("Ця папка закрита Android: починаючи з Android 11 сторонні програми не можуть відкривати Android/data та Android/obb (це обмеження системи, не помилка програми). Усі інші папки відкриваються після «Доступу до всіх файлів». Вміст гри можна взяти з APK через «Вибрати APK» → донор.",
                "Эта папка закрыта Android: начиная с Android 11 сторонние приложения не могут открывать Android/data и Android/obb (это ограничение системы, не ошибка программы). Остальные папки открываются после «Доступа ко всем файлам». Содержимое игры можно взять из APK через «Выбрать APK» → донор."), Modifier.padding(8.dp))
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(rows, key = { it.absolutePath }) { f ->
                val selected = f.absolutePath in p.sel
                Row(Modifier.fillMaxWidth().background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else Color.Transparent)
                    .combinedClickable(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onActivate()
                            if (f.isDirectory) { p.dir = f; p.sel = emptySet() } else onOpenFile(f)
                        },
                        onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onActivate(); onLongPress(f) }
                    ).padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(iconFor(f), null, tint = if (f.isDirectory) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        Text((if (f.isDirectory) tr("папка", "папка") else Fs.human(f.length())) + " · " + df.format(Date(f.lastModified())), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Checkbox(selected, { c -> onActivate(); p.sel = if (c) p.sel + f.absolutePath else p.sel - f.absolutePath })
                }
            }
        }
    }
}

@Composable
fun FileManagerScreen(onBack: () -> Unit, onConvert: (File) -> Unit, onEdit: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val root = remember { Environment.getExternalStorageDirectory() }
    val panes = remember { listOf(PaneState(root), PaneState(File(root, "Download"))) }
    var active by remember { mutableStateOf(0) }
    var tick by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var infoText by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    var zipTarget by remember { mutableStateOf<File?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var horizontalSplit by remember { mutableStateOf(true) }
    val hasAll = remember(tick) { Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager() }

    fun act() = panes[active]
    fun oth() = panes[1 - active]
    fun sel(): List<File> = act().sel.map { File(it) }.filter { it.exists() }

    fun runOp(label: String, block: () -> String) {
        scope.launch {
            busy = label
            note = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "✖ ${e.message}" } }
            busy = ""; panes.forEach { it.sel = emptySet() }; tick++
        }
    }
    fun showInfo(block: () -> String) {
        scope.launch { infoText = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "✖ ${e.message}" } }; dlg = "info" }
    }
    fun go(f: File) { act().dir = f; act().sel = emptySet(); tick++ }

    Frame(tr("Файловий менеджер", "Файловый менеджер"), onBack) {
        if (!hasAll) Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Потрібен «Доступ до всіх файлів», щоб бачити всі папки.", "Нужен «Доступ ко всем файлам», чтобы видеть все папки."), Modifier.weight(1f), fontSize = 12.sp)
                TextButton(onClick = {
                    try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }
                    catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                }) { Text(tr("Дати", "Дать")) }
                TextButton(onClick = { tick++ }) { Text(tr("Перевірити", "Проверить")) }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("/" to File("/"), "Root" to root, "Download" to File(root, "Download"), "Android/data" to File(root, "Android/data"), "Android/media" to File(root, "Android/media"), "Android/obb" to File(root, "Android/obb"))
                .forEach { (n, f) -> AssistChip(onClick = { go(f) }, label = { Text(n, fontSize = 11.sp) }) }
            AssistChip(onClick = { go(Fs.work(ctx)) }, label = { Text(tr("Робоча", "Рабочая"), fontSize = 11.sp) })
            AssistChip(onClick = { go(Fs.outDir(ctx)) }, label = { Text(tr("Результати", "Результаты"), fontSize = 11.sp) })
            ctx.getExternalFilesDirs(null).filterNotNull().map { File(it.absolutePath.substringBefore("/Android")) }.distinct().filter { it != root }
                .forEach { v -> AssistChip(onClick = { go(v) }, label = { Text(v.name.ifEmpty { "SD" }, fontSize = 11.sp) }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(filter, { filter = it }, Modifier.weight(1f).padding(horizontal = 6.dp), singleLine = true, placeholder = { Text(tr("Пошук у папці…", "Поиск в папке…"), fontSize = 12.sp) })
            IconButton(onClick = { horizontalSplit = !horizontalSplit }) { Icon(if (horizontalSplit) Icons.Filled.ViewAgenda else Icons.Filled.ViewColumn, null) }
        }
        fun onLong(i: Int, f: File) { active = i; panes[i].sel = setOf(f.absolutePath); menuOpen = true }
        val paneContent: @Composable (Modifier) -> Unit = { m ->
            for (i in 0..1) PaneView(panes[i], i == active, tick, filter, m, { active = i }, { f ->
                active = i
                val ext = f.extension.lowercase()
                when {
                    ext == "zip" -> { zipTarget = f; dlg = "zipmenu" }
                    ext in TEXT_EXT -> onEdit(f)
                    else -> { zipTarget = f; dlg = "openfile" }
                }
            }, { f -> onLong(i, f) }, haptic)
        }
        if (horizontalSplit) Row(Modifier.weight(1f)) { paneContent(Modifier.weight(1f)) }
        else Column(Modifier.weight(1f)) { paneContent(Modifier.weight(1f)) }
        if (busy.isNotEmpty()) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(busy, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp)) }
        if (note.isNotEmpty()) Text(note, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp), color = MaterialTheme.colorScheme.secondary)
        Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); input = ""; dlg = "mkdir" }) { Icon(Icons.Filled.CreateNewFolder, null) }
            Text(tr("Нова папка", "Новая папка"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            if (act().sel.isNotEmpty()) Text(tr("Вибрано: ${act().sel.size}", "Выбрано: ${act().sel.size}"), fontSize = 11.sp, modifier = Modifier.padding(end = 6.dp))
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, null) }
                DropdownMenu(menuOpen, { menuOpen = false }) {
            @Composable fun b(label: String, enabled: Boolean = true, onClick: () -> Unit) =
                DropdownMenuItem(text = { Text(label, fontSize = 13.sp) }, enabled = enabled && busy.isEmpty(), onClick = { menuOpen = false; haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() })
            val has = act().sel.isNotEmpty()
            val one = act().sel.size == 1
            b(tr("Копіювати →", "Копировать →"), has) {
                val l = sel(); val t = oth().dir
                runOp(tr("Копіювання…", "Копирование…")) {
                    var n = 0
                    for (f in l) {
                        if (f.isDirectory && t.canonicalPath.startsWith(f.canonicalPath)) continue
                        val d = Fs.uniqueFile(t, f.name); if (f.isDirectory) f.copyRecursively(d) else f.copyTo(d); n++
                    }
                    "✔ " + tr("Скопійовано: $n", "Скопировано: $n")
                }
            }
            b(tr("Перемістити →", "Переместить →"), has) {
                val l = sel(); val t = oth().dir
                runOp(tr("Переміщення…", "Перемещение…")) {
                    var n = 0
                    for (f in l) {
                        if (f.isDirectory && t.canonicalPath.startsWith(f.canonicalPath)) continue
                        val d = Fs.uniqueFile(t, f.name)
                        if (!f.renameTo(d)) { if (f.isDirectory) f.copyRecursively(d) else f.copyTo(d); f.deleteRecursively() }
                        n++
                    }
                    "✔ " + tr("Переміщено: $n", "Перемещено: $n")
                }
            }
            b(tr("Видалити", "Удалить"), has) { dlg = "delete" }
            b(tr("Перейменувати", "Переименовать"), one) { input = sel().firstOrNull()?.name ?: ""; dlg = "rename" }
            b(tr("Нова папка", "Новая папка")) { input = ""; dlg = "mkdir" }
            b(tr("Розпакувати →", "Распаковать →"), has) {
                val l = sel().filter { it.extension.equals("zip", true) }; val t = oth().dir
                runOp(tr("Розпаковування…", "Распаковка…")) {
                    var n = 0
                    for (z in l) n += ZipTools.unzip(z, Fs.uniqueFile(t, z.nameWithoutExtension)) { busy = it }
                    "✔ " + tr("Розпаковано файлів: $n", "Распаковано файлов: $n")
                }
            }
            b(tr("У ZIP →", "В ZIP →"), has) { input = (sel().firstOrNull()?.nameWithoutExtension ?: "archive"); dlg = "zipname" }
            b(tr("Конвертувати", "Конвертировать"), one && sel().firstOrNull()?.extension.equals("zip", true)) { sel().firstOrNull()?.let(onConvert) }
            b(tr("Редагувати", "Редактировать"), one && sel().firstOrNull()?.isFile == true) { sel().firstOrNull()?.let(onEdit) }
            b("→ AI", one && sel().firstOrNull()?.isFile == true) {
                val f = sel().first()
                runOp(tr("Аналіз файлу…", "Анализ файла…")) {
                    Session.aiFile = f
                    Session.aiAttach = "FILE ${f.name}:\n" + Insight.analyze(f)
                    "✔ " + tr("Файл проаналізовано й додано до AI-помічника (відкрийте 🤖 і ввімкніть 📎)", "Файл проанализирован и добавлен в AI-помощник (откройте 🤖 и включите 📎)")
                }
            }
            b(tr("Резервна копія", "Резервная копия"), has) {
                val l = sel()
                runOp(tr("Копіювання…", "Копирование…")) {
                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    l.forEach { f -> val d = File(f.parentFile, f.name + ".bak_$ts"); if (f.isDirectory) f.copyRecursively(d) else f.copyTo(d) }
                    "✔ " + tr("Резервні копії створено", "Резервные копии созданы")
                }
            }
            b(tr("Інфо", "Инфо"), has) {
                val l = sel()
                showInfo {
                    l.joinToString("\n\n") { f ->
                        "${f.absolutePath}\n${if (f.isDirectory) tr("папка", "папка") else tr("файл", "файл")} · ${Fs.human(dirSize(f))}\n${tr("змінено", "изменено")}: ${Date(f.lastModified())}\nR/W: ${f.canRead()}/${f.canWrite()}" +
                            (if (f.extension.equals("zip", true)) "\nZIP: " + (try { ZipFile(f).use { it.size() } .toString() + " " + tr("записів", "записей") } catch (e: Exception) { tr("пошкоджений", "повреждён") }) else "")
                    }
                }
            }
            b(tr("Порівняти", "Сравнить"), panes[0].sel.size == 1 && panes[1].sel.size == 1) {
                val a = File(panes[0].sel.first()); val c = File(panes[1].sel.first())
                showInfo {
                    val sb = StringBuilder("A: ${a.name} ${Fs.human(a.length())}\nB: ${c.name} ${Fs.human(c.length())}\n")
                    if (a.isFile && c.isFile) {
                        sb.appendLine(if (sha(a) == sha(c)) "SHA-256: " + tr("ідентичні ✔", "идентичны ✔") else "SHA-256: " + tr("різні", "различны"))
                        if (a.extension.lowercase() in TEXT_EXT && a.length() < 2_000_000 && c.length() < 2_000_000) {
                            val la = a.readLines(); val lc = c.readLines(); var shown = 0; var diff = 0
                            for (i in 0 until maxOf(la.size, lc.size)) {
                                val x = la.getOrNull(i); val y = lc.getOrNull(i)
                                if (x != y) { diff++; if (shown < 15) { sb.appendLine("${i + 1}:\n - ${x?.take(120)}\n + ${y?.take(120)}"); shown++ } }
                            }
                            sb.appendLine(tr("Різних рядків: $diff (порівняння по номерах рядків)", "Различных строк: $diff (сравнение по номерам строк)"))
                        }
                    } else sb.appendLine(tr("Оберіть по одному файлу в кожній панелі", "Выберите по одному файлу в каждой панели"))
                    sb.toString()
                }
            }
        }
            }
        }

    if (dlg == "delete") AlertDialog(onDismissRequest = { dlg = "" },
        title = { Text(tr("Видалити без відновлення?", "Удалить без восстановления?")) },
        text = { Text(sel().joinToString("\n") { it.name }.take(600)) },
        confirmButton = { TextButton(onClick = { dlg = ""; val l = sel(); runOp(tr("Видалення…", "Удаление…")) { l.forEach { it.deleteRecursively() }; "✔ " + tr("Видалено: ${l.size}", "Удалено: ${l.size}") } }) { Text(tr("Видалити", "Удалить")) } },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text(tr("Скасувати", "Отмена")) } })

    if (dlg == "rename" || dlg == "mkdir" || dlg == "zipname") AlertDialog(onDismissRequest = { dlg = "" },
        title = { Text(when (dlg) { "rename" -> tr("Нове ім'я", "Новое имя"); "mkdir" -> tr("Назва папки", "Название папки"); else -> tr("Ім'я ZIP (без .zip)", "Имя ZIP (без .zip)") }) },
        text = { OutlinedTextField(input, { input = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                val kind = dlg; dlg = ""; val name = input.trim().replace("/", "_")
                if (name.isEmpty()) return@TextButton
                val l = sel(); val here = act().dir; val t = oth().dir
                when (kind) {
                    "rename" -> runOp("…") { val f = l.first(); if (File(f.parentFile, name).exists()) "✖ " + tr("Таке ім'я вже є", "Такое имя уже есть") else if (f.renameTo(File(f.parentFile, name))) "✔ OK" else "✖ rename" }
                    "mkdir" -> runOp("…") { if (File(here, name).mkdirs()) "✔ OK" else "✖ mkdir" }
                    else -> runOp(tr("Пакування…", "Упаковка…")) {
                        val out = Fs.uniqueFile(t, "$name.zip")
                        ZipTools.zipPaths(l, out, contentsAtRoot = l.size == 1 && l[0].isDirectory) { busy = it }
                        "✔ ${out.name} (${Fs.human(out.length())})"
                    }
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text(tr("Скасувати", "Отмена")) } })

    if (dlg == "zipmenu") zipTarget?.let { z ->
        AlertDialog(onDismissRequest = { dlg = "" }, title = { Text(z.name) },
            text = { Text(Fs.human(z.length())) },
            confirmButton = { TextButton(onClick = { dlg = ""; onConvert(z) }) { Text(tr("Конвертувати", "Конвертировать")) } },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        dlg = ""; val t = oth().dir
                        runOp(tr("Розпаковування…", "Распаковка…")) { "✔ " + ZipTools.unzip(z, Fs.uniqueFile(t, z.nameWithoutExtension)) { busy = it } + " " + tr("файлів", "файлов") }
                    }) { Text(tr("Розпакувати →", "Распаковать →")) }
                    TextButton(onClick = { dlg = "" }) { Text(tr("Закрити", "Закрыть")) }
                }
            })
    }

    if (dlg == "openfile") zipTarget?.let { f ->
        AlertDialog(onDismissRequest = { dlg = "" }, title = { Text(f.name) }, text = { Text(Fs.human(f.length())) },
            confirmButton = { TextButton(onClick = { dlg = ""; try { openExternal(ctx, f) } catch (e: Exception) { note = "✖ ${e.message}" } }) { Text(tr("Відкрити в програмі…", "Открыть в приложении…")) } },
            dismissButton = {
                Row {
                    if (f.length() < 3_000_000) TextButton(onClick = { dlg = ""; onEdit(f) }) { Text(tr("Як текст", "Как текст")) }
                    TextButton(onClick = { dlg = "" }) { Text(tr("Закрити", "Закрыть")) }
                }
            })
    }

    if (dlg == "info") AlertDialog(onDismissRequest = { dlg = "" }, title = { Text(tr("Інформація", "Информация")) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(infoText, fontSize = 12.sp, fontFamily = FontFamily.Monospace) } },
        confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } })
}
