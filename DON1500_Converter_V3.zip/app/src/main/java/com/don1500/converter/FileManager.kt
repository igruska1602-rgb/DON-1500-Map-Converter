@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

class PaneState(start: File) {
    var dir by mutableStateOf(start)
    var sel by mutableStateOf(setOf<String>())
    var sort by mutableStateOf(0) // 0 ім'я, 1 розмір, 2 дата
}

private val TEXT_EXT = setOf("xml", "lua", "txt", "log", "json", "i3d", "md", "ini", "cfg", "properties", "gradle", "yml")

private fun iconFor(f: File): ImageVector = if (f.isDirectory) Icons.Filled.Folder else when (f.extension.lowercase()) {
    "zip", "rar", "7z" -> Icons.Filled.FolderZip
    "xml", "lua", "txt", "log", "json", "md" -> Icons.Filled.Description
    "i3d", "shapes" -> Icons.Filled.ViewInAr
    "png", "jpg", "jpeg", "dds", "webp" -> Icons.Filled.Image
    "apk" -> Icons.Filled.Android
    else -> Icons.Filled.InsertDriveFile
}

private fun openExternal(ctx: android.content.Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, f.name))
}

private fun dirSize(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

private fun sha(f: File): String {
    val md = MessageDigest.getInstance("SHA-256"); val b = ByteArray(1 shl 16)
    f.inputStream().use { i -> while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
    return md.digest().joinToString("") { "%02x".format(it) }
}

@Composable
fun PaneView(
    p: PaneState, active: Boolean, tick: Int, filter: String, mod: Modifier, compact: Boolean,
    onActivate: () -> Unit, onOpenFile: (File) -> Unit, onAction: (File, String) -> Unit
) {
    val raw = remember(p.dir, tick) { p.dir.listFiles() }
    val rows = remember(raw, filter, p.sort) {
        (raw?.toList() ?: emptyList()).filter { filter.isBlank() || it.name.contains(filter, true) }
            .sortedWith(compareBy<File>({ !it.isDirectory }).thenComparator { a, b ->
                when (p.sort) { 1 -> b.length().compareTo(a.length()); 2 -> b.lastModified().compareTo(a.lastModified()); else -> a.name.compareTo(b.name, true) }
            })
    }
    val df = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    val selecting = p.sel.isNotEmpty()
    fun toggle(f: File) { p.sel = if (f.absolutePath in p.sel) p.sel - f.absolutePath else p.sel + f.absolutePath }
    Column(mod.padding(2.dp).border(2.dp, if (active) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(10.dp)).clickable { onActivate() }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onActivate(); p.dir.parentFile?.let { p.dir = it; p.sel = emptySet() } }, modifier = Modifier.size(34.dp)) { Icon(Icons.Filled.ArrowUpward, null) }
            Text(p.dir.absolutePath, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Text("${rows.size}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 6.dp))
        }
        if (raw == null) {
            InfoHint(tr("Ця папка закрита Android: починаючи з Android 11 сторонні програми не можуть відкривати Android/data та Android/obb (це обмеження системи, не помилка програми). Усі інші папки відкриваються після «Доступу до всіх файлів». Вміст гри можна взяти з APK через «Вибрати APK» → донор.",
                "Эта папка закрыта Android: начиная с Android 11 сторонние приложения не могут открывать Android/data и Android/obb (это ограничение системы, не ошибка программы). Остальные папки открываются после «Доступа ко всем файлам». Содержимое игры можно взять из APK через «Выбрать APK» → донор."), Modifier.padding(8.dp))
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(rows, key = { it.absolutePath }) { f ->
                val selected = f.absolutePath in p.sel
                val ext = f.extension.lowercase()
                Row(Modifier.fillMaxWidth().background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else Color.Transparent)
                    .combinedClickable(
                        onClick = {
                            onActivate()
                            if (selecting) toggle(f)
                            else if (f.isDirectory) { p.dir = f; p.sel = emptySet() } else onOpenFile(f)
                        },
                        onLongClick = { onActivate(); toggle(f) }
                    ).padding(start = 6.dp, top = 1.dp, bottom = 1.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(iconFor(f), null, tint = if (f.isDirectory) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary, modifier = Modifier.size(if (compact) 22.dp else 26.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = if (compact) 12.sp else 14.sp)
                        Text(
                            (if (f.isDirectory) tr("папка", "папка") else Fs.human(f.length())) + (if (compact) "" else " · " + df.format(Date(f.lastModified()))),
                            fontSize = 10.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (selecting) Checkbox(selected, { toggle(f) }, modifier = Modifier.size(36.dp))
                    else Box {
                        IconButton(onClick = { onActivate(); menuFor = f.absolutePath }, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.MoreVert, null, Modifier.size(20.dp)) }
                        DropdownMenu(expanded = menuFor == f.absolutePath, onDismissRequest = { menuFor = null }) {
                            @Composable fun item(id: String, label: String, icon: ImageVector) =
                                DropdownMenuItem(text = { Text(label) }, leadingIcon = { Icon(icon, null) }, onClick = { menuFor = null; onAction(f, id) })
                            item("select", tr("Вибрати", "Выбрать"), Icons.Filled.CheckCircle)
                            item("copy", tr("Копіювати →", "Копировать →"), Icons.Filled.ContentCopy)
                            item("move", tr("Перемістити →", "Переместить →"), Icons.Filled.DriveFileMove)
                            item("rename", tr("Перейменувати", "Переименовать"), Icons.Filled.DriveFileRenameOutline)
                            item("delete", tr("Видалити", "Удалить"), Icons.Filled.Delete)
                            item("zip", tr("У ZIP →", "В ZIP →"), Icons.Filled.Archive)
                            if (ext == "zip") {
                                item("unzip", tr("Розпакувати →", "Распаковать →"), Icons.Filled.Unarchive)
                                item("convert", tr("Конвертувати", "Конвертировать"), Icons.Filled.Build)
                            }
                            if (f.isFile) {
                                item("edit", tr("Редагувати", "Редактировать"), Icons.Filled.Edit)
                                item("ai", "→ AI", Icons.Filled.SmartToy)
                                item("open", tr("Відкрити в програмі…", "Открыть в приложении…"), Icons.Filled.OpenInNew)
                            }
                            item("backup", tr("Резервна копія", "Резервная копия"), Icons.Filled.Backup)
                            item("info", tr("Інфо", "Инфо"), Icons.Filled.Info)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FileManagerScreen(store: Store, onBack: () -> Unit, onConvert: (File) -> Unit, onEdit: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val root = remember { Environment.getExternalStorageDirectory() }
    val panes = remember { listOf(PaneState(root), PaneState(File(root, "Download"))) }
    var active by remember { mutableStateOf(0) }
    var tick by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var infoText by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var zipTarget by remember { mutableStateOf<File?>(null) }
    var layout by remember { mutableStateOf(store.fmLayout) } // 0 зверху/знизу, 1 ліворуч/праворуч, 2 одна панель
    var topMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var addMenu by remember { mutableStateOf(false) }
    val hasAll = remember(tick) { Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager() }
    val openAi = LocalOpenAi.current

    fun act() = panes[active]
    fun oth() = panes[1 - active]
    fun sel(): List<File> = act().sel.map { File(it) }.filter { it.exists() }
    val selCount = panes.sumOf { it.sel.size }
    fun setLayout(v: Int) { layout = v; store.fmLayout = v }

    fun runOp(label: String, block: () -> String) {
        scope.launch {
            busy = label
            note = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "✖ ${e.message}" } }
            busy = ""; panes.forEach { it.sel = emptySet() }; tick++
        }
    }
    fun showInfo(block: () -> String) {
        scope.launch { infoText = withContext(Dispatchers.IO) { try { block() } catch (e: Exception) { "✖ ${e.message}" } }; dlg = "info" }
    }
    fun go(f: File) { act().dir = f; act().sel = emptySet(); tick++ }

    fun doCopy() {
        val l = sel(); val t = oth().dir
        runOp(tr("Копіювання…", "Копирование…")) {
            var n = 0
            for (f in l) {
                if (f.isDirectory && t.canonicalPath.startsWith(f.canonicalPath)) continue
                val d = Fs.uniqueFile(t, f.name); if (f.isDirectory) f.copyRecursively(d) else f.copyTo(d); n++
            }
            "✔ " + tr("Скопійовано: $n", "Скопировано: $n")
        }
    }
    fun doMove() {
        val l = sel(); val t = oth().dir
        runOp(tr("Переміщення…", "Перемещение…")) {
            var n = 0
            for (f in l) {
                if (f.isDirectory && t.canonicalPath.startsWith(f.canonicalPath)) continue
                val d = Fs.uniqueFile(t, f.name)
                if (!f.renameTo(d)) { if (f.isDirectory) f.copyRecursively(d) else f.copyTo(d); f.deleteRecursively() }
                n++
            }
            "✔ " + tr("Переміщено: $n", "Перемещено: $n")
        }
    }
    fun doUnzip() {
        val l = sel().filter { it.extension.equals("zip", true) }; val t = oth().dir
        runOp(tr("Розпаковування…", "Распаковка…")) {
            var n = 0
            for (z in l) n += ZipTools.unzip(z, Fs.uniqueFile(t, z.nameWithoutExtension)) { busy = it }
            "✔ " + tr("Розпаковано файлів: $n", "Распаковано файлов: $n")
        }
    }
    fun doAi() {
        val f = sel().firstOrNull() ?: return
        runOp(tr("Аналіз файлу…", "Анализ файла…")) {
            Session.aiFile = f
            Session.aiAttach = "FILE ${f.name}:\n" + Insight.analyze(f)
            "✔ " + tr("Файл проаналізовано й додано до AI-помічника (відкрийте 🤖 і ввімкніть 📎)", "Файл проанализирован и добавлен в AI-помощник (откройте 🤖 и включите 📎)")
        }
    }
    fun doBackup() {
        val l = sel()
        runOp(tr("Копіювання…", "Копирование…")) {
            val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            l.forEach { f -> val d = File(f.parentFile, f.name + ".bak_$ts"); if (f.isDirectory) f.copyRecursively(d) else f.copyTo(d) }
            "✔ " + tr("Резервні копії створено", "Резервные копии созданы")
        }
    }
    fun doInfo() {
        val l = sel()
        showInfo {
            l.joinToString("\n\n") { f ->
                "${f.absolutePath}\n${if (f.isDirectory) tr("папка", "папка") else tr("файл", "файл")} · ${Fs.human(dirSize(f))}\n${tr("змінено", "изменено")}: ${Date(f.lastModified())}\nR/W: ${f.canRead()}/${f.canWrite()}" +
                    (if (f.extension.equals("zip", true)) "\nZIP: " + (try { ZipFile(f).use { it.size() }.toString() + " " + tr("записів", "записей") } catch (e: Exception) { tr("пошкоджений", "повреждён") }) else "")
            }
        }
    }
    fun doCompare() {
        val a = File(panes[0].sel.first()); val c = File(panes[1].sel.first())
        showInfo {
            val sb = StringBuilder("A: ${a.name} ${Fs.human(a.length())}\nB: ${c.name} ${Fs.human(c.length())}\n")
            if (a.isFile && c.isFile) {
                sb.appendLine(if (sha(a) == sha(c)) "SHA-256: " + tr("ідентичні ✔", "идентичны ✔") else "SHA-256: " + tr("різні", "различны"))
                if (a.extension.lowercase() in TEXT_EXT && a.length() < 2_000_000 && c.length() < 2_000_000) {
                    val la = a.readLines(); val lc = c.readLines(); var shown = 0; var diff = 0
                    for (i in 0 until maxOf(la.size, lc.size)) {
                        val x = la.getOrNull(i); val y = lc.getOrNull(i)
                        if (x != y) { diff++; if (shown < 15) { sb.appendLine("${i + 1}:\n - ${x?.take(120)}\n + ${y?.take(120)}"); shown++ } }
                    }
                    sb.appendLine(tr("Різних рядків: $diff (порівняння по номерах рядків)", "Различных строк: $diff (сравнение по номерам строк)"))
                }
            } else sb.appendLine(tr("Оберіть по одному файлу в кожній панелі", "Выберите по одному файлу в каждой панели"))
            sb.toString()
        }
    }
    fun doAction(id: String) {
        when (id) {
            "copy" -> doCopy()
            "move" -> doMove()
            "delete" -> dlg = "delete"
            "rename" -> { input = sel().firstOrNull()?.name ?: ""; dlg = "rename" }
            "zip" -> { input = (sel().firstOrNull()?.nameWithoutExtension ?: "archive"); dlg = "zipname" }
            "unzip" -> doUnzip()
            "convert" -> sel().firstOrNull()?.let(onConvert)
            "edit" -> sel().firstOrNull()?.let(onEdit)
            "ai" -> doAi()
            "open" -> sel().firstOrNull()?.let { try { openExternal(ctx, it) } catch (e: Exception) { note = "✖ ${e.message}" } }
            "backup" -> doBackup()
            "info" -> doInfo()
            "compare" -> doCompare()
        }
    }
    // Дія з меню «⋮» одного рядка: робимо цей файл єдиним виділеним і виконуємо.
    fun rowAction(pane: Int, f: File, id: String) {
        active = pane
        if (id == "select") { panes[pane].sel = panes[pane].sel + f.absolutePath; return }
        panes[pane].sel = setOf(f.absolutePath)
        panes[1 - pane].sel = emptySet()
        doAction(id)
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        // ---------- верхня панель ----------
        if (selCount > 0) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)).padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { panes.forEach { it.sel = emptySet() } }) { Icon(Icons.Filled.Close, null) }
                Text("$selCount", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    act().sel = act().dir.listFiles()?.filter { filter.isBlank() || it.name.contains(filter, true) }?.map { it.absolutePath }?.toSet() ?: emptySet()
                }) { Icon(Icons.Filled.SelectAll, null) }
                IconButton(onClick = { doCopy() }, enabled = busy.isEmpty()) { Icon(Icons.Filled.ContentCopy, null) }
                IconButton(onClick = { doMove() }, enabled = busy.isEmpty()) { Icon(Icons.Filled.DriveFileMove, null) }
                IconButton(onClick = { dlg = "delete" }, enabled = busy.isEmpty()) { Icon(Icons.Filled.Delete, null) }
                Box {
                    IconButton(onClick = { moreMenu = true }) { Icon(Icons.Filled.MoreVert, null) }
                    DropdownMenu(moreMenu, { moreMenu = false }) {
                        val one = act().sel.size == 1
                        val f1 = sel().firstOrNull()
                        @Composable fun mi(id: String, label: String, enabled: Boolean = true) =
                            DropdownMenuItem(text = { Text(label) }, enabled = enabled && busy.isEmpty(), onClick = { moreMenu = false; doAction(id) })
                        mi("rename", tr("Перейменувати", "Переименовать"), one)
                        mi("zip", tr("У ZIP →", "В ZIP →"))
                        mi("unzip", tr("Розпакувати →", "Распаковать →"))
                        mi("convert", tr("Конвертувати", "Конвертировать"), one && f1?.extension.equals("zip", true))
                        mi("edit", tr("Редагувати", "Редактировать"), one && f1?.isFile == true)
                        mi("ai", "→ AI", one && f1?.isFile == true)
                        mi("backup", tr("Резервна копія", "Резервная копия"))
                        mi("info", tr("Інфо", "Инфо"))
                        mi("compare", tr("Порівняти (по файлу в кожній панелі)", "Сравнить (по файлу в каждой панели)"), panes[0].sel.size == 1 && panes[1].sel.size == 1)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
                Text(tr("Файловий менеджер", "Файловый менеджер"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                IconButton(onClick = { showSearch = !showSearch; if (!showSearch) filter = "" }) { Icon(Icons.Filled.Search, null) }
                IconButton(onClick = { setLayout((layout + 1) % 3) }) {
                    Icon(when (layout) { 0 -> Icons.Filled.ViewAgenda; 1 -> Icons.Filled.ViewColumn; else -> Icons.Filled.CropPortrait }, null, tint = MaterialTheme.colorScheme.primary)
                }
                if (openAi != null) IconButton(onClick = openAi) { Icon(Icons.Filled.SmartToy, null, tint = MaterialTheme.colorScheme.primary) }
                Box {
                    IconButton(onClick = { topMenu = true }) { Icon(Icons.Filled.MoreVert, null) }
                    DropdownMenu(topMenu, { topMenu = false }) {
                        @Composable fun ti(label: String, onClick: () -> Unit) = DropdownMenuItem(text = { Text(label) }, onClick = { topMenu = false; onClick() })
                        ti(tr("Розділити: зверху / знизу", "Разделить: сверху / снизу")) { setLayout(0) }
                        ti(tr("Розділити: ліворуч / праворуч", "Разделить: слева / справа")) { setLayout(1) }
                        ti(tr("Одна панель", "Одна панель")) { setLayout(2) }
                        ti(tr("Сортування: A-Z", "Сортировка: A-Z")) { act().sort = 0 }
                        ti(tr("Сортування: розмір", "Сортировка: размер")) { act().sort = 1 }
                        ti(tr("Сортування: дата", "Сортировка: дата")) { act().sort = 2 }
                        ti(tr("Куди зберігати результати…", "Куда сохранять результаты…")) { dlg = "outpick" }
                        if (OutPref.path.isNotBlank()) ti(tr("Перейти в папку збереження", "Перейти в папку сохранения")) { go(File(OutPref.path)) }
                        ti(tr("Оновити", "Обновить")) { tick++ }
                    }
                }
            }
            if (showSearch) OutlinedTextField(filter, { filter = it }, Modifier.fillMaxWidth().padding(horizontal = 8.dp), singleLine = true,
                placeholder = { Text(tr("Пошук у папці…", "Поиск в папке…"), fontSize = 12.sp) },
                trailingIcon = { IconButton(onClick = { filter = ""; showSearch = false }) { Icon(Icons.Filled.Close, null) } })
        }
        if (!hasAll) Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Потрібен «Доступ до всіх файлів», щоб бачити всі папки.", "Нужен «Доступ ко всем файлам», чтобы видеть все папки."), Modifier.weight(1f), fontSize = 12.sp)
                TextButton(onClick = {
                    try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }
                    catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                }) { Text(tr("Дати", "Дать")) }
                TextButton(onClick = { tick++ }) { Text(tr("Перевірити", "Проверить")) }
            }
        }
        // ---------- панелі ----------
        Box(Modifier.weight(1f)) {
            val pv: @Composable (Int, Modifier, Boolean) -> Unit = { i, m, compact ->
                PaneView(panes[i], i == active, tick, filter, m, compact, { active = i }, { f ->
                    active = i
                    val ext = f.extension.lowercase()
                    when {
                        ext == "zip" -> { panes[i].sel = setOf(f.absolutePath); zipTarget = f; dlg = "zipmenu" }
                        ext in TEXT_EXT -> onEdit(f)
                        else -> { zipTarget = f; dlg = "openfile" }
                    }
                }, { f, id -> rowAction(i, f, id) })
            }
            when (layout) {
                1 -> Row(Modifier.fillMaxSize()) { pv(0, Modifier.weight(1f).fillMaxHeight(), true); pv(1, Modifier.weight(1f).fillMaxHeight(), true) }
                2 -> pv(active, Modifier.fillMaxSize(), false)
                else -> Column(Modifier.fillMaxSize()) { pv(0, Modifier.weight(1f), false); pv(1, Modifier.weight(1f), false) }
            }
            // «+» — створити
            Box(Modifier.align(Alignment.BottomEnd).padding(14.dp)) {
                FloatingActionButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); addMenu = true }, modifier = Modifier.size(52.dp)) { Icon(Icons.Filled.Add, null) }
                DropdownMenu(addMenu, { addMenu = false }) {
                    DropdownMenuItem(text = { Text(tr("Нова папка", "Новая папка")) }, leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) }, onClick = { addMenu = false; input = ""; dlg = "mkdir" })
                    DropdownMenuItem(text = { Text(tr("Новий файл", "Новый файл")) }, leadingIcon = { Icon(Icons.Filled.NoteAdd, null) }, onClick = { addMenu = false; input = ""; dlg = "mkfile" })
                }
            }
        }
        if (busy.isNotEmpty()) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(busy, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 8.dp)) }
        if (note.isNotEmpty()) Text(note, fontSize = 12.sp, maxLines = 3, modifier = Modifier.padding(horizontal = 8.dp), color = MaterialTheme.colorScheme.secondary)
        // ---------- швидкі місця ----------
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Root" to root, "Download" to File(root, "Download"), "Android/data" to File(root, "Android/data"), "Android/media" to File(root, "Android/media"), "Android/obb" to File(root, "Android/obb"), "/" to File("/"))
                .forEach { (n, f) -> AssistChip(onClick = { go(f) }, label = { Text(n, fontSize = 11.sp) }) }
            if (OutPref.path.isNotBlank()) AssistChip(onClick = { go(File(OutPref.path)) }, label = { Text(tr("Збереження", "Сохранение"), fontSize = 11.sp) })
            AssistChip(onClick = { go(Fs.work(ctx)) }, label = { Text(tr("Робоча", "Рабочая"), fontSize = 11.sp) })
            AssistChip(onClick = { go(Fs.outDir(ctx)) }, label = { Text(tr("Результати", "Результаты"), fontSize = 11.sp) })
            ctx.getExternalFilesDirs(null).filterNotNull().map { File(it.absolutePath.substringBefore("/Android")) }.distinct().filter { it != root }
                .forEach { v -> AssistChip(onClick = { go(v) }, label = { Text(v.name.ifEmpty { "SD" }, fontSize = 11.sp) }) }
        }
        Spacer(Modifier.height(if (ConvJob.busy || ConvJob.done) 76.dp else 0.dp))
    }

    if (dlg == "outpick") FolderPickerDialog(OutPref.path, onPick = { OutPref.setPath(store, it); dlg = ""; note = "✔ " + tr("Результати зберігатимуться в: ", "Результаты будут сохраняться в: ") + it }, onDismiss = { dlg = "" })

    if (dlg == "delete") AlertDialog(onDismissRequest = { dlg = "" },
        title = { Text(tr("Видалити без відновлення?", "Удалить без восстановления?")) },
        text = { Text(sel().joinToString("\n") { it.name }.take(600)) },
        confirmButton = { TextButton(onClick = { dlg = ""; val l = sel(); runOp(tr("Видалення…", "Удаление…")) { l.forEach { it.deleteRecursively() }; "✔ " + tr("Видалено: ${l.size}", "Удалено: ${l.size}") } }) { Text(tr("Видалити", "Удалить")) } },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text(tr("Скасувати", "Отмена")) } })

    if (dlg == "rename" || dlg == "mkdir" || dlg == "mkfile" || dlg == "zipname") AlertDialog(onDismissRequest = { dlg = "" },
        title = { Text(when (dlg) { "rename" -> tr("Нове ім'я", "Новое имя"); "mkdir" -> tr("Назва папки", "Название папки"); "mkfile" -> tr("Назва файлу", "Название файла"); else -> tr("Ім'я ZIP (без .zip)", "Имя ZIP (без .zip)") }) },
        text = { OutlinedTextField(input, { input = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                val kind = dlg; dlg = ""; val name = input.trim().replace("/", "_")
                if (name.isEmpty()) return@TextButton
                val l = sel(); val here = act().dir; val t = oth().dir
                when (kind) {
                    "rename" -> runOp("…") { val f = l.first(); if (File(f.parentFile, name).exists()) "✖ " + tr("Таке ім'я вже є", "Такое имя уже есть") else if (f.renameTo(File(f.parentFile, name))) "✔ OK" else "✖ rename" }
                    "mkdir" -> runOp("…") { if (File(here, name).mkdirs()) "✔ OK" else "✖ mkdir" }
                    "mkfile" -> runOp("…") { val f = File(here, name); if (f.exists()) "✖ " + tr("Таке ім'я вже є", "Такое имя уже есть") else if (f.createNewFile()) "✔ OK" else "✖ create" }
                    else -> runOp(tr("Пакування…", "Упаковка…")) {
                        val out = Fs.uniqueFile(t, "$name.zip")
                        ZipTools.zipPaths(l, out, contentsAtRoot = l.size == 1 && l[0].isDirectory) { busy = it }
                        "✔ ${out.name} (${Fs.human(out.length())})"
                    }
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text(tr("Скасувати", "Отмена")) } })

    if (dlg == "zipmenu") zipTarget?.let { z ->
        AlertDialog(onDismissRequest = { dlg = ""; panes.forEach { it.sel = emptySet() } }, title = { Text(z.name) },
            text = { Text(Fs.human(z.length())) },
            confirmButton = { TextButton(onClick = { dlg = ""; panes.forEach { it.sel = emptySet() }; onConvert(z) }) { Text(tr("Конвертувати", "Конвертировать")) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { dlg = ""; doUnzip() }) { Text(tr("Розпакувати →", "Распаковать →")) }
                    TextButton(onClick = { dlg = ""; panes.forEach { it.sel = emptySet() } }) { Text(tr("Закрити", "Закрыть")) }
                }
            })
    }

    if (dlg == "openfile") zipTarget?.let { f ->
        AlertDialog(onDismissRequest = { dlg = "" }, title = { Text(f.name) }, text = { Text(Fs.human(f.length())) },
            confirmButton = { TextButton(onClick = { dlg = ""; try { openExternal(ctx, f) } catch (e: Exception) { note = "✖ ${e.message}" } }) { Text(tr("Відкрити в програмі…", "Открыть в приложении…")) } },
            dismissButton = {
                Row {
                    if (f.length() < 3_000_000) TextButton(onClick = { dlg = ""; onEdit(f) }) { Text(tr("Як текст", "Как текст")) }
                    TextButton(onClick = { dlg = "" }) { Text(tr("Закрити", "Закрыть")) }
                }
            })
    }

    if (dlg == "info") AlertDialog(onDismissRequest = { dlg = "" }, title = { Text(tr("Інформація", "Информация")) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(infoText, fontSize = 12.sp, fontFamily = FontFamily.Monospace) } },
        confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } })
}
