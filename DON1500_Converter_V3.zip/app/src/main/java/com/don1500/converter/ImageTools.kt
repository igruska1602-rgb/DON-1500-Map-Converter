@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException

/** Читання зображень (PNG/JPG/WEBP/BMP/DDS), зміна розміру, запис у PNG / JPG / TGA / DDS (DXT1 або DXT5 з мипмапами). */
object ImageTools {
    class Img(val w: Int, val h: Int, val px: IntArray)

    fun load(bytes: ByteArray, name: String): Img? {
        var data = bytes
        if (name.endsWith(".dds", true)) { val r = Dds.decode(bytes, 0); data = r.png ?: return null }
        val bmp = BitmapFactory.decodeByteArray(data, 0, data.size) ?: return null
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val img = Img(bmp.width, bmp.height, px)
        bmp.recycle()
        return img
    }

    fun resize(img: Img, size: Int, square: Boolean): Img {
        if (size <= 0) return img
        val nw: Int; val nh: Int
        if (square) { nw = size; nh = size } else {
            val s = size.toFloat() / maxOf(img.w, img.h)
            nw = maxOf(1, (img.w * s).toInt()); nh = maxOf(1, (img.h * s).toInt())
        }
        if (nw == img.w && nh == img.h) return img
        val src = Bitmap.createBitmap(img.px, img.w, img.h, Bitmap.Config.ARGB_8888)
        val dst = Bitmap.createScaledBitmap(src, nw, nh, true)
        val px = IntArray(nw * nh)
        dst.getPixels(px, 0, nw, 0, 0, nw, nh)
        if (dst !== src) dst.recycle()
        src.recycle()
        return Img(nw, nh, px)
    }

    private fun opaque(px: IntArray): Boolean { for (v in px) if ((v ushr 24) != 255) return false; return true }

    fun encode(img: Img, fmt: String): ByteArray = when (fmt) {
        "PNG" -> bitmapBytes(img, Bitmap.CompressFormat.PNG, 100, !opaque(img.px))
        "JPG" -> bitmapBytes(img, Bitmap.CompressFormat.JPEG, 92, false)
        "TGA" -> tga(img)
        "DDS" -> dds(img)
        else -> throw IllegalArgumentException(fmt)
    }

    private fun bitmapBytes(img: Img, f: Bitmap.CompressFormat, q: Int, alpha: Boolean): ByteArray {
        val b = Bitmap.createBitmap(img.px, img.w, img.h, Bitmap.Config.ARGB_8888)
        b.setHasAlpha(alpha)
        val o = ByteArrayOutputStream()
        b.compress(f, q, o)
        b.recycle()
        return o.toByteArray()
    }

    private fun tga(img: Img): ByteArray {
        val out = ByteArray(18 + img.w * img.h * 4)
        out[2] = 2
        out[12] = (img.w and 255).toByte(); out[13] = (img.w shr 8).toByte()
        out[14] = (img.h and 255).toByte(); out[15] = (img.h shr 8).toByte()
        out[16] = 32; out[17] = 0x28
        var o = 18
        for (v in img.px) {
            out[o++] = v.toByte(); out[o++] = (v shr 8).toByte(); out[o++] = (v shr 16).toByte(); out[o++] = (v ushr 24).toByte()
        }
        return out
    }

    private fun le(o: ByteArray, off: Int, v: Int) {
        o[off] = v.toByte(); o[off + 1] = (v shr 8).toByte(); o[off + 2] = (v shr 16).toByte(); o[off + 3] = (v ushr 24).toByte()
    }

    private fun half(i: Img): Img {
        val nw = maxOf(1, i.w / 2); val nh = maxOf(1, i.h / 2)
        val px = IntArray(nw * nh)
        for (y in 0 until nh) for (x in 0 until nw) {
            var a = 0; var r = 0; var g = 0; var b = 0
            for (dy in 0..1) for (dx in 0..1) {
                val v = i.px[minOf(i.h - 1, y * 2 + dy) * i.w + minOf(i.w - 1, x * 2 + dx)]
                a += v ushr 24; r += (v shr 16) and 255; g += (v shr 8) and 255; b += v and 255
            }
            px[y * nw + x] = ((a / 4) shl 24) or ((r / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
        }
        return Img(nw, nh, px)
    }

    private fun dds(img: Img): ByteArray {
        val alpha = !opaque(img.px)
        val levels = ArrayList<Img>()
        var cur = img
        levels.add(cur)
        while (cur.w > 1 || cur.h > 1) { cur = half(cur); levels.add(cur) }
        val bs = if (alpha) 16 else 8
        fun sz(i: Img) = ((i.w + 3) / 4) * ((i.h + 3) / 4) * bs
        val total = levels.sumOf { sz(it) }
        val out = ByteArray(128 + total)
        le(out, 0, 0x20534444); le(out, 4, 124); le(out, 8, 0xA1007)
        le(out, 12, img.h); le(out, 16, img.w); le(out, 20, sz(img)); le(out, 28, levels.size)
        le(out, 76, 32); le(out, 80, 4)
        val fc = if (alpha) "DXT5" else "DXT1"
        for (k in 0..3) out[84 + k] = fc[k].code.toByte()
        le(out, 108, 0x1000 or (if (levels.size > 1) 0x400008 else 0))
        var p = 128
        for (l in levels) p = encodeLevel(l, alpha, out, p)
        return out
    }

    private fun encodeLevel(l: Img, alpha: Boolean, out: ByteArray, start: Int): Int {
        var p = start
        val blk = IntArray(16)
        for (by in 0 until (l.h + 3) / 4) for (bx in 0 until (l.w + 3) / 4) {
            for (j in 0 until 4) for (i in 0 until 4) {
                blk[j * 4 + i] = l.px[minOf(l.h - 1, by * 4 + j) * l.w + minOf(l.w - 1, bx * 4 + i)]
            }
            if (alpha) { alphaBlock(blk, out, p); p += 8 }
            colorBlock(blk, out, p); p += 8
        }
        return p
    }

    private fun alphaBlock(blk: IntArray, out: ByteArray, o: Int) {
        var mn = 255; var mx = 0
        for (v in blk) { val a = v ushr 24; if (a < mn) mn = a; if (a > mx) mx = a }
        out[o] = mx.toByte(); out[o + 1] = mn.toByte()
        if (mx == mn) { for (k in 2..7) out[o + k] = 0; return }
        val t = IntArray(8); t[0] = mx; t[1] = mn
        for (i in 1..6) t[i + 1] = ((7 - i) * mx + i * mn) / 7
        var bits = 0L
        for (i in 0 until 16) {
            val a = blk[i] ushr 24
            var best = 0; var bd = 1000
            for (k in 0 until 8) { val d = Math.abs(t[k] - a); if (d < bd) { bd = d; best = k } }
            bits = bits or (best.toLong() shl (3 * i))
        }
        for (k in 0 until 6) out[o + 2 + k] = ((bits shr (8 * k)) and 255L).toByte()
    }

    private fun colorBlock(blk: IntArray, out: ByteArray, o: Int) {
        var minR = 255; var minG = 255; var minB = 255; var maxR = 0; var maxG = 0; var maxB = 0
        for (v in blk) {
            val r = (v shr 16) and 255; val g = (v shr 8) and 255; val b = v and 255
            if (r < minR) minR = r; if (g < minG) minG = g; if (b < minB) minB = b
            if (r > maxR) maxR = r; if (g > maxG) maxG = g; if (b > maxB) maxB = b
        }
        fun q(r: Int, g: Int, b: Int) = (((r * 31 + 127) / 255) shl 11) or (((g * 63 + 127) / 255) shl 5) or ((b * 31 + 127) / 255)
        var c0 = q(maxR, maxG, maxB); var c1 = q(minR, minG, minB)
        if (c0 < c1) { val t = c0; c0 = c1; c1 = t }
        out[o] = c0.toByte(); out[o + 1] = (c0 shr 8).toByte(); out[o + 2] = c1.toByte(); out[o + 3] = (c1 shr 8).toByte()
        if (c0 == c1) { for (k in 4..7) out[o + k] = 0; return }
        fun ex(c: Int) = intArrayOf(((c shr 11) and 31) * 255 / 31, ((c shr 5) and 63) * 255 / 63, (c and 31) * 255 / 31)
        val a = ex(c0); val b = ex(c1)
        val pal = arrayOf(a, b,
            intArrayOf((2 * a[0] + b[0]) / 3, (2 * a[1] + b[1]) / 3, (2 * a[2] + b[2]) / 3),
            intArrayOf((a[0] + 2 * b[0]) / 3, (a[1] + 2 * b[1]) / 3, (a[2] + 2 * b[2]) / 3))
        var bits = 0
        for (i in 0 until 16) {
            val r = (blk[i] shr 16) and 255; val g = (blk[i] shr 8) and 255; val bl = blk[i] and 255
            var best = 0; var bd = Int.MAX_VALUE
            for (k in 0 until 4) {
                val dr = pal[k][0] - r; val dg = pal[k][1] - g; val db = pal[k][2] - bl
                val d = dr * dr + dg * dg + db * db
                if (d < bd) { bd = d; best = k }
            }
            bits = bits or (best shl (2 * i))
        }
        le(out, o + 4, bits)
    }
}

/** Розкидає вибрані файли по відсутніх шляхах результату (за назвою файлу, з перетворенням формату). */
fun distribute(ctx: Context, uris: List<Uri>, zip: File, rep: ConvertReport, maxTex: Int): String {
    val tmpDir = File(zip.parentFile, ".dist").also { it.mkdirs() }
    val adds = LinkedHashMap<String, File>()
    val unmatched = ArrayList<String>()
    val miss = rep.missing.keys.toList()
    for (u in uris) {
        val name = Fs.displayName(ctx, u)
        val base = name.substringBeforeLast('.').lowercase()
        val targets = miss.filter { it !in adds && it.substringAfterLast('/').substringBeforeLast('.').lowercase() == base }
        if (targets.isEmpty()) { unmatched += name; continue }
        val bytes = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
        for (t in targets) {
            val ext = t.substringAfterLast('.', "").lowercase()
            val f = File(tmpDir, "d_${adds.size}.bin")
            try {
                if (ext == "png" || ext == "dds" || ext == "jpg" || ext == "tga") {
                    val img = ImageTools.load(bytes, name) ?: throw IOException(tr("не зображення", "не изображение"))
                    val r = ImageTools.resize(img, if (maxTex > 0 && maxOf(img.w, img.h) > maxTex) maxTex else 0, false)
                    f.writeBytes(ImageTools.encode(r, ext.uppercase()))
                } else f.writeBytes(bytes)
                adds[t] = f
            } catch (e: Exception) { unmatched += "$name (${e.message})" }
        }
    }
    if (adds.isNotEmpty()) {
        ZipTools.addMany(zip, adds)
        adds.keys.forEach { rep.missing.remove(it); rep.changes += tr("Додано вручну: $it", "Добавлено вручную: $it") }
    }
    tmpDir.deleteRecursively()
    Session.reportText = rep.render(); Session.rev++
    return "✔ " + tr("Розкладено файлів: ${adds.size}", "Разложено файлов: ${adds.size}") +
        (if (unmatched.isNotEmpty()) "\n" + tr("Не підійшли: ", "Не подошли: ") + unmatched.joinToString(", ") else "")
}

@Composable
fun ImagesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uris by remember { mutableStateOf(listOf<Uri>()) }
    var fmt by remember { mutableStateOf("PNG") }
    var size by remember { mutableStateOf(1024) }
    var square by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var cur by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l -> uris = l }
    Frame(tr("Конвертер зображень", "Конвертер изображений"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("Вибрати зображення (одне чи кілька)", "Выбрать изображения (одно или несколько)")) }
            Text(tr("Вибрано: ${uris.size}. Підтримуються PNG, JPG, WEBP, BMP, DDS.", "Выбрано: ${uris.size}. Поддерживаются PNG, JPG, WEBP, BMP, DDS."), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
            Text(tr("Формат результату", "Формат результата"), fontWeight = FontWeight.Bold)
            Row { listOf("PNG", "DDS", "JPG", "TGA").forEach { f -> FilterChip(fmt == f, { fmt = f }, { Text(f) }); Spacer(Modifier.width(6.dp)) } }
            Text(tr("Розмір", "Размер"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Row { listOf(0 to tr("Оригінал", "Оригинал"), 512 to "512", 1024 to "1024", 2048 to "2048", 4096 to "4096").forEach { (v, l) -> FilterChip(size == v, { size = v }, { Text(l, fontSize = 12.sp) }); Spacer(Modifier.width(4.dp)) } }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(tr("Робити квадрат (512×512, 1024×1024…), розтягуючи", "Делать квадрат (512×512, 1024×1024…), растягивая"), Modifier.weight(1f), fontSize = 13.sp)
                Switch(square, { square = it })
            }
            Text(tr("DDS записується як DXT1 (без прозорості) або DXT5 (з прозорістю), з мипмапами. ASTC не підтримується.", "DDS записывается как DXT1 (без прозрачности) или DXT5 (с прозрачностью), с мипмапами. ASTC не поддерживается."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(enabled = uris.isNotEmpty() && !busy, modifier = Modifier.padding(top = 8.dp), onClick = {
                scope.launch {
                    busy = true; msg = ""; prog = 0f
                    msg = withContext(Dispatchers.IO) {
                        var ok = 0
                        val errs = StringBuilder()
                        for ((i, u) in uris.withIndex()) {
                            prog = i / uris.size.toFloat()
                            val name = Fs.displayName(ctx, u); cur = name
                            try {
                                val bytes = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
                                val img = ImageTools.load(bytes, name) ?: throw IOException(tr("не вдалося прочитати зображення", "не удалось прочитать изображение"))
                                val out = ImageTools.encode(ImageTools.resize(img, size, square), fmt)
                                val f = File(Fs.work(ctx), name.substringBeforeLast('.') + "." + fmt.lowercase())
                                f.writeBytes(out)
                                Fs.publish(ctx, f, "application/octet-stream", "converted")
                                ok++
                            } catch (e: Throwable) { errs.appendLine("$name: ${e.message}") }
                        }
                        "✔ $ok / ${uris.size} → Download/DON1500/converted\n$errs"
                    }
                    busy = false
                }
            }) { Text(tr("Конвертувати", "Конвертировать")) }
            if (busy) { LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)); Text("${(prog * 100).toInt()}% · $cur", fontSize = 12.sp) }
            if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
        }
    }
}
