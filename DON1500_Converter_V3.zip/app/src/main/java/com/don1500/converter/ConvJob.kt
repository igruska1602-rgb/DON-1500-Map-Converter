package com.don1500.converter

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Конвертація живе на рівні програми, а не екрана: можна вийти з «Конвертера» в будь-який інший розділ,
 * а прогрес (відсотки, час, «Скасувати») показується смужкою внизу на всіх екранах.
 * Якщо Android сам закриє програму (вона у фоні й бракує пам'яті) — задача зупиниться.
 */
object ConvJob {
    var busy by mutableStateOf(false)
    var done by mutableStateOf(false)
    var prog by mutableStateOf(0f)
    var cur by mutableStateOf("")
    var msg by mutableStateOf("")
    var label by mutableStateOf("")
    var startMs by mutableStateOf(0L)
    val cancelFlag = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun dismiss() { done = false }

    fun start(appCtx: Context, store: Store, analyzeOnly: Boolean, texSize: Int) {
        val s = Session.sourceFile ?: return
        if (busy) return
        val ctx = appCtx.applicationContext
        busy = true; done = false; prog = 0f; msg = ""; cur = ""; label = s.name
        cancelFlag.set(false); startMs = System.currentTimeMillis()
        val target = store.target
        val signNick = store.signNick
        val signOn = store.signEnabled
        val rename = store.renameFs
        val trim = store.trimLang
        val byName = store.donorByName
        scope.launch {
            try {
                val base = Converter.outputName(s.name, target).removeSuffix(".zip")
                val folder = File(Fs.outDir(ctx), base).also { it.mkdirs() }
                val out = if (analyzeOnly) null else File(folder, "$base.zip").also { if (it.exists()) it.delete() }
                val opt = Options(rename, trim, texSize, target, DonorLib.list(ctx, donorTarget(target)), byName, signNick, signOn)
                val r = Converter.run(s, out, opt, isCancelled = { cancelFlag.get() }) { f, p -> cur = f; prog = p }
                // З власною папкою звіти не засмічують її (лише коли ввімкнено «підпапка для кожного мода»).
                val pubReports = OutPref.path.isBlank() || OutPref.sub
                if (!r.cancelled) {
                    if (out != null && out.exists() && r.verified) {
                        Session.outputZip = out
                        try { r.savedTo = Fs.publish(ctx, out, "application/zip", base) } catch (e: Exception) { r.issues += Issue("WARN", out.name, "Save: ${e.message}") }
                    }
                    val tag = if (analyzeOnly) "_analysis" else "_report"
                    val rf = File(folder, base + tag + ".txt"); rf.writeText(r.render())
                    if (pubReports) try { Fs.publish(ctx, rf, "text/plain", base) } catch (_: Exception) { }
                    if (r.missing.isNotEmpty()) {
                        val mf = File(folder, base + "_missing.txt")
                        mf.writeText(r.missing.entries.joinToString("\n") { "${it.key}   <- ${it.value}" })
                        if (pubReports) try { Fs.publish(ctx, mf, "text/plain", base) } catch (_: Exception) { }
                    }
                } else if (folder.listFiles().isNullOrEmpty()) folder.delete()
                Session.report = r; Session.reportText = r.render(); Session.rev++
                if (r.cancelled) msg = tr("⛔ Скасовано", "⛔ Отменено")
                prog = 1f
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false
            done = !cancelFlag.get()
        }
    }
}
