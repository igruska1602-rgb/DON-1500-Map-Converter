package com.don1500.converter

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.sqrt

/** Декодер DDS → PNG: BC1/BC2/BC3/BC5 та нестиснені 24/32 bit. BC7, кубічні та 3D — не підтримуються. */
object Dds {
    class Result(val png: ByteArray?, val error: String?, val w: Int = 0, val h: Int = 0)

    private class Info(val w: Int, val h: Int, val kind: String, val off: Int, val bpp: Int, val masks: IntArray)

    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or
            ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)

    private fun parse(b: ByteArray): Pair<Info?, String?> {
        if (b.size < 128 || le32(b, 0) != 0x20534444) return null to "не DDS-файл"
        val h = le32(b, 12); val w = le32(b, 16)
        val pf = le32(b, 80); val bits = le32(b, 88)
        val caps2 = le32(b, 112)
        if (caps2 and 0x200 != 0) return null to "cubemap не підтримується"
        if (caps2 and 0x200000 != 0) return null to "3D-текстура не підтримується"
        if (w <= 0 || h <= 0 || w.toLong() * h > 8192L * 8192L) return null to "некоректний розмір ${w}x$h"
        val noMask = intArrayOf(0, 0, 0, 0)
        if (pf and 4 != 0) {
            val fc = String(charArrayOf(b[84].toInt().toChar(), b[85].toInt().toChar(), b[86].toInt().toChar(), b[87].toInt().toChar()))
            return when (fc) {
                "DXT1" -> Info(w, h, "BC1", 128, 0, noMask) to null
                "DXT2", "DXT3" -> Info(w, h, "BC2", 128, 0, noMask) to null
                "DXT4", "DXT5" -> Info(w, h, "BC3", 128, 0, noMask) to null
                "ATI2", "BC5U" -> Info(w, h, "BC5", 128, 0, noMask) to null
                "DX10" -> {
                    if (b.size < 148) return null to "обрізаний DX10-заголовок"
                    when (val f = le32(b, 128)) {
                        71, 72 -> Info(w, h, "BC1", 148, 0, noMask) to null
                        74, 75 -> Info(w, h, "BC2", 148, 0, noMask) to null
                        77, 78 -> Info(w, h, "BC3", 148, 0, noMask) to null
                        83, 84 -> Info(w, h, "BC5", 148, 0, noMask) to null
                        87, 91 -> Info(w, h, "RAW", 148, 4, intArrayOf(0xFF0000, 0xFF00, 0xFF, -16777216)) to null
                        28, 29 -> Info(w, h, "RAW", 148, 4, intArrayOf(0xFF, 0xFF00, 0xFF0000, -16777216)) to null
                        98, 99 -> null to "BC7 (DXGI $f) не підтримується"
                        else -> null to "DXGI формат $f не підтримується"
                    }
                }
                else -> null to "формат $fc не підтримується"
            }
        }
        if (pf and 0x40 != 0 && (bits == 32 || bits == 24)) {
            val m = intArrayOf(le32(b, 92), le32(b, 96), le32(b, 100), if (pf and 1 != 0) le32(b, 104) else 0)
            return Info(w, h, "RAW", 128, bits / 8, m) to null
        }
        return null to "невідомий піксельний формат DDS"
    }

    /** Швидка перевірка за заголовком (без повного декодування). */
    fun probe(b: ByteArray): String? = parse(b).second

    fun decode(b: ByteArray, maxTex: Int = 0): Result {
        val (info, err) = parse(b)
        if (info == null) return Result(null, err)
        val w = info.w; val h = info.h
        val need = when (info.kind) {
            "BC1" -> ((w + 3) / 4).toLong() * ((h + 3) / 4) * 8
            "RAW" -> w.toLong() * h * info.bpp
            else -> ((w + 3) / 4).toLong() * ((h + 3) / 4) * 16
        }
        if (b.size - info.off < need) return Result(null, "файл обрізаний")
        val px = try {
            if (info.kind == "RAW") decodeRaw(b, info) else decodeBlocks(b, info)
        } catch (e: OutOfMemoryError) { return Result(null, "не вистачає пам'яті для ${w}x$h") }
        var opaque = true
        for (v in px) if ((v ushr 24) != 255) { opaque = false; break }
        var bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        if (maxTex > 0 && maxOf(w, h) > maxTex) {
            val sc = maxTex.toFloat() / maxOf(w, h)
            val nb = Bitmap.createScaledBitmap(bmp, maxOf(1, (w * sc).toInt()), maxOf(1, (h * sc).toInt()), true)
            bmp.recycle(); bmp = nb
        }
        bmp.setHasAlpha(!opaque)
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
        val rw = bmp.width; val rh = bmp.height
        bmp.recycle()
        return Result(bo.toByteArray(), null, rw, rh)
    }

    private fun argb(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b

    private fun decodeRaw(b: ByteArray, i: Info): IntArray {
        val out = IntArray(i.w * i.h)
        var p = i.off
        fun ch(v: Int, mask: Int, def: Int): Int {
            if (mask == 0) return def
            val sh = Integer.numberOfTrailingZeros(mask)
            val n = Integer.bitCount(mask)
            return (((v and mask) ushr sh) * 255) / ((1 shl n) - 1)
        }
        for (k in out.indices) {
            var v = 0
            for (j in 0 until i.bpp) v = v or ((b[p + j].toInt() and 255) shl (8 * j))
            p += i.bpp
            out[k] = argb(ch(v, i.masks[3], 255), ch(v, i.masks[0], 0), ch(v, i.masks[1], 0), ch(v, i.masks[2], 0))
        }
        return out
    }

    private fun color(b: ByteArray, o: Int, bc1: Boolean, px: IntArray) {
        val c0 = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
        val c1 = (b[o + 2].toInt() and 255) or ((b[o + 3].toInt() and 255) shl 8)
        val r0 = ((c0 shr 11) and 31) * 255 / 31; val g0 = ((c0 shr 5) and 63) * 255 / 63; val b0 = (c0 and 31) * 255 / 31
        val r1 = ((c1 shr 11) and 31) * 255 / 31; val g1 = ((c1 shr 5) and 63) * 255 / 63; val b1 = (c1 and 31) * 255 / 31
        val pal = IntArray(4)
        pal[0] = argb(255, r0, g0, b0); pal[1] = argb(255, r1, g1, b1)
        if (c0 > c1 || !bc1) {
            pal[2] = argb(255, (2 * r0 + r1) / 3, (2 * g0 + g1) / 3, (2 * b0 + b1) / 3)
            pal[3] = argb(255, (r0 + 2 * r1) / 3, (g0 + 2 * g1) / 3, (b0 + 2 * b1) / 3)
        } else {
            pal[2] = argb(255, (r0 + r1) / 2, (g0 + g1) / 2, (b0 + b1) / 2)
            pal[3] = 0
        }
        var bits = le32(b, o + 4)
        for (i in 0 until 16) { px[i] = pal[bits and 3]; bits = bits ushr 2 }
    }

    private fun alphaBlock(b: ByteArray, o: Int, out: IntArray) {
        val a0 = b[o].toInt() and 255; val a1 = b[o + 1].toInt() and 255
        val t = IntArray(8); t[0] = a0; t[1] = a1
        if (a0 > a1) { for (i in 1..6) t[i + 1] = ((7 - i) * a0 + i * a1) / 7 }
        else { for (i in 1..4) t[i + 1] = ((5 - i) * a0 + i * a1) / 5; t[6] = 0; t[7] = 255 }
        var bits = 0L
        for (i in 0 until 6) bits = bits or ((b[o + 2 + i].toLong() and 255L) shl (8 * i))
        for (i in 0 until 16) { out[i] = t[(bits and 7L).toInt()]; bits = bits ushr 3 }
    }

    private fun decodeBlocks(b: ByteArray, info: Info): IntArray {
        val w = info.w; val h = info.h
        val out = IntArray(w * h)
        val bw = (w + 3) / 4; val bh = (h + 3) / 4
        val bs = if (info.kind == "BC1") 8 else 16
        val px = IntArray(16); val a = IntArray(16); val a2 = IntArray(16)
        var p = info.off
        for (by in 0 until bh) for (bx in 0 until bw) {
            when (info.kind) {
                "BC1" -> color(b, p, true, px)
                "BC2" -> {
                    color(b, p + 8, false, px)
                    for (i in 0 until 8) {
                        val v = b[p + i].toInt() and 255
                        a[i * 2] = (v and 15) * 17; a[i * 2 + 1] = (v shr 4) * 17
                    }
                    for (i in 0 until 16) px[i] = (px[i] and 0xFFFFFF) or (a[i] shl 24)
                }
                "BC3" -> {
                    color(b, p + 8, false, px); alphaBlock(b, p, a)
                    for (i in 0 until 16) px[i] = (px[i] and 0xFFFFFF) or (a[i] shl 24)
                }
                else -> { // BC5: нормалі, B відновлюється
                    alphaBlock(b, p, a); alphaBlock(b, p + 8, a2)
                    for (i in 0 until 16) {
                        val nx = a[i] / 127.5 - 1.0; val ny = a2[i] / 127.5 - 1.0
                        val nz = sqrt(max(0.0, 1.0 - nx * nx - ny * ny))
                        px[i] = argb(255, a[i], a2[i], ((nz * 0.5 + 0.5) * 255).toInt())
                    }
                }
            }
            for (j in 0 until 4) for (i in 0 until 4) {
                val x = bx * 4 + i; val y = by * 4 + j
                if (x < w && y < h) out[y * w + x] = px[j * 4 + i]
            }
            p += bs
        }
        return out
    }
}
