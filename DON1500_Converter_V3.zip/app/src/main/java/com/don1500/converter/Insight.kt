package com.don1500.converter

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Локальний аналіз файлу будь-якого розміру: AI отримує стислий звіт і фрагменти з помилками, а не весь файл. */
object Insight {
    private val TEXTY = setOf("lua", "txt", "log", "md", "ini", "cfg", "json")
    private val NODE_TAGS = setOf("TransformGroup", "Shape", "Light", "Camera", "AudioSource")

    fun analyze(f: File): String = try {
        val ext = f.extension.lowercase()
        when {
            ext in TEXTY -> textInsight(f)
            ext == "xml" || ext == "i3d" -> xmlInsight(f)
            else -> "size=${Fs.human(f.length())}; format .$ext is not analysed (binary/unknown)"
        }
    } catch (e: Exception) { "analysis failed: ${e.message}" }

    private fun textInsight(f: File): String {
        val len = f.length()
        RandomAccessFile(f, "r").use { r ->
            val n = minOf(3000L, len).toInt()
            val head = ByteArray(n); r.readFully(head)
            val sb = StringBuilder("size=${Fs.human(len)}\n[HEAD]\n").append(String(head, Charsets.UTF_8))
            if (len > 6000) {
                val tail = ByteArray(3000); r.seek(len - 3000); r.readFully(tail)
                sb.append("\n[...]\n[TAIL]\n").append(String(tail, Charsets.UTF_8))
            }
            return sb.toString()
        }
    }

    private class Ref(val value: String, val line: Int)

    private fun readLines(f: File, want: Set<Int>): Map<Int, String> {
        val out = HashMap<Int, String>()
        if (want.isEmpty()) return out
        val max = want.max()
        f.bufferedReader().useLines { seq ->
            var n = 0
            for (l in seq) { n++; if (n in want) out[n] = l.trim().take(260); if (n >= max) break }
        }
        return out
    }

    private fun findModRoot(f: File): File? {
        var d: File? = f.parentFile; var k = 0
        while (d != null && k < 6) { if (File(d, "modDesc.xml").exists()) return d; d = d.parentFile; k++ }
        return null
    }

    private fun xmlInsight(f: File): String {
        val tags = HashMap<String, Int>()
        var elements = 0; var depth = 0; var maxDepth = 0
        var root = ""
        val fileDefs = HashMap<String, Int>()
        val dupFiles = ArrayList<Pair<String, Int>>()
        val idDefs = HashMap<String, Int>()
        val dups = ArrayList<Pair<String, Int>>()
        val fileRefs = ArrayList<Ref>()
        val pathRefs = ArrayList<Ref>()
        var ddsRefs = 0
        var parseError: String? = null
        var errLine = -1
        val p = Xml.newPullParser()
        try {
            p.setInput(BufferedInputStream(FileInputStream(f), 1 shl 16), null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    elements++; depth++; if (depth > maxDepth) maxDepth = depth
                    val name = p.name
                    if (root.isEmpty()) root = name
                    tags[name] = (tags[name] ?: 0) + 1
                    val line = p.lineNumber
                    for (i in 0 until p.attributeCount) {
                        val an = p.getAttributeName(i); val av = p.getAttributeValue(i)
                        if (an.lowercase().endsWith("filename")) {
                            if (pathRefs.size < 4000) pathRefs += Ref(av, line)
                            if (av.endsWith(".dds", true)) ddsRefs++
                        } else if (an == "fileId") {
                            if (name == "File") { if (fileDefs.containsKey(av)) dupFiles += av to line else fileDefs[av] = line }
                            else if (fileRefs.size < 6000) fileRefs += Ref(av, line)
                        } else if ((an == "materialId" && name == "Material") || (an == "nodeId" && name in NODE_TAGS)) {
                            val k = "$an=$av"
                            val first = idDefs[k]
                            if (first != null) { if (dups.size < 200) dups += "$k (first at line $first)" to line } else idDefs[k] = line
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG) depth--
                ev = p.next()
            }
        } catch (e: XmlPullParserException) { parseError = e.message; errLine = p.lineNumber }
        catch (e: IOException) { parseError = e.message }

        val dangling = fileRefs.filter { it.value !in fileDefs }
        val base = f.parentFile
        val modRoot = findModRoot(f)
        val missing = ArrayList<Ref>()
        val seen = HashSet<String>()
        for (r in pathRefs) {
            val v = r.value
            if (v.isBlank() || v.contains('$') || v.contains("://") || !seen.add(v)) continue
            val ok = File(base, v).exists() || (modRoot != null && File(modRoot, v).exists()) ||
                (v.endsWith(".png", true) && (File(base, v.dropLast(4) + ".dds").exists() || (modRoot != null && File(modRoot, v.dropLast(4) + ".dds").exists())))
            if (!ok && missing.size < 80) missing += r
        }
        val want = HashSet<Int>()
        if (errLine > 0) for (d in -2..2) if (errLine + d > 0) want += errLine + d
        dupFiles.take(8).forEach { want += it.second }
        dups.take(8).forEach { want += it.second }
        dangling.take(8).forEach { want += it.line }
        missing.take(15).forEach { want += it.line }
        val snip = readLines(f, want)
        fun at(l: Int) = "  [$l] ${snip[l] ?: ""}"

        val sb = StringBuilder()
        sb.append("size=${Fs.human(f.length())}; root=<$root>; elements=$elements; maxDepth=$maxDepth\n")
        sb.append("top tags: " + tags.entries.sortedByDescending { it.value }.take(12).joinToString(", ") { "${it.key}=${it.value}" } + "\n")
        if (parseError != null) {
            sb.append("XML PARSE ERROR at line $errLine: $parseError\n")
            for (d in -2..2) if (snip.containsKey(errLine + d)) sb.append(at(errLine + d)).append('\n')
        } else sb.append("XML is well-formed\n")
        if (dupFiles.isNotEmpty()) { sb.append("DUPLICATE <File fileId>: ${dupFiles.size}\n"); dupFiles.take(8).forEach { sb.append("  fileId=${it.first}\n").append(at(it.second)).append('\n') } }
        if (dups.isNotEmpty()) { sb.append("DUPLICATE ids: ${dups.size}\n"); dups.take(8).forEach { sb.append("  ${it.first}\n").append(at(it.second)).append('\n') } }
        if (dangling.isNotEmpty()) { sb.append("fileId REFERENCES TO UNDEFINED <File>: ${dangling.size}\n"); dangling.take(8).forEach { sb.append("  fileId=${it.value}\n").append(at(it.line)).append('\n') } }
        if (missing.isNotEmpty()) { sb.append("MISSING referenced files: ${missing.size}\n"); missing.take(15).forEach { sb.append("  ${it.value}\n").append(at(it.line)).append('\n') } }
        if (ddsRefs > 0) sb.append("references to .dds: $ddsRefs (FS26 Mobile expects .png)\n")
        if (parseError == null && dupFiles.isEmpty() && dups.isEmpty() && dangling.isEmpty() && missing.isEmpty()) sb.append("no structural problems found by local checks\n")
        return sb.toString().take(9000)
    }
}

/** Застосування виправлень від AI: блоки ```patch з рядками FIND:/REPLACE: (потокова заміна, з резервною копією). */
object PatchTool {
    class Patch(val find: String, val replace: String)

    fun parse(text: String): List<Patch> {
        val out = ArrayList<Patch>()
        Regex("(?s)```patch\\s*\\n(.*?)```").findAll(text).forEach { m ->
            var find: String? = null
            for (line in m.groupValues[1].lines()) {
                if (line.startsWith("FIND:")) find = line.removePrefix("FIND:").removePrefix(" ")
                else if (line.startsWith("REPLACE:")) {
                    val fnd = find
                    if (fnd != null) { out += Patch(fnd, line.removePrefix("REPLACE:").removePrefix(" ")); find = null }
                }
            }
        }
        return out.filter { it.find.isNotEmpty() }
    }

    fun apply(f: File, patches: List<Patch>): String {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val crlf = f.inputStream().use { i ->
            val b = ByteArray(8192); val n = i.read(b)
            n > 0 && String(b, 0, n, Charsets.ISO_8859_1).contains("\r\n")
        }
        val sep = if (crlf) "\r\n" else "\n"
        val tmp = File(f.parentFile, f.name + ".tmp")
        var total = 0
        f.bufferedReader().use { r ->
            tmp.bufferedWriter().use { w ->
                while (true) {
                    var l = r.readLine() ?: break
                    for (p in patches) {
                        if (l.contains(p.find)) { total += l.split(p.find).size - 1; l = l.replace(p.find, p.replace) }
                    }
                    w.write(l); w.write(sep)
                }
            }
        }
        if (total == 0) { tmp.delete(); return "✖ " + tr("Нічого не змінено: фрагменти не знайдено у файлі", "Ничего не изменено: фрагменты не найдены в файле") }
        f.copyTo(File(f.parentFile, f.name + ".bak_" + ts), overwrite = true)
        f.delete()
        if (!tmp.renameTo(f)) return "✖ rename failed"
        return "✔ " + tr("Замін: $total. Резервна копія: ${f.name}.bak_$ts", "Замен: $total. Резервная копия: ${f.name}.bak_$ts")
    }
}

/** Створення modDesc.xml для архіву без нього (дані гри / розпакована карта) за знайденим map.xml. */
object Repack {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** Повертає (текст modDesc, кореневий префікс) або null, якщо map.xml немає. */
    fun synthesize(names: List<String>, srcName: String): Pair<String, Pair<String, String?>>? {
        val clean = names.map { it.replace('\\', '/').trimStart('/') }.filter { !it.startsWith("__MACOSX/") }
        val mp0 = clean.filter { it.substringAfterLast('/').equals("map.xml", true) }.minByOrNull { p -> p.count { it == '/' } } ?: return null
        var root = ""
        var cur = clean
        while (cur.isNotEmpty() && cur.all { it.contains('/') } && cur.map { it.substringBefore('/') }.distinct().size == 1) {
            val seg = cur[0].substringBefore('/')
            root = if (root.isEmpty()) seg else "$root/$seg"
            cur = cur.map { it.substringAfter('/') }
        }
        val rel = if (root.isEmpty()) mp0 else mp0.removePrefix("$root/")
        val dir = rel.substringBeforeLast('/', "")
        val relSet = clean.map { (if (root.isEmpty()) it else it.removePrefix("$root/")).lowercase() }.toSet()
        fun has(p: String) = p.lowercase() in relSet
        fun inDir(sub: String) = if (dir.isEmpty()) sub else "$dir/$sub"
        val base = srcName.substringBeforeLast('.').replace(Regex("(?i)^FS(25|26|23)[_ ]?"), "")
        val title = esc(base.replace('_', ' ').trim().ifEmpty { "Map" })
        val id = "map" + base.replace(Regex("[^A-Za-z0-9]"), "").ifEmpty { "Mod" }
        val iconRe = Regex("(overview|icon|preview)", RegexOption.IGNORE_CASE)
        val iconExt = setOf("png", "dds", "jpg")
        val inTree = clean.map { (if (root.isEmpty()) it else it.removePrefix("$root/")) }
            .filter { it.startsWith(if (dir.isEmpty()) "" else "$dir/") && it.substringAfterLast('.', "").lowercase() in iconExt }
        fun score(p: String): Int {
            val name = p.substringAfterLast('/')
            var s = 0
            if (iconRe.containsMatchIn(name)) s += 10
            if (name.substringAfterLast('.').equals("png", true)) s += 2
            if (p.substringBeforeLast('/', "") == dir) s += 3
            return s
        }
        val icon = inTree.filter { iconRe.containsMatchIn(it.substringAfterLast('/')) }.maxByOrNull { score(it) }
            ?: listOf("overview.png", "icon_Map.png", "preview.png", "icon.png", "overview.dds", "icon.dds").flatMap { listOf(it, inDir(it)) }.firstOrNull { has(it) }
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\"?>\n<modDesc descVersion=\"2\" titleId=\"fs26mobile\">\n")
        sb.append("    <author>DON-1500 Converter</author>\n    <version>1.0.0.0</version>\n")
        sb.append("    <title>\n        <en>$title</en>\n    </title>\n    <description>\n        <en>$title</en>\n    </description>\n")
        if (icon != null) sb.append("    <iconFilename>$icon</iconFilename>\n")
        else sb.append("    <!-- DON1500: icon not found automatically, add iconFilename manually if the map does not appear correctly -->\n")
        sb.append("    <multiplayer supported=\"false\" only=\"false\"/>\n    <maps>\n")
        sb.append("        <map id=\"$id\" className=\"Mission00\" filename=\"\$dataS/scripts/mission00.lua\" configFilename=\"$rel\"")
        if (has(inDir("config/vehicles.xml"))) sb.append(" defaultVehiclesXMLFilename=\"${inDir("config/vehicles.xml")}\"")
        if (has(inDir("config/handtools.xml"))) sb.append(" defaultHandToolsXMLFilename=\"${inDir("config/handtools.xml")}\"")
        if (has(inDir("config/placeables.xml"))) sb.append(" defaultPlaceablesXMLFilename=\"${inDir("config/placeables.xml")}\"")
        if (has(inDir("config/items.xml"))) sb.append(" defaultItemsXMLFilename=\"${inDir("config/items.xml")}\"")
        sb.append(">\n            <title>\n                <en>$title</en>\n            </title>\n            <description>\n                <en>$title</en>\n            </description>\n")
        if (icon != null) sb.append("            <iconFilename>$icon</iconFilename>\n")
        sb.append("        </map>\n    </maps>\n</modDesc>\n")
        return sb.toString() to (root to icon)
    }
}
