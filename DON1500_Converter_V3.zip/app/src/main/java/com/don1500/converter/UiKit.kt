@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private fun fmtT(s: Long) = if (s < 60) "$s ${tr("с", "с")}" else "${s / 60} ${tr("хв", "мин")} ${s % 60} ${tr("с", "с")}"

/** «Бігова доріжка»: відсотки, час і «Скасувати» видно на будь-якому екрані, поки йде конвертація. */
@Composable
fun ConvBanner(onClick: () -> Unit, modifier: Modifier = Modifier) {
    if (!ConvJob.busy && !ConvJob.done) return
    val now by produceState(System.currentTimeMillis(), ConvJob.busy) {
        while (ConvJob.busy) { value = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) }
    }
    val pct = (ConvJob.prog * 100).toInt().coerceIn(0, 100)
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (ConvJob.busy) {
                    Text("$pct%", fontWeight = FontWeight.Black, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(ConvJob.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val el = ((now - ConvJob.startMs) / 1000).coerceAtLeast(0)
                        val eta = if (ConvJob.prog > 0.02f) (el * (1 - ConvJob.prog) / ConvJob.prog).toLong() else -1L
                        Text(
                            tr("Минуло ", "Прошло ") + fmtT(el) + (if (eta >= 0) tr(" · залишилось ~", " · осталось ~") + fmtT(eta) else ""),
                            fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                        )
                    }
                    IconButton(onClick = { ConvJob.cancelFlag.set(true); ConvJob.cur = tr("Скасовую…", "Отменяю…") }, modifier = Modifier.size(34.dp)) { Icon(Icons.Filled.Close, null) }
                } else {
                    val bad = Session.report?.critical == true
                    Text(
                        (if (bad) "⚠ " else "✔ ") + tr("Готово: ", "Готово: ") + ConvJob.label +
                            (if (bad) tr(" — є проблеми, див. звіт", " — есть проблемы, см. отчёт") else ""),
                        Modifier.weight(1f), fontSize = 12.sp, maxLines = 2
                    )
                    IconButton(onClick = { ConvJob.dismiss() }, modifier = Modifier.size(34.dp)) { Icon(Icons.Filled.Close, null) }
                }
            }
            if (ConvJob.busy) {
                LinearProgressIndicator(progress = { ConvJob.prog }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                Text(ConvJob.cur, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun canWriteTo(dir: File): Boolean = try {
    val t = File(dir, ".don_write_test")
    t.writeText("x"); t.delete()
} catch (e: Exception) { false }

/** Вибір папки для збереження результатів (потрібен «Доступ до всіх файлів»). */
@Composable
fun FolderPickerDialog(startPath: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val root = remember { Environment.getExternalStorageDirectory() }
    var dir by remember {
        mutableStateOf(File(startPath.ifBlank { File(root, "Download").absolutePath }).let { if (it.isDirectory) it else root })
    }
    var tick by remember { mutableStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val hasAll = remember(tick) { Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager() }
    val subs = remember(dir, tick) {
        dir.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name.lowercase() } ?: emptyList()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Куди зберігати файли", "Куда сохранять файлы")) },
        text = {
            Column {
                Text(dir.absolutePath, fontSize = 12.sp, maxLines = 2, color = MaterialTheme.colorScheme.primary)
                if (!hasAll) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Потрібен «Доступ до всіх файлів»", "Нужен «Доступ ко всем файлам»"), Modifier.weight(1f), fontSize = 11.sp)
                    TextButton(onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }
                        catch (e: Exception) { try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) { } }
                    }) { Text(tr("Дати", "Дать")) }
                    TextButton(onClick = { tick++ }) { Text(tr("Перевірити", "Проверить")) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(onClick = { dir = root; err = "" }, label = { Text("Root", fontSize = 11.sp) })
                    AssistChip(onClick = { dir = File(root, "Download"); err = "" }, label = { Text("Download", fontSize = 11.sp) })
                    AssistChip(onClick = { dir = File(root, "Documents"); err = "" }, label = { Text("Documents", fontSize = 11.sp) })
                    AssistChip(onClick = { dir = File(root, "Android/media"); err = "" }, label = { Text("Android/media", fontSize = 11.sp) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { dir.parentFile?.let { dir = it; err = "" } }) { Icon(Icons.Filled.ArrowUpward, null) }
                    Text(tr("Вгору", "Вверх"), Modifier.weight(1f), fontSize = 12.sp)
                    IconButton(onClick = { creating = !creating }) { Icon(Icons.Filled.CreateNewFolder, null) }
                }
                if (creating) Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newName, { newName = it }, Modifier.weight(1f), singleLine = true, label = { Text(tr("Нова папка", "Новая папка")) })
                    TextButton(onClick = {
                        val n = newName.trim().replace("/", "_")
                        if (n.isNotEmpty()) {
                            val f = File(dir, n)
                            if (f.mkdirs() || f.isDirectory) { dir = f; newName = ""; creating = false; err = "" } else err = tr("Не вдалося створити папку", "Не удалось создать папку")
                        }
                    }) { Text("OK") }
                }
                LazyColumn(Modifier.height(240.dp)) {
                    items(subs, key = { it.absolutePath }) { f ->
                        Row(Modifier.fillMaxWidth().clickable { dir = f; err = "" }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.secondary)
                            Text(f.name, Modifier.padding(start = 10.dp), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (subs.isEmpty()) item { Text(tr("Підпапок немає", "Подпапок нет"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                if (err.isNotEmpty()) Text(err, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                Text(
                    tr("Android/data (папка модів гри) з Android 11 закрита системою — туди програма записати не може. Збережіть сюди, а далі перенесіть файловим менеджером з доступом.",
                        "Android/data (папка модов игры) с Android 11 закрыта системой — туда приложение записать не может. Сохраните сюда, а дальше перенесите файловым менеджером с доступом."),
                    fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (canWriteTo(dir)) onPick(dir.absolutePath)
                else err = tr("У цю папку не можна записувати (немає дозволу або вона закрита Android)", "В эту папку нельзя записывать (нет разрешения или она закрыта Android)")
            }) { Text(tr("Вибрати цю папку", "Выбрать эту папку")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Отмена")) } }
    )
}

/** Рядок «Куди зберігати» з кнопками; використовується в Конвертері й Налаштуваннях. */
@Composable
fun OutFolderRow(store: Store) {
    var pick by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(tr("Куди зберігати результат", "Куда сохранять результат"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(OutPref.path.ifBlank { "Download/DON1500" }, fontSize = 11.sp, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { pick = true }) { Text(tr("Змінити", "Изменить")) }
            if (OutPref.path.isNotBlank()) TextButton(onClick = { OutPref.setPath(store, "") }) { Text(tr("Скинути", "Сбросить")) }
        }
        if (OutPref.path.isNotBlank()) Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Окрема підпапка для кожного мода (і звіти)", "Отдельная подпапка для каждого мода (и отчёты)"), Modifier.weight(1f), fontSize = 11.sp)
            Switch(OutPref.sub, { OutPref.setSub(store, it) })
        }
    }
    if (pick) FolderPickerDialog(OutPref.path, onPick = { OutPref.setPath(store, it); pick = false }, onDismiss = { pick = false })
}

/** Вибір будь-якого кольору: готові кружечки, повзунки (відтінок / насиченість / яскравість) і HEX. */
@Composable
fun ColorPickerDialog(initialHex: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val init = remember {
        try { android.graphics.Color.parseColor(initialHex) } catch (e: Exception) { 0xFFFF4A3D.toInt() }
    }
    val hsv0 = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(init, it) } }
    var h by remember { mutableStateOf(hsv0[0]) }
    var s by remember { mutableStateOf(hsv0[1]) }
    var v by remember { mutableStateOf(hsv0[2]) }
    val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
    var hexText by remember { mutableStateOf("#%06X".format(argb and 0xFFFFFF)) }
    fun setFrom(c: Int) {
        val a = FloatArray(3); android.graphics.Color.colorToHSV(c, a)
        h = a[0]; s = a[1]; v = a[2]; hexText = "#%06X".format(c and 0xFFFFFF)
    }
    val presets = listOf(0xFFFF4A3D, 0xFFFF9800, 0xFFFFC107, 0xFF8BC34A, 0xFF3DDC84, 0xFF00BCD4, 0xFF3D8BFF, 0xFF3F51B5, 0xFF9B5CFF, 0xFFE91E63, 0xFFFFFFFF, 0xFF9E9E9E)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Свій колір теми", "Свой цвет темы")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(argb)))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { c ->
                        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            .clickable { setFrom(c.toInt()) })
                    }
                }
                Text(tr("Відтінок", "Оттенок"), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                Slider(h, { h = it; hexText = "#%06X".format(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) and 0xFFFFFF) }, valueRange = 0f..360f)
                Text(tr("Насиченість", "Насыщенность"), fontSize = 12.sp)
                Slider(s, { s = it; hexText = "#%06X".format(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) and 0xFFFFFF) }, valueRange = 0f..1f)
                Text(tr("Яскравість", "Яркость"), fontSize = 12.sp)
                Slider(v, { v = it; hexText = "#%06X".format(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) and 0xFFFFFF) }, valueRange = 0.15f..1f)
                OutlinedTextField(
                    hexText, { t ->
                        hexText = t
                        val x = t.trim().removePrefix("#")
                        if (x.length == 6 && x.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) setFrom((0xFF000000L or x.toLong(16)).toInt()).also { hexText = t }
                    },
                    Modifier.fillMaxWidth(), singleLine = true, label = { Text("HEX (#RRGGBB)") }
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick("#%06X".format(argb and 0xFFFFFF)) }) { Text(tr("Застосувати", "Применить")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Скасувати", "Отмена")) } }
    )
}
