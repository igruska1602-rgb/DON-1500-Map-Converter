package com.don1500.converter

import java.io.File
import java.util.zip.ZipFile

/** Для цілі FS22→FS23 донори беруться з бібліотеки FS23. */
fun donorTarget(t: String) = if (t == "FS22") "FS23" else t

/**
 * Правила перенесення карти FS22 → FS23 Mobile.
 * Джерело: інструкція «Перенесення карти FS22 у FS23 Mobile (Android, KNW)».
 * Реалізовано лише те, що в інструкції описано однозначно. Усе, що вимагає рішення людини
 * або оригінального файлу гри, виводиться у звіт як попередження.
 */
object Fs23Rules {
    private const val D = "\$data"

    private val mapDirRe = Regex(Regex.escape("$D/maps/") + "(?:mapUS|mapFR|mapAlpine)/")
    private val terrRe = Regex(Regex.escape("$D/maps/") + "(?:map/)?textures/terrain/([A-Za-z]+\\d+)_(diffuse|normal)\\.(?:png|dds)")
    private val ddsDataRe = Regex("(" + Regex.escape("$D/") + "[^\"'<>\\s]*?)\\.dds", RegexOption.IGNORE_CASE)
    private val dataRefRe = Regex(Regex.escape("$D/") + "[^\"'<>\\s]+")
    private val bldRe = Regex(
        "(" + Regex.escape("$D/maps/") + "(?:map/)?textures/)" +
            "(chimney03|concreteRoadBlock0\\d|barricadeMedium|barricadeSmall|electricityHut|bucketGalvanized|chainlinkFence|railroadStorage02_0\\d|railwayBridge03)" +
            "(_[A-Za-z]+\\.(?:png|dds))"
    )

    private val foliage = listOf(
        "$D/foliage/decoFoliage/decoFoliageUS.xml" to "$D/foliage/decoFoliage/decoFoliage.xml",
        "$D/foliage/decoFoliage/decoFoliageFR.xml" to "$D/foliage/decoFoliage/decoFoliage.xml",
        "$D/foliage/decoBush/decoBushFR.xml" to "$D/foliage/decoBush/decoBush.xml",
        "$D/foliage/meadow/meadowDLC.xml" to "$D/foliage/meadow/meadowUS.xml",
        "$D/foliage/meadow/meadowFR.xml" to "$D/foliage/meadow/meadowUS.xml",
        "$D/foliage/groundFoliage/groundFoliage.xml" to "$D/foliage/decoFoliage/decoFoliage.xml"
    )

    private val distance = listOf(
        Regex("(ground/)(?:lime|liquidManure|manure)_distance_diffuse") to "fertilizer_distance_diffuse",
        Regex("(ground/)maizeChopper_distance_diffuse") to "harvestReady_distance_diffuse",
        Regex("(ground/)straw_distance_diffuse") to "stubbleTillage_distance_diffuse"
    )

    private val helpIds = listOf(
        "helpLine_FirstSteps_Shop", "helpLine_FirstSteps_Farmer", "helpLine_ImproveYield_Fertilizing",
        "helpLine_Animals_General", "helpLine_CropOverview_GrapesOlives"
    )

    const val STARTER_VEHICLES = """<?xml version="1.0" encoding="utf-8" standalone="no" ?>
<vehicles>
    <vehicle filename="data/vehicles/johnDeere/series4755/series4755.xml" id="1" farmId="1" propertyState="1" xPosition="12.0" yOffset="0.5" zPosition="30.0" yRotation="-90" defaultFarmProperty="true" />
    <vehicle filename="data/vehicles/kverneland/ecomat/ecomat.xml" id="2" farmId="1" propertyState="1" xPosition="16.5" yOffset="0.5" zPosition="30.0" yRotation="-90" defaultFarmProperty="true" />
    <attachments rootVehicleId="1">
        <attachment attachmentId="2" inputJointDescIndex="1" jointIndex="1" moveDown="false"/>
    </attachments>
</vehicles>
"""

    /** Єдина частина MapFrameFix.lua, яка є в інструкції повністю (далі файл інструкції обірвано). */
    const val MAP_FRAME_FIX = """-- MapFrameFix: захист екрана карти (FS22 -> FS23 Mobile)
local C = InGameMenuMobileMapFrame
if C ~= nil and C.getNumberOfItemsInSection ~= nil then
    local orig = C.getNumberOfItemsInSection
    C.getNumberOfItemsInSection = function(self, ...)
        local ok, res = pcall(orig, self, ...)
        if ok and type(res) == "number" then return res end
        return 0
    end
end
"""

    fun isCache(rel: String): Boolean {
        val l = rel.lowercase()
        return l.contains(".i3d.terrain.") && l.endsWith(".cache")
    }

    private fun count(t: String, s: String): Int { var n = 0; var i = t.indexOf(s); while (i >= 0) { n++; i = t.indexOf(s, i + s.length) }; return n }

    private fun terrainName(n: String): String {
        val l = n.lowercase()
        val d = l.filter { it.isDigit() }.toIntOrNull() ?: 1
        val nn = "%02d".format(d.coerceIn(1, 3))
        return when {
            l.startsWith("concrete") || l.startsWith("asphalt") -> "asphalt$nn"
            l == "dirt01" -> "dirt01"
            l.startsWith("dirt") || l.startsWith("forestground") || l.startsWith("grassdirt") -> "dirt01"
            l == "grass04" -> "grass03"
            l.startsWith("grass") -> "grass$nn"
            l == "gravel01" || l == "gravel02" || l == "gravel03" -> "gravel$nn"
            l.startsWith("animalmud") -> "animalMud$nn"
            l.startsWith("mountainrock") -> n
            else -> "gravel01"
        }
    }

    private fun bldName(n: String): String = when {
        n == "chimney03" -> "chimney06"
        n.startsWith("concreteRoadBlock") -> "concreteUS02"
        n.startsWith("barricade") -> "barricadeBig"
        n == "electricityHut" -> "electricityShed"
        n == "bucketGalvanized" -> "bucketPlasticBlue"
        n == "chainlinkFence" -> "alpsFence02"
        n.startsWith("railroadStorage02_") -> n.replace("railroadStorage02_", "railroadStorage01_")
        n == "railwayBridge03" -> "roadBridge03"
        else -> n
    }

    /** Текстові правила для xml / i3d. */
    fun fixText(rel: String, text: String, rep: ConvertReport): String {
        var t = text
        val base = rel.substringAfterLast('/')

        // 0. шляхи mapUS / mapFR / mapAlpine → map
        var n = 0
        t = mapDirRe.replace(t) { n++; "$D/maps/map/" }
        if (n > 0) rep.changes += tr("$rel: шляхів mapUS/mapFR/mapAlpine → map: $n", "$rel: путей mapUS/mapFR/mapAlpine → map: $n")

        // 7.2 ground-текстури
        val g = count(t, "$D/maps/textures/terrain/ground/")
        if (g > 0) {
            t = t.replace("$D/maps/textures/terrain/ground/", "$D/maps/map/textures/terrain/ground/")
            rep.changes += tr("$rel: ground-текстури → maps/map/…: $g", "$rel: ground-текстуры → maps/map/…: $g")
        }
        for ((re, to) in distance) {
            var c = 0
            t = re.replace(t) { c++; it.groupValues[1] + to }
            if (c > 0) rep.changes += tr("$rel: distance-текстури замінено на $to: $c", "$rel: distance-текстуры заменены на $to: $c")
        }

        // 7.1 текстури шарів землі
        var c1 = 0
        t = terrRe.replace(t) { m ->
            val nm = terrainName(m.groupValues[1])
            c1++
            "$D/maps/map/textures/terrain/${nm}_${m.groupValues[2]}.png"
        }
        if (c1 > 0) rep.changes += tr("$rel: текстури шарів землі переведено на наявні в FS23: $c1", "$rel: текстуры слоёв земли переведены на имеющиеся в FS23: $c1")

        // 7.3 рослини
        for ((from, to) in foliage) {
            val c = count(t, from)
            if (c > 0) { t = t.replace(from, to); rep.changes += tr("$rel: foliage ${from.substringAfterLast('/')} → ${to.substringAfterLast('/')}: $c", "$rel: foliage ${from.substringAfterLast('/')} → ${to.substringAfterLast('/')}: $c") }
        }

        // 7.5 текстури будівель (лише з таблиці інструкції; якщо донор завантажено — тільки коли новий файл у ньому є)
        var c5 = 0
        t = bldRe.replace(t) { m ->
            val newRef = "$D/maps/map/textures/" + bldName(m.groupValues[2]) + m.groupValues[3].replace(".dds", ".png")
            if (Donor.count > 0 && !Donor.has(newRef)) m.value else { c5++; newRef }
        }
        if (c5 > 0) rep.changes += tr("$rel: текстури будівель замінено на схожі: $c5", "$rel: текстуры зданий заменены на похожие: $c5")

        // .dds → .png у посиланнях на $data (гра сама знаходить .ast)
        var cd = 0
        t = ddsDataRe.replace(t) { cd++; it.groupValues[1] + ".png" }
        if (cd > 0) rep.changes += tr("$rel: \$data-посилань .dds→.png: $cd", "$rel: \$data-ссылок .dds→.png: $cd")

        // Перевірка за індексом гри (якщо завантажено «Дані гри» FS23): підстановки для відсутніх файлів
        if (Donor.count > 0) t = donorRemap(rel, t, rep)

        when (base) {
            "map.xml" -> t = mapXml(rel, t, rep)
            "farmlands.xml" -> t = farmlands(rel, t, rep)
            "trafficSystem.xml" -> {
                val before = t
                t = Regex("\\s+licensePlates\\s*=\\s*\"[^\"]*\"").replace(t, "")
                if (t != before) rep.changes += "$rel: " + tr("прибрано licensePlates", "убран licensePlates")
            }
            "vehicles.xml" -> if (!t.contains("<vehicle ") && !t.contains("<vehicle\n")) {
                t = STARTER_VEHICLES
                rep.changes += "$rel: " + tr("порожній — додано стартову техніку (трактор + плуг)", "пустой — добавлена стартовая техника (трактор + плуг)")
                rep.issues += Issue("WARN", rel, tr("Стартова техніка стоїть у точці X=12 Z=30 — перевірте, що там суша", "Стартовая техника стоит в точке X=12 Z=30 — проверьте, что там суша"))
            }
            "environment.xml", "fieldGround.xml", "weed.xml" ->
                rep.issues += Issue("WARN", rel, tr("Власна копія FS22. Інструкція радить брати оригінал з гри (maps/map/$base), інакше можливі чорне небо / біла земля", "Собственная копия FS22. Инструкция советует брать оригинал из игры (maps/map/$base), иначе возможны чёрное небо / белая земля"))
            "sound.xml" ->
                rep.issues += Issue("WARN", rel, tr("Інструкція радить оригінальний sound.xml з гри, у ньому змінити лише шлях до вашого sounds.i3d", "Инструкция советует оригинальный sound.xml из игры, в нём изменить только путь к вашему sounds.i3d"))
        }
        if (rel.endsWith(".i3d")) t = i3dRules(rel, t, rep)
        return t
    }

    private fun donorRemap(rel: String, text: String, rep: ConvertReport): String {
        val refs = LinkedHashSet<String>()
        dataRefRe.findAll(text).forEach { refs += it.value }
        val map = HashMap<String, String>()
        var maskWarn = 0
        for (r in refs) {
            if (Donor.has(r)) continue
            val cands = ArrayList<String>()
            if (r.startsWith("$D/maps/textures/")) cands += r.replaceFirst("$D/maps/textures/", "$D/maps/map/textures/")
            val low = r.lowercase()
            if (low.contains("/textures/") && low.endsWith(".png")) {
                when {
                    low.endsWith("_normal.png") -> cands += "$D/maps/textures/shared/default_normal.png"
                    low.endsWith("_specular.png") -> cands += "$D/maps/textures/shared/default_specular.png"
                    low.endsWith("_height.png") || low.endsWith("_emissive.png") || low.endsWith("_alpha.png") -> cands += "$D/maps/textures/shared/default_height.png"
                    low.endsWith("_mask.png") -> maskWarn++
                    low.endsWith("_diffuse.png") -> cands += "$D/maps/map/textures/concreteUS02_diffuse.png"
                }
            }
            cands.firstOrNull { Donor.has(it) }?.let { map[r] = it }
        }
        var t = text
        if (map.isNotEmpty()) {
            // довші ключі першими, щоб не зачепити підрядки
            for ((from, to) in map.entries.sortedByDescending { it.key.length }) t = t.replace(from, to)
            rep.changes += tr("$rel: за індексом гри підставлено файлів: ${map.size}", "$rel: по индексу игры подставлено файлов: ${map.size}")
        }
        if (maskWarn > 0) rep.issues += Issue("WARN", rel, tr("Є відсутні _mask-текстури ($maskWarn): заглушкою default_height модель стане чорною — потрібна своя біла картинка", "Есть отсутствующие _mask-текстуры ($maskWarn): заглушкой default_height модель станет чёрной — нужна своя белая картинка"))
        return t
    }

    private fun mapXml(rel: String, text: String, rep: ConvertReport): String {
        var t = text
        // 4.2 licensePlates
        val b1 = t
        t = Regex("[ \\t]*<licensePlates\\b[^>]*?/>[ \\t]*\\r?\\n?").replace(t, "")
        t = Regex("(?s)[ \\t]*<licensePlates\\b[^>]*?>.*?</licensePlates>[ \\t]*\\r?\\n?").replace(t, "")
        if (t != b1) rep.changes += "$rel: " + tr("прибрано licensePlates", "убран licensePlates")
        // 4.4 hotspots → порожній блок (це ж прибирає SHOP_ANIMAL з station_fr_…)
        val b2 = t
        t = Regex("(?s)<hotspots\\b[^>]*?(?:/>|>.*?</hotspots>)").replace(t, "<hotspots/>")
        if (t != b2 && !b2.contains("<hotspots/>")) rep.changes += "$rel: " + tr("hotspots → порожній блок", "hotspots → пустой блок")
        // 4.3 helpline trigger → zone
        var zi = 0
        t = Regex("(?s)<helpline\\b[^>]*>.*?</helpline>").replace(t) { blk ->
            Regex("<trigger\\b([^>]*?)/>").replace(blk.value) { m ->
                val pos = Regex("position\\s*=\\s*\"([^\"]+)\"").find(m.groupValues[1])?.groupValues?.get(1)
                if (pos == null) m.value else { val id = helpIds[zi % helpIds.size]; zi++; "<zone position=\"$pos\" radius=\"50.00\" helpId=\"$id\"/>" }
            }
        }
        if (zi > 0) {
            rep.changes += "$rel: " + tr("helpline: trigger → zone ($zi)", "helpline: trigger → zone ($zi)")
            rep.issues += Issue("WARN", rel, tr("helpId призначено по колу зі списку з інструкції — перевірте, чи підходять підказки", "helpId назначены по кругу из списка инструкции — проверьте, подходят ли подсказки"))
        }
        // 4.5 / 4.7 додаткові рядки перед </map>
        val end = t.lastIndexOf("</map>")
        if (end >= 0) {
            val add = StringBuilder()
            if (!t.contains("<collectibles")) add.append("    <collectibles filename=\"$D/maps/map/collectibles.xml\"/>\n")
            if (!t.contains("<culling")) add.append("    <culling xzOffset=\"100\" clipDistanceThreshold1=\"150\" clipDistanceThreshold2=\"400\"/>\n")
            if (!t.contains("<navigationCollision")) add.append("    <navigationCollision revision=\"2\"/>\n")
            if (add.isNotEmpty()) {
                t = t.substring(0, end) + add + t.substring(end)
                rep.changes += "$rel: " + tr("додано collectibles / culling / navigationCollision", "добавлены collectibles / culling / navigationCollision")
            }
        } else rep.issues += Issue("WARN", rel, tr("Не знайдено </map> — рядки collectibles/culling/navigationCollision не додано", "Не найден </map> — строки collectibles/culling/navigationCollision не добавлены"))
        // 4.6 decoFoliages — потрібен блок із оригінального map.xml гри
        rep.issues += Issue("WARN", rel, tr("decoFoliages: замініть блок на <decoFoliages> з оригінального maps/map/map.xml гри (автоматично не змінювалось)", "decoFoliages: замените блок на <decoFoliages> из оригинального maps/map/map.xml игры (автоматически не менялось)"))
        if (t.contains("decoForest")) rep.issues += Issue("WARN", rel, tr("Знайдено decoForest — в оригіналі FS23 використовується meadow", "Найден decoForest — в оригинале FS23 используется meadow"))
        return t
    }

    private fun farmlands(rel: String, text: String, rep: ConvertReport): String {
        var t = text
        val b = t
        // а) infoLayerName у кореневому теґу
        t = Regex("<farmlands(?=[\\s>])([^>]*)>").replace(t) { m ->
            if (m.groupValues[1].contains("infoLayerName")) m.value else "<farmlands infoLayerName=\"farmlands\"" + m.groupValues[1] + ">"
        }
        // б) defaultFarmProperty="true" у кожну ферму
        t = Regex("<farmland(?=\\s)([^>]*?)(/?)>").replace(t) { m ->
            if (m.groupValues[1].contains("defaultFarmProperty")) m.value
            else "<farmland" + m.groupValues[1].trimEnd() + " defaultFarmProperty=\"true\"" + m.groupValues[2] + ">"
        }
        // npcName → npcIndex
        t = Regex("npcName\\s*=\\s*\"[^\"]*\"").replace(t, "npcIndex=\"1\"")
        if (t != b) rep.changes += "$rel: " + tr("infoLayerName, defaultFarmProperty=\"true\", npcIndex", "infoLayerName, defaultFarmProperty=\"true\", npcIndex")
        return t
    }

    private fun i3dRules(rel: String, text: String, rep: ConvertReport): String {
        var t = text
        val layers = Regex("<Layer\\b").findAll(t).count()
        if (layers > 17) rep.issues += Issue("WARN", rel, tr("Шарів землі: $layers. Для мобільної гри інструкція радить 12–17 (прибрати зайві вручну)", "Слоёв земли: $layers. Для мобильной игры инструкция советует 12–17 (убрать лишние вручную)"))
        if (Regex("FoliageType[^>]*name\\s*=\\s*\"stone\"").containsMatchIn(t))
            rep.issues += Issue("WARN", rel, tr("Є FoliageType «stone» — у FS23 Mobile його немає: видаліть блок FoliageMultiLayer, його File і densityMap_stones.gdm", "Есть FoliageType «stone» — в FS23 Mobile его нет: удалите блок FoliageMultiLayer, его File и densityMap_stones.gdm"))
        if (Regex("oak\\dLOD|oakBranches|oakTrunk|spruce\\dVar\\dLOD|spruceBranch|spruceTrunk").containsMatchIn(t))
            rep.issues += Issue("WARN", rel, tr("Дерева oak/spruce: замініть за таблицею 7.4 (oak→americanElm…, spruce→pine…) вручну — шляхи моделей залежать від вашої карти", "Деревья oak/spruce: замените по таблице 7.4 (oak→americanElm…, spruce→pine…) вручную — пути моделей зависят от вашей карты"))
        // 7.6 група fields
        if (rel.substringAfterLast('/') == "map.i3d" && !Regex("<TransformGroup[^>]*\\bname\\s*=\\s*\"fields\"").containsMatchIn(t)) {
            val scene = t.lastIndexOf("</Scene>")
            val ua = t.lastIndexOf("</UserAttributes>")
            if (scene >= 0 && ua >= 0) {
                val maxId = Regex("nodeId\\s*=\\s*\"(\\d+)\"").findAll(t).mapNotNull { it.groupValues[1].toIntOrNull() }.maxOrNull() ?: 0
                val b = if (maxId < 20001) 20001 else maxId + 1
                val grp = "  <TransformGroup name=\"fields\" nodeId=\"$b\">\n" +
                    "    <TransformGroup name=\"field01\" translation=\"40 69.5 55\" nodeId=\"${b + 1}\">\n" +
                    "      <TransformGroup name=\"fieldDimensions\" translation=\"-50 0 -30\" nodeId=\"${b + 2}\">\n" +
                    "        <TransformGroup name=\"corner01_1\" nodeId=\"${b + 3}\">\n" +
                    "          <TransformGroup name=\"corner01_2\" translation=\"100 0 0\" nodeId=\"${b + 4}\"/>\n" +
                    "          <TransformGroup name=\"corner01_3\" translation=\"100 0 60\" nodeId=\"${b + 5}\"/>\n" +
                    "        </TransformGroup>\n      </TransformGroup>\n" +
                    "      <TransformGroup name=\"fieldMapIndicator\" nodeId=\"${b + 6}\"/>\n    </TransformGroup>\n  </TransformGroup>\n"
                val attrs = "    <UserAttribute nodeId=\"$b\">\n      <Attribute name=\"onCreate\" type=\"scriptCallback\" value=\"FieldUtil.onCreate\"/>\n    </UserAttribute>\n" +
                    "    <UserAttribute nodeId=\"${b + 1}\">\n      <Attribute name=\"fieldAngle\" type=\"integer\" value=\"0\"/>\n      <Attribute name=\"fieldDimensionIndex\" type=\"integer\" value=\"0\"/>\n" +
                    "      <Attribute name=\"fieldGrassMission\" type=\"boolean\" value=\"false\"/>\n      <Attribute name=\"fieldMissionAllowed\" type=\"boolean\" value=\"false\"/>\n" +
                    "      <Attribute name=\"nameIndicatorIndex\" type=\"integer\" value=\"1\"/>\n    </UserAttribute>\n"
                // UserAttributes зазвичай після Scene: вставляємо з кінця, щоб індекси не зсунулись
                t = if (ua > scene) {
                    val s1 = t.substring(0, ua) + attrs + t.substring(ua)
                    s1.substring(0, scene) + grp + s1.substring(scene)
                } else {
                    val s1 = t.substring(0, scene) + grp + t.substring(scene)
                    val ua2 = s1.lastIndexOf("</UserAttributes>")
                    s1.substring(0, ua2) + attrs + s1.substring(ua2)
                }
                rep.changes += "$rel: " + tr("додано групу fields (nodeId $b–${b + 6})", "добавлена группа fields (nodeId $b–${b + 6})")
                rep.issues += Issue("WARN", rel, tr("Група fields — заглушка з інструкції (translation 40 69.5 55): підставте координати свого поля", "Группа fields — заглушка из инструкции (translation 40 69.5 55): подставьте координаты своего поля"))
            }
        }
        return t
    }

    // ---- modDesc ----
    fun donorKnw(donors: List<File>): String? {
        for (d in donors) {
            try {
                ZipFile(d).use { z ->
                    var best: String? = null
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (!e.isDirectory && e.name.substringAfterLast('/') == "modDesc.xml") {
                            val cur = best
                            if (cur == null || e.name.count { it == '/' } < cur.count { it == '/' }) best = e.name
                        }
                    }
                    val b = best
                    if (b != null) {
                        val txt = z.getInputStream(z.getEntry(b)).use { it.readBytes() }.toString(Charsets.UTF_8)
                        Regex("<knw\\b[^>]*?/>").find(txt)?.let { return it.value }
                    }
                }
            } catch (_: Exception) { }
        }
        return null
    }

    /** modDesc.xml → папка карти, напр. «maps/mapFR». */
    fun mapDir(modDesc: String): String? =
        Regex("configFilename\\s*=\\s*\"([^\"]+)/map\\.xml\"").find(modDesc)?.groupValues?.get(1)

    fun fixModDesc(src: String, opt: Options, rep: ConvertReport, modName: String): String {
        var t = src
        val knwRe = Regex("<knw\\b[^>]*?/>")
        val k = knwRe.find(t)
        fun withName(tag: String): String =
            if (Regex("modName\\s*=").containsMatchIn(tag)) Regex("modName\\s*=\\s*\"[^\"]*\"").replace(tag, "modName=\"$modName\"")
            else tag.removeSuffix("/>").trimEnd() + " modName=\"$modName\" />"
        if (k != null) {
            t = t.replaceRange(k.range, withName(k.value))
            rep.changes += "modDesc.xml: " + tr("<knw> modName = $modName (owner і key не чіпали)", "<knw> modName = $modName (owner и key не трогали)")
        } else {
            val dk = donorKnw(opt.donors)
            val m = Regex("<modDesc\\b[^>]*>").find(t)
            if (dk != null && m != null) {
                t = t.substring(0, m.range.last + 1) + "\n    " + withName(dk) + t.substring(m.range.last + 1)
                rep.changes += "modDesc.xml: " + tr("<knw> узято з донора FS23, modName = $modName", "<knw> взят из донора FS23, modName = $modName")
                rep.issues += Issue("WARN", "modDesc.xml", tr("<knw> скопійовано з донора — переконайтесь, що це ваш робочий тег", "<knw> скопирован из донора — убедитесь, что это ваш рабочий тег"))
            } else rep.issues += Issue("WARN", "modDesc.xml", tr("Немає тега <knw>. Додайте його з будь-якого робочого мода FS23 (owner/key не вигадуються), modName=\"$modName\"", "Нет тега <knw>. Добавьте его из любого рабочего мода FS23 (owner/key не выдумываются), modName=\"$modName\""))
        }
        if (t.contains("<dependencies>")) rep.issues += Issue("WARN", "modDesc.xml", tr("Є <dependencies>. Інструкція: видаляти лише якщо залежний мод вбудовано в карту — автоматично не видалялось", "Есть <dependencies>. Инструкция: удалять только если зависимый мод встроен в карту — автоматически не удалялось"))
        val dir = mapDir(t)
        if (dir != null) {
            val sf = "$dir/scripts/MapFrameFix.lua"
            if (!t.contains("MapFrameFix.lua")) {
                t = if (t.contains("<extraSourceFiles>")) t.replaceFirst("<extraSourceFiles>", "<extraSourceFiles>\n        <sourceFile filename=\"$sf\"/>")
                else t.replaceFirst("</modDesc>", "    <extraSourceFiles>\n        <sourceFile filename=\"$sf\"/>\n    </extraSourceFiles>\n</modDesc>")
                rep.changes += "modDesc.xml: " + tr("підключено $sf", "подключён $sf")
            }
        } else rep.issues += Issue("WARN", "modDesc.xml", tr("Не знайдено configFilename=\"…/map.xml\" — MapFrameFix.lua не підключено", "Не найден configFilename=\"…/map.xml\" — MapFrameFix.lua не подключён"))
        return t
    }

    /** Файли, які треба додати в архів (MapFrameFix.lua), якщо його ще немає. */
    fun extraFiles(modDesc: String): List<Pair<String, ByteArray>> {
        val dir = mapDir(modDesc) ?: return emptyList()
        return listOf("$dir/scripts/MapFrameFix.lua" to MAP_FRAME_FIX.toByteArray(Charsets.UTF_8))
    }
}
