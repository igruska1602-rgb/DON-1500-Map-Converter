@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        Lang.uk = store.uk
        Donor.load(this)
        setContent { App(store) }
    }
}

data class Palette(val id: String, val uk: String, val ru: String, val swatch: Color, val primaryDark: Color, val primaryLight: Color, val secondaryDark: Color, val secondaryLight: Color, val onPrimary: Color = Color.White)

val PALETTES = listOf(
    Palette("orange", "Помаранчевий", "Оранжевый", Color(0xFFFF4A3D), Color(0xFFFF4A3D), Color(0xFFD9261C), Color(0xFFFFB020), Color(0xFFE08A00)),
    Palette("blue", "Синій", "Синий", Color(0xFF3D8BFF), Color(0xFF3D8BFF), Color(0xFF1C63D9), Color(0xFF4FD0E0), Color(0xFF0E8FA3)),
    Palette("green", "Зелений", "Зелёный", Color(0xFF3DDC84), Color(0xFF2FBE70), Color(0xFF1E9956), Color(0xFFB0DD3D), Color(0xFF7AA018)),
    Palette("red", "Червоний", "Красный", Color(0xFFE23D3D), Color(0xFFE23D3D), Color(0xFFBF1F1F), Color(0xFFFF8A3D), Color(0xFFD9641C)),
    Palette("purple", "Фіолетовий", "Фиолетовый", Color(0xFF9B5CFF), Color(0xFF9B5CFF), Color(0xFF6E2FD9), Color(0xFFFF5CC8), Color(0xFFD91FA3)),
    Palette("silver", "Білий / срібний", "Белый / серебристый", Color(0xFFD8DCE2), Color(0xFFB9C0CC), Color(0xFF55606E), Color(0xFF8A94A3), Color(0xFF3B4250), Color(0xFF14161A)),
)

@Composable
fun DonTheme(dark: Boolean, accent: String, content: @Composable () -> Unit) {
    val p = PALETTES.firstOrNull { it.id == accent } ?: PALETTES[0]
    val cs = if (dark) darkColorScheme(
        primary = p.primaryDark, onPrimary = p.onPrimary, secondary = p.secondaryDark,
        background = Color(0xFF0E0E10), surface = Color(0xFF1A1A1E), surfaceVariant = Color(0xFF26262B),
        onBackground = Color(0xFFF2F2F2), onSurface = Color(0xFFF2F2F2), onSurfaceVariant = Color(0xFFB8B8BE)
    ) else lightColorScheme(
        primary = p.primaryLight, onPrimary = p.onPrimary, secondary = p.secondaryLight,
        background = Color(0xFFF7F4F1), surface = Color.White, surfaceVariant = Color(0xFFEDE7E2)
    )
    MaterialTheme(colorScheme = cs, content = content)
}

val LocalOpenAi = compositionLocalOf<(() -> Unit)?> { null }

@Composable
fun Frame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
            val openAi = LocalOpenAi.current
            if (openAi != null && !title.startsWith("AI")) IconButton(onClick = openAi) { Icon(Icons.Filled.SmartToy, null, tint = MaterialTheme.colorScheme.primary) }
        }
        content()
    }
}

@Composable
fun App(store: Store) {
    var dark by remember { mutableStateOf(store.dark) }
    var accent by remember { mutableStateOf(store.accent) }
    var screen by remember { mutableStateOf("home") }
    var autoPick by remember { mutableStateOf(false) }
    var editFile by remember { mutableStateOf<File?>(null) }
    var prev by remember { mutableStateOf("home") }
    fun go(s: String) { autoPick = false; prev = screen; screen = s }
    val openAi: () -> Unit = { go("ai") }
    BackHandler(screen != "home") { screen = if (screen == "ai") prev else "home" }
    DonTheme(dark, accent) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            CompositionLocalProvider(LocalOpenAi provides openAi) {
            when (screen) {
                "home" -> HomeScreen(store, onOpen = { id ->
                    when (id) {
                        "fs25" -> { autoPick = true; screen = "converter" }
                        else -> go(id)
                    }
                })
                "apk" -> ApkScreen(onConvert = { autoPick = false; screen = "converter" }) { go("home") }
                "donors" -> DonorsScreen(store) { go("home") }
                "converter" -> ConverterScreen(store, autoPick) { go("home") }
                "files" -> FileManagerScreen(
                    onBack = { go("home") },
                    onConvert = { f -> Session.sourceFile = f; Session.report = null; Session.reportText = ""; go("converter") },
                    onEdit = { f -> editFile = f; go("editor") }
                )
                "editor" -> EditorScreen(editFile) { go("home") }
                "textures" -> TexturesScreen(store) { go("home") }
                "images" -> ImagesScreen { go("home") }
                "errors" -> ErrorsScreen(store) { go("home") }
                "ai" -> AiScreen(store, onNav = { go(it) }) { screen = prev }
                "results" -> ResultsScreen { go("home") }
                "settings" -> SettingsScreen(store, dark, onDark = { dark = it; store.dark = it }, accent = accent, onAccent = { accent = it; store.accent = it }) { go("home") }
                "texswap" -> TextureSwapScreen(store) { go("home") }
            }
            }
        }
    }
}

private class Tile(val id: String, val icon: ImageVector, val uk: String, val ru: String)

@Composable
fun HomeScreen(store: Store, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val tiles = listOf(
        Tile("apk", Icons.Filled.Android, "APK / ДАНІ ГРИ", "APK / ДАННЫЕ ИГРЫ"),
        Tile("fs25", Icons.Filled.FolderOpen, "ВИБРАТИ FS25", "ВЫБРАТЬ FS25"),
        Tile("converter", Icons.Filled.Build, "КОНВЕРТЕР FS25 → FS26", "КОНВЕРТЕР FS25 → FS26"),
        Tile("donors", Icons.Filled.Storage, "ДОНОРИ FS26 / FS23", "ДОНОРЫ FS26 / FS23"),
        Tile("texswap", Icons.Filled.Palette, "ЗАМІНА ТЕКСТУР", "ЗАМЕНА ТЕКСТУР"),
        Tile("files", Icons.Filled.Folder, "ФАЙЛОВИЙ МЕНЕДЖЕР", "ФАЙЛОВЫЙ МЕНЕДЖЕР"),
        Tile("editor", Icons.Filled.Edit, "XML / i3D РЕДАКТОР", "XML / i3D РЕДАКТОР"),
        Tile("textures", Icons.Filled.Image, "ТЕКСТУРИ ТА РЕСУРСИ", "ТЕКСТУРЫ И РЕСУРСЫ"),
        Tile("images", Icons.Filled.Image, "КОНВЕРТЕР ЗОБРАЖЕНЬ", "КОНВЕРТЕР ИЗОБРАЖЕНИЙ"),
        Tile("errors", Icons.Filled.BugReport, "ПЕРЕВІРКА ПОМИЛОК", "ПРОВЕРКА ОШИБОК"),
        Tile("ai", Icons.Filled.SmartToy, "AI-ПОМІЧНИК", "AI-ПОМОЩНИК"),
        Tile("results", Icons.Filled.Assessment, "РЕЗУЛЬТАТИ КОНВЕРТАЦІЇ", "РЕЗУЛЬТАТЫ КОНВЕРТАЦИИ"),
        Tile("settings", Icons.Filled.Settings, "НАЛАШТУВАННЯ", "НАСТРОЙКИ")
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.don_hero), null, Modifier.size(112.dp).clip(RoundedCornerShape(22.dp)))
            Column(Modifier.padding(start = 14.dp)) {
                Text("DON-1500", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                Text(tr("КОНВЕРТОР", "КОНВЕРТОР"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("FS25 → FS26 Mobile", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    Card(
                        onClick = { Haptics.tap(ctx, store); onOpen(t.id) },
                        modifier = Modifier.weight(1f).height(104.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(3.dp)
                    ) {
                        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                            Text(tr(t.uk, t.ru), fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 15.sp)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ErrorsScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var cur by remember { mutableStateOf("") }
    val src = Session.sourceFile
    Frame(tr("Перевірка помилок", "Проверка ошибок"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Джерело: ", "Источник: ") + (src?.name ?: tr("не вибрано (оберіть у «Вибрати FS25»)", "не выбрано (выберите в «Выбрать FS25»)")))
            Spacer(Modifier.height(8.dp))
            Button(enabled = src != null && !busy, onClick = {
                scope.launch {
                    busy = true
                    val r = withContext(Dispatchers.IO) { Converter.run(src!!, null, Options(store.renameFs, store.trimLang)) { f, _ -> cur = f } }
                    Session.report = r; Session.reportText = r.render(); busy = false
                }
            }) { Text(tr("Аналізувати (без змін)", "Анализировать (без изменений)")) }
            if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp)); Text(cur, fontSize = 11.sp, maxLines = 1) }
            Spacer(Modifier.height(8.dp))
            SelectionContainer { Text(Session.reportText.ifEmpty { tr("Звіт з'явиться тут.", "Отчёт появится здесь.") }, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
fun ResultsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf("") }
    val root = Fs.outDir(ctx)
    val folders = remember(tick, Session.rev) { root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() } ?: emptyList() }
    val loose = remember(tick, Session.rev) { root.listFiles()?.filter { it.isFile } ?: emptyList() }
    fun mime(f: File) = if (f.extension == "zip") "application/zip" else "text/plain"
    Frame(tr("Результати конвертації", "Результаты конвертации"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Кожен мод — окрема папка. Копія автоматично лежить у Download/DON1500/<мод>. Робоче місце: ", "Каждый мод — отдельная папка. Копия автоматически лежит в Download/DON1500/<мод>. Рабочее место: ") + root.absolutePath, fontSize = 11.sp)
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.secondary)
            folders.forEach { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("📁 ${d.name}", fontWeight = FontWeight.Bold)
                        d.listFiles()?.sortedBy { it.name }?.forEach { f ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(f.name, fontSize = 13.sp); Text(Fs.human(f.length()), fontSize = 11.sp) }
                                if (f.extension == "txt") TextButton(onClick = { preview = f.readText().take(20000) }) { Text(tr("Звіт", "Отчёт")) }
                                TextButton(onClick = {
                                    scope.launch { msg = withContext(Dispatchers.IO) { try { "✔ " + Fs.publish(ctx, f, mime(f), d.name) } catch (e: Exception) { "✖ ${e.message}" } } }
                                }) { Text("→ Download") }
                            }
                        }
                        TextButton(onClick = { d.deleteRecursively(); tick++ }) { Text(tr("Видалити робочу копію", "Удалить рабочую копию")) }
                    }
                }
            }
            loose.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name, Modifier.weight(1f), fontSize = 12.sp)
                    TextButton(onClick = { f.delete(); tick++ }) { Text(tr("Видалити", "Удалить")) }
                }
            }
            if (folders.isEmpty() && loose.isEmpty()) Text(tr("Поки порожньо.", "Пока пусто."))
            if (preview.isNotEmpty()) SelectionContainer { Text(preview, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
fun ProfileCard(p: Profile, active: Boolean, onSave: (Profile) -> String, onDelete: () -> Unit, onUse: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var name by remember(p.id) { mutableStateOf(p.name) }
    var provider by remember(p.id) { mutableStateOf(p.provider) }
    var model by remember(p.id) { mutableStateOf(p.model) }
    var key by remember(p.id) { mutableStateOf(p.key) }
    var baseUrl by remember(p.id) { mutableStateOf(p.baseUrl) }
    var models by remember { mutableStateOf(listOf<String>()) }
    var mmenu by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun onKey(v: String) { key = v; Ai.detectProvider(v.trim())?.let { provider = it } }
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(active, onUse)
                OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, label = { Text(tr("Назва", "Название")) })
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null) }
            }
            OutlinedTextField(key, { onKey(it) }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true,
                label = { Text(tr("API-ключ (вставте — провайдер визначиться сам)", "API-ключ (вставьте — провайдер определится сам)")) },
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    Row {
                        IconButton(onClick = { clip.getText()?.text?.let { onKey(it.trim()) } }) { Icon(Icons.Filled.ContentPaste, null) }
                        IconButton(onClick = { show = !show }) { Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null) }
                    }
                })
            Box(Modifier.padding(top = 6.dp)) {
                OutlinedButton(onClick = { menu = true }) { Text("$provider ▾") }
                DropdownMenu(menu, { menu = false }) {
                    Ai.providers.forEach { pr -> DropdownMenuItem(text = { Text(pr) }, onClick = { provider = pr; menu = false }) }
                }
            }
            if (provider == "Custom") OutlinedTextField(baseUrl, { baseUrl = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true, label = { Text("Base URL (https://…/v1)") })
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true,
                label = { Text(tr("Модель (порожньо = авто)", "Модель (пусто = авто)")) })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    OutlinedButton(enabled = !busy, onClick = {
                        scope.launch {
                            busy = true; msg = ""
                            val r = withContext(Dispatchers.IO) {
                                try { Ai.listModels(provider, key.trim(), baseUrl.trim()) } catch (e: Exception) { msg = "✖ ${e.message}"; emptyList<String>() }
                            }
                            models = r; busy = false
                            if (r.isNotEmpty()) mmenu = true
                        }
                    }) { Text(tr("Моделі ▾", "Модели ▾")) }
                    DropdownMenu(mmenu, { mmenu = false }) {
                        models.take(80).forEach { id -> DropdownMenuItem(text = { Text(id) }, onClick = { model = id; mmenu = false }) }
                    }
                }
                TextButton(onClick = { model = "" }) { Text("Авто", softWrap = false) }
            }
            Button(enabled = !busy, modifier = Modifier.padding(top = 4.dp), onClick = {
                val np = Profile(p.id, name.trim().ifEmpty { "AI" }, provider, model.trim(), key.trim(), baseUrl.trim())
                msg = onSave(np)
                scope.launch {
                    busy = true
                    val r = withContext(Dispatchers.IO) {
                        try {
                            val b = Ai.bestModel(np.provider, np.key, np.baseUrl)
                            if (b == null) "✖ " + tr("Ключ прийнято, але моделей не знайдено", "Ключ принят, но моделей не найдено")
                            else "✔ " + tr("Ключ працює. Авто-вибір моделі: ", "Ключ работает. Авто-выбор модели: ") + b
                        } catch (e: Exception) { "✖ ${e.message}" }
                    }
                    msg += "\n$r"; busy = false
                }
            }) { Text(tr("Зберегти і перевірити", "Сохранить и проверить")) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
        }
    }
}

@Composable
fun SettingsScreen(store: Store, dark: Boolean, onDark: (Boolean) -> Unit, accent: String, onAccent: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" } }
    var uk by remember { mutableStateOf(Lang.uk) }
    var rename by remember { mutableStateOf(store.renameFs) }
    var trim by remember { mutableStateOf(store.trimLang) }
    var maxTex by remember { mutableStateOf(store.maxTex) }
    var list by remember { mutableStateOf(store.profiles()) }
    var active by remember { mutableStateOf(store.activeProfile) }
    fun persist(l: List<Profile>): String {
        list = l
        return if (store.saveProfiles(l)) "✔ " + tr("Збережено (зашифровано)", "Сохранено (зашифровано)")
        else "✖ " + tr("Безпечне сховище недоступне — НЕ збережено", "Безопасное хранилище недоступно — НЕ сохранено")
    }
    Frame(tr("Налаштування", "Настройки"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Мова: ", "Язык: "))
                FilterChip(uk, { uk = true; Lang.uk = true; store.uk = true }, { Text("Українська") }); Spacer(Modifier.width(8.dp))
                FilterChip(!uk, { uk = false; Lang.uk = false; store.uk = false }, { Text("Русский") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Темна тема", "Тёмная тема"), Modifier.weight(1f)); Switch(dark, onDark) }
            Text(tr("Колір теми", "Цвет темы"), Modifier.padding(top = 10.dp), fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PALETTES.forEach { p ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onAccent(p.id) }) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(p.swatch).border(
                            width = if (accent == p.id) 3.dp else 1.dp,
                            color = if (accent == p.id) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outline,
                            shape = CircleShape))
                        Text(tr(p.uk, p.ru).substringBefore(" "), fontSize = 10.sp)
                    }
                }
            }
            Text(tr("Вібрація на натискання", "Вибрация на нажатия"), Modifier.padding(top = 10.dp), fontWeight = FontWeight.Bold)
            Row {
                FilterChip(store.vibeLevel == 0, { store.vibeLevel = 0 }, { Text(tr("Вимк", "Выкл")) }); Spacer(Modifier.width(6.dp))
                FilterChip(store.vibeLevel == 1, { store.vibeLevel = 1; Haptics.tap(LocalContext.current, store) }, { Text(tr("Слабка", "Слабая")) }); Spacer(Modifier.width(6.dp))
                FilterChip(store.vibeLevel == 2, { store.vibeLevel = 2; Haptics.tap(LocalContext.current, store) }, { Text(tr("Середня", "Средняя")) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Перейменовувати FS25→FS26 у назві мода", "Переименовывать FS25→FS26 в названии мода"), Modifier.weight(1f)); Switch(rename, { rename = it; store.renameFs = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Прибирати зайві мови з modDesc", "Убирать лишние языки из modDesc"), Modifier.weight(1f)); Switch(trim, { trim = it; store.trimLang = it }) }
            Text(tr("Макс. розмір текстур після DDS→PNG", "Макс. размер текстур после DDS→PNG"), Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold)
            Row {
                FilterChip(maxTex == 0, { maxTex = 0; store.maxTex = 0 }, { Text(tr("Оригінал", "Оригинал")) }); Spacer(Modifier.width(6.dp))
                FilterChip(maxTex == 2048, { maxTex = 2048; store.maxTex = 2048 }, { Text("2048") }); Spacer(Modifier.width(6.dp))
                FilterChip(maxTex == 1024, { maxTex = 1024; store.maxTex = 1024 }, { Text("1024") })
            }
            Text(tr("PNG без стиснення займає у кілька разів більше місця, ніж DDS, тому карта зростає. 2048 помітно зменшує розмір і підходить для телефону. Швидкий вибір розміру є також на екрані конвертера.", "PNG без сжатия занимает в несколько раз больше места, чем DDS, поэтому карта растёт. 2048 заметно уменьшает размер и подходит для телефона. Быстрый выбор размера есть также на экране конвертера."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            var signNick by remember { mutableStateOf(store.signNick) }
            var signOn by remember { mutableStateOf(store.signEnabled) }
            var signMsg by remember { mutableStateOf("") }
            val kb = LocalSoftwareKeyboardController.current
            val focus = LocalFocusManager.current
            Text(tr("Підпис автора", "Подпись автора"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(tr("Без AI, працює офлайн. Вписує ваш нік у поле «автор» у modDesc.xml (видно в грі там, де показується автор/бренд) і додає приховану мітку DON1500-SIGNATURE для перевірки нашою ж програмою пізніше.", "Без AI, работает офлайн. Вписывает ваш ник в поле «автор» в modDesc.xml (виден в игре там, где показывается автор/бренд) и добавляет скрытую метку DON1500-SIGNATURE для проверки нашей же программой позже."), fontSize = 11.sp)
            Text(tr("Чесно: сама гра цю мітку не перевіряє і не ховає мод за її відсутності — це не в нашій владі. Будь-хто з текстовим редактором технічно може її прибрати.", "Честно: сама игра эту метку не проверяет и не скрывает мод при её отсутствии — это не в нашей власти. Любой с текстовым редактором технически может её убрать."), fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Додавати підпис при конвертації", "Добавлять подпись при конвертации"), Modifier.weight(1f), fontSize = 13.sp)
                Switch(signOn, { signOn = it; store.signEnabled = it })
            }
            OutlinedTextField(signNick, { signNick = it; signMsg = "" }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("Ваш нік (наприклад DON-1500)", "Ваш ник (например DON-1500)")) })
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                Button(onClick = {
                    store.signNick = signNick.trim(); signNick = signNick.trim()
                    focus.clearFocus(); kb?.hide()
                    signMsg = "✔ " + tr("Збережено", "Сохранено")
                }) { Text(tr("Зберегти", "Сохранить")) }
                if (signMsg.isNotEmpty()) Text(signMsg, Modifier.padding(start = 10.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
            }
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI-ключі (${list.size}/20)", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = {
                    if (list.size < 20) persist(list + Profile(java.util.UUID.randomUUID().toString(), tr("Новий ключ", "Новый ключ"), "OpenAI", "", ""))
                }) { Icon(Icons.Filled.Add, null) }
            }
            if (!store.secureAvailable) Text(tr("⚠ Безпечне сховище недоступне на цьому пристрої: ключі не зберігатимуться.", "⚠ Безопасное хранилище недоступно на этом устройстве: ключи не будут сохраняться."), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            list.forEach { p ->
                key(p.id) {
                    ProfileCard(p, p.id == active,
                        onSave = { np -> persist(list.map { if (it.id == np.id) np else it }) },
                        onDelete = { persist(list.filter { it.id != p.id }); if (active == p.id) { active = ""; store.activeProfile = "" } },
                        onUse = { active = p.id; store.activeProfile = p.id })
                }
            }
            Text(tr("Файли надсилаються в AI лише після вашого підтвердження.", "Файлы отправляются в AI только после вашего подтверждения."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("DON-1500 Converter v$ver", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
