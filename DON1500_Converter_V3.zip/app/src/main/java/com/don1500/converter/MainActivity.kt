@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        Lang.uk = store.uk
        setContent { App(store) }
    }
}

@Composable
fun DonTheme(dark: Boolean, content: @Composable () -> Unit) {
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFFFF4A3D), onPrimary = Color.White, secondary = Color(0xFFFFB020),
        background = Color(0xFF0E0E10), surface = Color(0xFF1A1A1E), surfaceVariant = Color(0xFF26262B),
        onBackground = Color(0xFFF2F2F2), onSurface = Color(0xFFF2F2F2), onSurfaceVariant = Color(0xFFB8B8BE)
    ) else lightColorScheme(
        primary = Color(0xFFD9261C), onPrimary = Color.White, secondary = Color(0xFFE08A00),
        background = Color(0xFFF7F4F1), surface = Color.White, surfaceVariant = Color(0xFFEDE7E2)
    )
    MaterialTheme(colorScheme = cs, content = content)
}

@Composable
fun Frame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        content()
    }
}

@Composable
fun App(store: Store) {
    var dark by remember { mutableStateOf(store.dark) }
    var screen by remember { mutableStateOf("home") }
    var autoPick by remember { mutableStateOf(false) }
    var editFile by remember { mutableStateOf<File?>(null) }
    fun go(s: String) { autoPick = false; screen = s }
    BackHandler(screen != "home") { screen = "home" }
    DonTheme(dark) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (screen) {
                "home" -> HomeScreen(onOpen = { id ->
                    when (id) {
                        "fs25" -> { autoPick = true; screen = "converter" }
                        else -> go(id)
                    }
                })
                "apk" -> ApkScreen { go("home") }
                "converter" -> ConverterScreen(store, autoPick) { go("home") }
                "files" -> FileManagerScreen(
                    onBack = { go("home") },
                    onConvert = { f -> Session.sourceFile = f; Session.report = null; Session.reportText = ""; go("converter") },
                    onEdit = { f -> editFile = f; go("editor") }
                )
                "editor" -> EditorScreen(editFile) { go("home") }
                "textures" -> TexturesScreen { go("home") }
                "errors" -> ErrorsScreen(store) { go("home") }
                "ai" -> AiScreen(store) { go("home") }
                "results" -> ResultsScreen { go("home") }
                "settings" -> SettingsScreen(store, dark, onDark = { dark = it; store.dark = it }) { go("home") }
            }
        }
    }
}

private class Tile(val id: String, val icon: ImageVector, val uk: String, val ru: String)

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val tiles = listOf(
        Tile("apk", Icons.Filled.Android, "ВИБРАТИ APK", "ВЫБРАТЬ APK"),
        Tile("fs25", Icons.Filled.FolderOpen, "ВИБРАТИ FS25", "ВЫБРАТЬ FS25"),
        Tile("converter", Icons.Filled.Build, "КОНВЕРТЕР FS25 → FS26", "КОНВЕРТЕР FS25 → FS26"),
        Tile("files", Icons.Filled.Folder, "ФАЙЛОВИЙ МЕНЕДЖЕР", "ФАЙЛОВЫЙ МЕНЕДЖЕР"),
        Tile("editor", Icons.Filled.Edit, "XML / i3D РЕДАКТОР", "XML / i3D РЕДАКТОР"),
        Tile("textures", Icons.Filled.Image, "ТЕКСТУРИ ТА РЕСУРСИ", "ТЕКСТУРЫ И РЕСУРСЫ"),
        Tile("errors", Icons.Filled.BugReport, "ПЕРЕВІРКА ПОМИЛОК", "ПРОВЕРКА ОШИБОК"),
        Tile("ai", Icons.Filled.SmartToy, "AI-ПОМІЧНИК", "AI-ПОМОЩНИК"),
        Tile("results", Icons.Filled.Assessment, "РЕЗУЛЬТАТИ КОНВЕРТАЦІЇ", "РЕЗУЛЬТАТЫ КОНВЕРТАЦИИ"),
        Tile("settings", Icons.Filled.Settings, "НАЛАШТУВАННЯ", "НАСТРОЙКИ")
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.don_hero), null, Modifier.size(112.dp).clip(RoundedCornerShape(22.dp)))
            Column(Modifier.padding(start = 14.dp)) {
                Text("DON-1500", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                Text(tr("КОНВЕРТОР", "КОНВЕРТОР"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("FS25 → FS26 Mobile", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    Card(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onOpen(t.id) },
                        modifier = Modifier.weight(1f).height(104.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(3.dp)
                    ) {
                        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                            Text(tr(t.uk, t.ru), fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 15.sp)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ErrorsScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var cur by remember { mutableStateOf("") }
    val src = Session.sourceFile
    Frame(tr("Перевірка помилок", "Проверка ошибок"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Джерело: ", "Источник: ") + (src?.name ?: tr("не вибрано (оберіть у «Вибрати FS25»)", "не выбрано (выберите в «Выбрать FS25»)")))
            Spacer(Modifier.height(8.dp))
            Button(enabled = src != null && !busy, onClick = {
                scope.launch {
                    busy = true
                    val r = withContext(Dispatchers.IO) { Converter.run(src!!, null, Options(store.renameFs, store.trimLang)) { f, _ -> cur = f } }
                    Session.report = r; Session.reportText = r.render(); busy = false
                }
            }) { Text(tr("Аналізувати (без змін)", "Анализировать (без изменений)")) }
            if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp)); Text(cur, fontSize = 11.sp, maxLines = 1) }
            Spacer(Modifier.height(8.dp))
            SelectionContainer { Text(Session.reportText.ifEmpty { tr("Звіт з'явиться тут.", "Отчёт появится здесь.") }, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
fun ResultsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf("") }
    val files = remember(tick, Session.rev) { Fs.outDir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList() }
    Frame(tr("Результати конвертації", "Результаты конвертации"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Автоматично копіюється в Download/DON1500. Робочі файли: ", "Автоматически копируется в Download/DON1500. Рабочие файлы: ") + Fs.outDir(ctx).absolutePath, fontSize = 11.sp)
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.secondary)
            files.forEach { f ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(f.name, fontWeight = FontWeight.Bold)
                        Text(Fs.human(f.length()), fontSize = 12.sp)
                        Row {
                            TextButton(onClick = {
                                scope.launch {
                                    msg = withContext(Dispatchers.IO) {
                                        try { "✔ " + Fs.publish(ctx, f, if (f.extension == "zip") "application/zip" else "text/plain") } catch (e: Exception) { "✖ ${e.message}" }
                                    }
                                }
                            }) { Text(tr("Зберегти у Download", "Сохранить в Download")) }
                            if (f.extension == "txt") TextButton(onClick = { preview = f.readText().take(20000) }) { Text(tr("Переглянути", "Просмотреть")) }
                            TextButton(onClick = { f.delete(); tick++ }) { Text(tr("Видалити", "Удалить")) }
                        }
                    }
                }
            }
            if (files.isEmpty()) Text(tr("Поки порожньо.", "Пока пусто."))
            if (preview.isNotEmpty()) SelectionContainer { Text(preview, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
fun AiScreen(store: Store, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var withReport by remember { mutableStateOf(true) }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf("") }
    val provider = store.provider
    fun payload(): String = (if (withReport && Session.reportText.isNotEmpty()) "REPORT:\n" + Session.reportText.take(12000) + "\n\n" else "") + "QUESTION:\n" + q
    Frame(tr("AI-помічник", "AI-помощник"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Провайдер: $provider (змінити в Налаштуваннях)", "Провайдер: $provider (изменить в Настройках)"), fontSize = 12.sp)
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 8.dp), minLines = 4,
                label = { Text(tr("Питання, лог або XML", "Вопрос, лог или XML")) })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(withReport, { withReport = it }); Text(tr("Додати останній звіт конвертера", "Добавить последний отчёт конвертера"), fontSize = 13.sp)
            }
            Button(enabled = q.isNotBlank() && !busy, onClick = { confirm = payload() }) { Text(tr("Надіслати…", "Отправить…")) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            Spacer(Modifier.height(8.dp))
            SelectionContainer { Text(answer, fontSize = 14.sp) }
        }
    }
    if (confirm.isNotEmpty()) AlertDialog(
        onDismissRequest = { confirm = "" },
        title = { Text(tr("Що буде передано до $provider", "Что будет передано в $provider")) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(confirm.take(4000), fontSize = 11.sp, fontFamily = FontFamily.Monospace) } },
        confirmButton = {
            TextButton(onClick = {
                val text = confirm; confirm = ""
                scope.launch {
                    busy = true
                    answer = withContext(Dispatchers.IO) {
                        try { Ai.chat(provider, store.getKey(provider), store.model(provider), Ai.SYSTEM, text) } catch (e: Exception) { "✖ ${e.message}" }
                    }
                    busy = false
                }
            }) { Text(tr("Дозволяю, надіслати", "Разрешаю, отправить")) }
        },
        dismissButton = { TextButton(onClick = { confirm = "" }) { Text(tr("Скасувати", "Отмена")) } }
    )
}

@Composable
fun SettingsScreen(store: Store, dark: Boolean, onDark: (Boolean) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var uk by remember { mutableStateOf(Lang.uk) }
    var provider by remember { mutableStateOf(store.provider) }
    var key by remember(provider) { mutableStateOf(store.getKey(provider)) }
    var model by remember(provider) { mutableStateOf(store.model(provider)) }
    var show by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(store.renameFs) }
    var trim by remember { mutableStateOf(store.trimLang) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Frame(tr("Налаштування", "Настройки"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Мова: ", "Язык: ")); 
                FilterChip(uk, { uk = true; Lang.uk = true; store.uk = true }, { Text("Українська") }); Spacer(Modifier.width(8.dp))
                FilterChip(!uk, { uk = false; Lang.uk = false; store.uk = false }, { Text("Русский") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Темна тема", "Тёмная тема"), Modifier.weight(1f)); Switch(dark, onDark) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Перейменовувати FS25→FS26 у назві мода", "Переименовывать FS25→FS26 в названии мода"), Modifier.weight(1f)); Switch(rename, { rename = it; store.renameFs = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Прибирати зайві мови з modDesc (як у вашому прикладі FS26)", "Убирать лишние языки из modDesc (как в вашем примере FS26)"), Modifier.weight(1f)); Switch(trim, { trim = it; store.trimLang = it }) }
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("AI", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Box {
                OutlinedButton(onClick = { menu = true }) { Text("${tr("Провайдер", "Провайдер")}: $provider") }
                DropdownMenu(menu, { menu = false }) {
                    Ai.providers.forEach { p -> DropdownMenuItem(text = { Text(p) }, onClick = { provider = p; store.provider = p; menu = false }) }
                }
            }
            OutlinedTextField(model, { model = it; store.setModel(provider, it) }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true,
                label = { Text(tr("Модель (порожньо = ${Ai.defaultModel(provider)})", "Модель (пусто = ${Ai.defaultModel(provider)})")) })
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true, label = { Text("API key") },
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { IconButton({ show = !show }) { Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null) } })
            Row {
                Button(onClick = {
                    msg = if (store.setKey(provider, key.trim())) tr("✔ Ключ збережено (зашифровано)", "✔ Ключ сохранён (зашифрован)")
                    else tr("✖ Безпечне сховище недоступне на цьому пристрої — ключ НЕ збережено", "✖ Безопасное хранилище недоступно на этом устройстве — ключ НЕ сохранён")
                }) { Text(tr("Зберегти", "Сохранить")) }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true; msg = ""
                        msg = withContext(Dispatchers.IO) {
                            try { Ai.chat(provider, key.trim(), model, "Reply with the single word OK.", "ping"); "✔ " + tr("З'єднання працює", "Соединение работает") }
                            catch (e: Exception) { "✖ ${e.message}" }
                        }
                        busy = false
                    }
                }) { Text(tr("Перевірити з'єднання", "Проверить соединение")) }
            }
            if (msg.isNotEmpty()) Text(msg, Modifier.padding(top = 6.dp), fontSize = 13.sp)
            Text(tr("Файли надсилаються в AI лише після вашого підтвердження.", "Файлы отправляются в AI только после вашего подтверждения."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("DON-1500 Converter v3.0", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
