@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        Lang.uk = store.uk
        Donor.load(this)
        setContent { App(store) }
    }
}

@Composable
fun DonTheme(dark: Boolean, content: @Composable () -> Unit) {
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFFFF4A3D), onPrimary = Color.White, secondary = Color(0xFFFFB020),
        background = Color(0xFF0E0E10), surface = Color(0xFF1A1A1E), surfaceVariant = Color(0xFF26262B),
        onBackground = Color(0xFFF2F2F2), onSurface = Color(0xFFF2F2F2), onSurfaceVariant = Color(0xFFB8B8BE)
    ) else lightColorScheme(
        primary = Color(0xFFD9261C), onPrimary = Color.White, secondary = Color(0xFFE08A00),
        background = Color(0xFFF7F4F1), surface = Color.White, surfaceVariant = Color(0xFFEDE7E2)
    )
    MaterialTheme(colorScheme = cs, content = content)
}

val LocalOpenAi = compositionLocalOf<(() -> Unit)?> { null }

@Composable
fun Frame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
            val openAi = LocalOpenAi.current
            if (openAi != null && !title.startsWith("AI")) IconButton(onClick = openAi) { Icon(Icons.Filled.SmartToy, null, tint = MaterialTheme.colorScheme.primary) }
        }
        content()
    }
}

@Composable
fun App(store: Store) {
    var dark by remember { mutableStateOf(store.dark) }
    var screen by remember { mutableStateOf("home") }
    var autoPick by remember { mutableStateOf(false) }
    var editFile by remember { mutableStateOf<File?>(null) }
    var prev by remember { mutableStateOf("home") }
    fun go(s: String) { autoPick = false; prev = screen; screen = s }
    val openAi: () -> Unit = { go("ai") }
    BackHandler(screen != "home") { screen = if (screen == "ai") prev else "home" }
    DonTheme(dark) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            CompositionLocalProvider(LocalOpenAi provides openAi) {
            when (screen) {
                "home" -> HomeScreen(onOpen = { id ->
                    when (id) {
                        "fs25" -> { autoPick = true; screen = "converter" }
                        else -> go(id)
                    }
                })
                "apk" -> ApkScreen { go("home") }
                "donors" -> DonorsScreen(store) { go("home") }
                "converter" -> ConverterScreen(store, autoPick) { go("home") }
                "files" -> FileManagerScreen(
                    onBack = { go("home") },
                    onConvert = { f -> Session.sourceFile = f; Session.report = null; Session.reportText = ""; go("converter") },
                    onEdit = { f -> editFile = f; go("editor") }
                )
                "editor" -> EditorScreen(editFile) { go("home") }
                "textures" -> TexturesScreen(store) { go("home") }
                "images" -> ImagesScreen { go("home") }
                "errors" -> ErrorsScreen(store) { go("home") }
                "ai" -> AiScreen(store) { screen = prev }
                "results" -> ResultsScreen { go("home") }
                "settings" -> SettingsScreen(store, dark, onDark = { dark = it; store.dark = it }) { go("home") }
            }
            }
        }
    }
}

private class Tile(val id: String, val icon: ImageVector, val uk: String, val ru: String)

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val tiles = listOf(
        Tile("apk", Icons.Filled.Android, "ВИБРАТИ APK", "ВЫБРАТЬ APK"),
        Tile("fs25", Icons.Filled.FolderOpen, "ВИБРАТИ FS25", "ВЫБРАТЬ FS25"),
        Tile("converter", Icons.Filled.Build, "КОНВЕРТЕР FS25 → FS26", "КОНВЕРТЕР FS25 → FS26"),
        Tile("donors", Icons.Filled.Storage, "ДОНОРИ FS26 / FS23", "ДОНОРЫ FS26 / FS23"),
        Tile("files", Icons.Filled.Folder, "ФАЙЛОВИЙ МЕНЕДЖЕР", "ФАЙЛОВЫЙ МЕНЕДЖЕР"),
        Tile("editor", Icons.Filled.Edit, "XML / i3D РЕДАКТОР", "XML / i3D РЕДАКТОР"),
        Tile("textures", Icons.Filled.Image, "ТЕКСТУРИ ТА РЕСУРСИ", "ТЕКСТУРЫ И РЕСУРСЫ"),
        Tile("images", Icons.Filled.Image, "КОНВЕРТЕР ЗОБРАЖЕНЬ", "КОНВЕРТЕР ИЗОБРАЖЕНИЙ"),
        Tile("errors", Icons.Filled.BugReport, "ПЕРЕВІРКА ПОМИЛОК", "ПРОВЕРКА ОШИБОК"),
        Tile("ai", Icons.Filled.SmartToy, "AI-ПОМІЧНИК", "AI-ПОМОЩНИК"),
        Tile("results", Icons.Filled.Assessment, "РЕЗУЛЬТАТИ КОНВЕРТАЦІЇ", "РЕЗУЛЬТАТЫ КОНВЕРТАЦИИ"),
        Tile("settings", Icons.Filled.Settings, "НАЛАШТУВАННЯ", "НАСТРОЙКИ")
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.don_hero), null, Modifier.size(112.dp).clip(RoundedCornerShape(22.dp)))
            Column(Modifier.padding(start = 14.dp)) {
                Text("DON-1500", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                Text(tr("КОНВЕРТОР", "КОНВЕРТОР"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("FS25 → FS26 Mobile", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    Card(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onOpen(t.id) },
                        modifier = Modifier.weight(1f).height(104.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(3.dp)
                    ) {
                        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                            Text(tr(t.uk, t.ru), fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 15.sp)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ErrorsScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var cur by remember { mutableStateOf("") }
    val src = Session.sourceFile
    Frame(tr("Перевірка помилок", "Проверка ошибок"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Джерело: ", "Источник: ") + (src?.name ?: tr("не вибрано (оберіть у «Вибрати FS25»)", "не выбрано (выберите в «Выбрать FS25»)")))
            Spacer(Modifier.height(8.dp))
            Button(enabled = src != null && !busy, onClick = {
                scope.launch {
                    busy = true
                    val r = withContext(Dispatchers.IO) { Converter.run(src!!, null, Options(store.renameFs, store.trimLang)) { f, _ -> cur = f } }
                    Session.report = r; Session.reportText = r.render(); busy = false
                }
            }) { Text(tr("Аналізувати (без змін)", "Анализировать (без изменений)")) }
            if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp)); Text(cur, fontSize = 11.sp, maxLines = 1) }
            Spacer(Modifier.height(8.dp))
            SelectionContainer { Text(Session.reportText.ifEmpty { tr("Звіт з'явиться тут.", "Отчёт появится здесь.") }, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
fun ResultsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf("") }
    val root = Fs.outDir(ctx)
    val folders = remember(tick, Session.rev) { root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() } ?: emptyList() }
    val loose = remember(tick, Session.rev) { root.listFiles()?.filter { it.isFile } ?: emptyList() }
    fun mime(f: File) = if (f.extension == "zip") "application/zip" else "text/plain"
    Frame(tr("Результати конвертації", "Результаты конвертации"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Кожен мод — окрема папка. Копія автоматично лежить у Download/DON1500/<мод>. Робоче місце: ", "Каждый мод — отдельная папка. Копия автоматически лежит в Download/DON1500/<мод>. Рабочее место: ") + root.absolutePath, fontSize = 11.sp)
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.secondary)
            folders.forEach { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("📁 ${d.name}", fontWeight = FontWeight.Bold)
                        d.listFiles()?.sortedBy { it.name }?.forEach { f ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(f.name, fontSize = 13.sp); Text(Fs.human(f.length()), fontSize = 11.sp) }
                                if (f.extension == "txt") TextButton(onClick = { preview = f.readText().take(20000) }) { Text(tr("Звіт", "Отчёт")) }
                                TextButton(onClick = {
                                    scope.launch { msg = withContext(Dispatchers.IO) { try { "✔ " + Fs.publish(ctx, f, mime(f), d.name) } catch (e: Exception) { "✖ ${e.message}" } } }
                                }) { Text("→ Download") }
                            }
                        }
                        TextButton(onClick = { d.deleteRecursively(); tick++ }) { Text(tr("Видалити робочу копію", "Удалить рабочую копию")) }
                    }
                }
            }
            loose.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name, Modifier.weight(1f), fontSize = 12.sp)
                    TextButton(onClick = { f.delete(); tick++ }) { Text(tr("Видалити", "Удалить")) }
                }
            }
            if (folders.isEmpty() && loose.isEmpty()) Text(tr("Поки порожньо.", "Пока пусто."))
            if (preview.isNotEmpty()) SelectionContainer { Text(preview, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
fun AiScreen(store: Store, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val profiles = remember { store.profiles() }
    var activeId by remember { mutableStateOf(store.activeProfile.ifEmpty { profiles.firstOrNull()?.id ?: "" }) }
    var menu by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var withReport by remember { mutableStateOf(true) }
    var withFile by remember { mutableStateOf(true) }
    val ctx = LocalContext.current
    var aiTarget by remember { mutableStateOf("FS26") }
    var imgDlg by remember { mutableStateOf(false) }
    var imgPrompt by remember { mutableStateOf("") }
    var imgModel by remember { mutableStateOf("") }
    var imgSize by remember { mutableStateOf(1024) }
    var imgFmt by remember { mutableStateOf("PNG") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf("") }
    val prof = profiles.firstOrNull { it.id == activeId } ?: profiles.firstOrNull()
    fun payload(): String =
        (if (withReport && Session.reportText.isNotEmpty()) "REPORT:\n" + Session.reportText.take(12000) + "\n\n" else "") +
            (if (withFile && Session.aiAttach.isNotEmpty()) Session.aiAttach.take(30000) + "\n\n" else "") +
            "QUESTION:\n" + q
    Frame(tr("AI-помічник", "AI-помощник"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            if (prof == null) {
                Text(tr("Немає жодного ключа. Налаштування → AI-ключі → кнопка «+».", "Нет ни одного ключа. Настройки → AI-ключи → кнопка «+»."))
            } else {
                Box {
                    OutlinedButton(onClick = { menu = true }) { Text("${prof.name} · ${prof.provider}") }
                    DropdownMenu(menu, { menu = false }) {
                        profiles.forEach { p -> DropdownMenuItem(text = { Text("${p.name} · ${p.provider}") }, onClick = { activeId = p.id; store.activeProfile = p.id; menu = false }) }
                    }
                }
            }
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 8.dp), minLines = 4,
                label = { Text(tr("Питання, лог або XML", "Вопрос, лог или XML")) })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(withReport, { withReport = it }); Text(tr("Додати останній звіт конвертера", "Добавить последний отчёт конвертера"), fontSize = 13.sp)
            }
            if (Session.aiAttach.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(withFile, { withFile = it }); Text(tr("Додати файл з менеджера: ", "Добавить файл из менеджера: ") + Session.aiAttach.lineSequence().first().take(60), fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Для гри: ", "Для игры: "))
                FilterChip(aiTarget == "FS26", { aiTarget = "FS26" }, { Text("FS26") }); Spacer(Modifier.width(6.dp))
                FilterChip(aiTarget == "FS23", { aiTarget = "FS23" }, { Text("FS23") })
            }
            Row {
                Button(enabled = prof != null && q.isNotBlank() && !busy, onClick = { confirm = payload() }) { Text(tr("Надіслати…", "Отправить…")) }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(enabled = prof != null && !busy, onClick = { imgDlg = true }) { Text(tr("Створити картинку…", "Создать картинку…")) }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            Spacer(Modifier.height(8.dp))
            SelectionContainer { Text(answer, fontSize = 14.sp) }
            if (answer.contains("```")) OutlinedButton(onClick = {
                scope.launch {
                    answer = answer + "\n\n" + withContext(Dispatchers.IO) {
                        try {
                            val ms = Regex("```(\\w*)\\s*\\n(.*?)```", RegexOption.DOT_MATCHES_ALL).findAll(answer).toList()
                            var n = 0
                            for (m in ms) {
                                val lang = m.groupValues[1].lowercase()
                                val ext = when (lang) { "lua", "xml", "i3d", "glsl", "hlsl" -> lang; else -> "txt" }
                                n++
                                val f = File(Fs.work(ctx), "ai_code_$n.$ext"); f.writeText(m.groupValues[2])
                                Fs.publish(ctx, f, "text/plain", "ai_code")
                            }
                            "✔ " + tr("Файлів збережено: $n → Download/DON1500/ai_code", "Файлов сохранено: $n → Download/DON1500/ai_code")
                        } catch (e: Exception) { "✖ ${e.message}" }
                    }
                }
            }) { Text(tr("Зберегти код із відповіді у файли", "Сохранить код из ответа в файлы")) }
        }
    }
    if (imgDlg && prof != null) AlertDialog(
        onDismissRequest = { imgDlg = false },
        title = { Text(tr("Створити картинку (${prof.provider})", "Создать картинку (${prof.provider})")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(imgPrompt, { imgPrompt = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text(tr("Опис текстури/картинки", "Описание текстуры/картинки")) })
                OutlinedTextField(imgModel, { imgModel = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true, label = { Text(tr("Модель зображень (порожньо = типова)", "Модель изображений (пусто = типовая)")) })
                Row(Modifier.padding(top = 6.dp)) { listOf(512, 1024, 2048).forEach { s -> FilterChip(imgSize == s, { imgSize = s }, { Text("$s") }); Spacer(Modifier.width(4.dp)) } }
                Row { listOf("PNG", "DDS", "JPG").forEach { f -> FilterChip(imgFmt == f, { imgFmt = f }, { Text(f) }); Spacer(Modifier.width(4.dp)) } }
                Text(tr("На сервіс піде лише ваш опис. Результат — в Download/DON1500/ai_images.", "На сервис уйдёт только ваше описание. Результат — в Download/DON1500/ai_images."), fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = imgPrompt.isNotBlank(), onClick = {
                imgDlg = false
                scope.launch {
                    busy = true
                    answer = withContext(Dispatchers.IO) {
                        try {
                            val raw = Ai.image(prof.provider, prof.key, imgModel.trim(), prof.baseUrl, imgPrompt)
                            val img = ImageTools.load(raw, "x.png") ?: throw java.io.IOException(tr("Не вдалося прочитати створене зображення", "Не удалось прочитать созданное изображение"))
                            val out = ImageTools.encode(ImageTools.resize(img, imgSize, true), imgFmt)
                            val f = File(Fs.work(ctx), "ai_image_" + (System.currentTimeMillis() / 1000) + "." + imgFmt.lowercase())
                            f.writeBytes(out)
                            "✔ " + Fs.publish(ctx, f, "application/octet-stream", "ai_images")
                        } catch (e: Throwable) { "✖ ${e.message}" }
                    }
                    busy = false
                }
            }) { Text(tr("Створити", "Создать")) }
        },
        dismissButton = { TextButton(onClick = { imgDlg = false }) { Text(tr("Скасувати", "Отмена")) } }
    )
    if (confirm.isNotEmpty() && prof != null) AlertDialog(
        onDismissRequest = { confirm = "" },
        title = { Text(tr("Що буде передано до ${prof.provider}", "Что будет передано в ${prof.provider}")) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(confirm.take(4000), fontSize = 11.sp, fontFamily = FontFamily.Monospace) } },
        confirmButton = {
            TextButton(onClick = {
                val text = confirm; confirm = ""
                scope.launch {
                    busy = true
                    answer = withContext(Dispatchers.IO) {
                        try { Ai.chat(prof.provider, prof.key, prof.model, Ai.SYSTEM + " Target game version: " + aiTarget + ". When you write files, put each file in its own fenced code block with the language (lua / xml).", text, prof.baseUrl) } catch (e: Exception) { "✖ ${e.message}" }
                    }
                    busy = false
                }
            }) { Text(tr("Дозволяю, надіслати", "Разрешаю, отправить")) }
        },
        dismissButton = { TextButton(onClick = { confirm = "" }) { Text(tr("Скасувати", "Отмена")) } }
    )
}

@Composable
fun ProfileCard(p: Profile, active: Boolean, onSave: (Profile) -> String, onDelete: () -> Unit, onUse: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember(p.id) { mutableStateOf(p.name) }
    var provider by remember(p.id) { mutableStateOf(p.provider) }
    var model by remember(p.id) { mutableStateOf(p.model) }
    var key by remember(p.id) { mutableStateOf(p.key) }
    var baseUrl by remember(p.id) { mutableStateOf(p.baseUrl) }
    var models by remember { mutableStateOf(listOf<String>()) }
    var mmenu by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(active, onUse)
                OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, label = { Text(tr("Назва", "Название")) })
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null) }
            }
            Box {
                OutlinedButton(onClick = { menu = true }) { Text(provider) }
                DropdownMenu(menu, { menu = false }) {
                    Ai.providers.forEach { pr -> DropdownMenuItem(text = { Text(pr) }, onClick = { provider = pr; menu = false }) }
                }
            }
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true,
                label = { Text(tr("Модель (порожньо = авто-вибір)", "Модель (пусто = авто-выбор)")) })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    OutlinedButton(enabled = !busy, onClick = {
                        scope.launch {
                            busy = true; msg = ""
                            val r = withContext(Dispatchers.IO) {
                                try { Ai.listModels(provider, key.trim(), baseUrl.trim()) } catch (e: Exception) { msg = "✖ ${e.message}"; emptyList<String>() }
                            }
                            models = r; busy = false
                            if (r.isNotEmpty()) mmenu = true
                        }
                    }) { Text(tr("Показати доступні моделі", "Показать доступные модели")) }
                    DropdownMenu(mmenu, { mmenu = false }) {
                        models.take(80).forEach { id -> DropdownMenuItem(text = { Text(id) }, onClick = { model = id; mmenu = false }) }
                    }
                }
                TextButton(onClick = { model = "" }) { Text(tr("Авто", "Авто")) }
            }
            if (provider == "Custom") OutlinedTextField(baseUrl, { baseUrl = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true, label = { Text("Base URL (https://…/v1)") })
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth().padding(top = 4.dp), singleLine = true, label = { Text("API key") },
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { IconButton(onClick = { show = !show }) { Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null) } })
            Row(Modifier.padding(top = 4.dp)) {
                Button(onClick = { msg = onSave(Profile(p.id, name.trim().ifEmpty { "AI" }, provider, model.trim(), key.trim(), baseUrl.trim())) }) { Text(tr("Зберегти", "Сохранить")) }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        msg = withContext(Dispatchers.IO) {
                            try { val rr = Ai.chat(provider, key.trim(), model.trim(), "Reply with the single word OK.", "ping", baseUrl.trim()); "✔ " + tr("З'єднання працює", "Соединение работает") + "\n" + rr.take(80) }
                            catch (e: Exception) { "✖ ${e.message}" }
                        }
                        busy = false
                    }
                }) { Text(tr("Перевірити", "Проверить")) }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
        }
    }
}

@Composable
fun SettingsScreen(store: Store, dark: Boolean, onDark: (Boolean) -> Unit, onBack: () -> Unit) {
    var uk by remember { mutableStateOf(Lang.uk) }
    var rename by remember { mutableStateOf(store.renameFs) }
    var trim by remember { mutableStateOf(store.trimLang) }
    var maxTex by remember { mutableStateOf(store.maxTex) }
    var list by remember { mutableStateOf(store.profiles()) }
    var active by remember { mutableStateOf(store.activeProfile) }
    fun persist(l: List<Profile>): String {
        list = l
        return if (store.saveProfiles(l)) "✔ " + tr("Збережено (зашифровано)", "Сохранено (зашифровано)")
        else "✖ " + tr("Безпечне сховище недоступне — НЕ збережено", "Безопасное хранилище недоступно — НЕ сохранено")
    }
    Frame(tr("Налаштування", "Настройки"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Мова: ", "Язык: "))
                FilterChip(uk, { uk = true; Lang.uk = true; store.uk = true }, { Text("Українська") }); Spacer(Modifier.width(8.dp))
                FilterChip(!uk, { uk = false; Lang.uk = false; store.uk = false }, { Text("Русский") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Темна тема", "Тёмная тема"), Modifier.weight(1f)); Switch(dark, onDark) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Перейменовувати FS25→FS26 у назві мода", "Переименовывать FS25→FS26 в названии мода"), Modifier.weight(1f)); Switch(rename, { rename = it; store.renameFs = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("Прибирати зайві мови з modDesc", "Убирать лишние языки из modDesc"), Modifier.weight(1f)); Switch(trim, { trim = it; store.trimLang = it }) }
            Text(tr("Макс. розмір текстур після DDS→PNG", "Макс. размер текстур после DDS→PNG"), Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold)
            Row {
                FilterChip(maxTex == 0, { maxTex = 0; store.maxTex = 0 }, { Text(tr("Оригінал", "Оригинал")) }); Spacer(Modifier.width(6.dp))
                FilterChip(maxTex == 2048, { maxTex = 2048; store.maxTex = 2048 }, { Text("2048") }); Spacer(Modifier.width(6.dp))
                FilterChip(maxTex == 1024, { maxTex = 1024; store.maxTex = 1024 }, { Text("1024") })
            }
            Text(tr("PNG без стиснення займає у кілька разів більше місця, ніж DDS, тому карта зростає. 2048 помітно зменшує розмір і підходить для телефону.", "PNG без сжатия занимает в несколько раз больше места, чем DDS, поэтому карта растёт. 2048 заметно уменьшает размер и подходит для телефона."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI-ключі (${list.size}/20)", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = {
                    if (list.size < 20) persist(list + Profile(java.util.UUID.randomUUID().toString(), tr("Новий ключ", "Новый ключ"), "OpenAI", "", ""))
                }) { Icon(Icons.Filled.Add, null) }
            }
            if (!store.secureAvailable) Text(tr("⚠ Безпечне сховище недоступне на цьому пристрої: ключі не зберігатимуться.", "⚠ Безопасное хранилище недоступно на этом устройстве: ключи не будут сохраняться."), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            list.forEach { p ->
                key(p.id) {
                    ProfileCard(p, p.id == active,
                        onSave = { np -> persist(list.map { if (it.id == np.id) np else it }) },
                        onDelete = { persist(list.filter { it.id != p.id }); if (active == p.id) { active = ""; store.activeProfile = "" } },
                        onUse = { active = p.id; store.activeProfile = p.id })
                }
            }
            Text(tr("Файли надсилаються в AI лише після вашого підтвердження.", "Файлы отправляются в AI только после вашего подтверждения."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("DON-1500 Converter v4.0", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
