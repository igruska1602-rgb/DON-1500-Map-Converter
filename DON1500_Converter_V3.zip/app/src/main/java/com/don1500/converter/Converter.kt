package com.don1500.converter

import java.io.*
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.util.zip.*

data class Issue(val level: String, val file: String, val msg: String)
class Options(
    val renameFs: Boolean, val trimLang: Boolean, val maxTex: Int = 0,
    val target: String = "FS26", val donors: List<File> = emptyList(), val donorByName: Boolean = true,
    val signNick: String = "", val signEnabled: Boolean = false
)

class ConvertReport {
    var sourceName = ""
    var outName = ""
    var type = ""
    var analyzeOnly = false
    var entries = 0
    var textureRewrites = 0
    var ddsConverted = 0
    var verified = false
    var cancelled = false
    var savedTo = ""
    val changes = mutableListOf<String>()
    val issues = mutableListOf<Issue>()
    val missing = linkedMapOf<String, String>() // шлях -> звідки згадується
    val missingData = linkedMapOf<String, String>() // \$data-посилання, яких немає в донорі

    val errors get() = issues.count { it.level == "ERROR" }
    val warnings get() = issues.count { it.level == "WARN" }
    val critical get() = errors > 0 || missing.isNotEmpty()

    private fun cat(p: String): String = when (p.substringAfterLast('.', "").lowercase()) {
        "png", "dds", "jpg", "jpeg", "tga" -> tr("Текстури", "Текстуры")
        "i3d", "shapes" -> tr("Моделі", "Модели")
        "xml" -> tr("Конфігурації XML", "Конфигурации XML")
        "ogg", "wav", "mp3" -> tr("Звуки", "Звуки")
        else -> tr("Інше", "Прочее")
    }

    fun render(): String = buildString {
        appendLine("DON-1500 Converter — " + tr("ЗВІТ", "ОТЧЁТ"))
        appendLine(tr("Джерело", "Источник") + ": $sourceName")
        if (!analyzeOnly) appendLine(tr("Результат", "Результат") + ": $outName")
        appendLine(tr("Тип", "Тип") + ": $type")
        appendLine(tr("Файлів в архіві", "Файлов в архиве") + ": $entries")
        appendLine()
        when {
            cancelled -> appendLine(tr("⛔ Конвертацію скасовано.", "⛔ Конвертация отменена."))
            analyzeOnly && critical -> appendLine(tr("⚠ Лише аналіз (файли не змінювались). Знайдено проблеми: помилок $errors, відсутніх файлів ${missing.size}.", "⚠ Только анализ (файлы не менялись). Найдены проблемы: ошибок $errors, отсутствующих файлов ${missing.size}."))
            analyzeOnly -> appendLine(tr("✔ Лише аналіз. Критичних проблем не знайдено.", "✔ Только анализ. Критичных проблем не найдено."))
            critical -> appendLine(tr("✖ Є критичні проблеми: помилок $errors, відсутніх файлів ${missing.size}. Мод НЕ можна вважати готовим.", "✖ Есть критичные проблемы: ошибок $errors, отсутствующих файлов ${missing.size}. Мод НЕЛЬЗЯ считать готовым."))
            else -> appendLine(tr("✔ Критичних помилок не знайдено. Архів перевірено на цілісність${if (verified) "" else " (перевірка не виконана)"}.", "✔ Критичных ошибок не найдено. Архив проверен на целостность${if (verified) "" else " (проверка не выполнена)"}."))
        }
        appendLine(tr("Сумісність у грі FS26 Mobile цим звітом НЕ підтверджується — перевірте в грі й надішліть log.txt.", "Совместимость в игре FS26 Mobile этим отчётом НЕ подтверждается — проверьте в игре и пришлите log.txt."))
        if (savedTo.isNotEmpty()) appendLine(tr("Збережено", "Сохранено") + ": $savedTo")
        appendLine()
        appendLine(tr("Змінено: рядків-посилань на текстури $textureRewrites, DDS→PNG: $ddsConverted", "Изменено: ссылок на текстуры $textureRewrites, DDS→PNG: $ddsConverted"))
        appendLine("=== " + tr("ЗМІНИ", "ИЗМЕНЕНИЯ") + " (${changes.size}) ===")
        changes.take(150).forEach { appendLine("• $it") }
        if (changes.size > 150) appendLine("… +${changes.size - 150}")
        appendLine()
        appendLine("=== " + tr("ВІДСУТНІ ФАЙЛИ", "ОТСУТСТВУЮЩИЕ ФАЙЛЫ") + " (${missing.size}) ===")
        missing.entries.groupBy { cat(it.key) }.forEach { (c, list) ->
            appendLine("[$c] ${list.size}")
            list.take(60).forEach { appendLine("  ${it.key}  ← ${it.value}") }
            if (list.size > 60) appendLine("  … +${list.size - 60}")
        }
        appendLine()
        if (Donor.count > 0) {
            appendLine("=== " + tr("НЕ ЗНАЙДЕНО В ДОНОРІ", "НЕ НАЙДЕНО В ДОНОРЕ") + " (${missingData.size}) — ${Donor.name} ===")
            missingData.entries.take(80).forEach { appendLine("  ${it.key}  ← ${it.value}") }
            if (missingData.size > 80) appendLine("  … +${missingData.size - 80}")
        } else appendLine(tr("Донор не завантажено: посилання \$data/… не перевірялись (розділ «Вибрати APK»).", "Донор не загружен: ссылки \$data/… не проверялись (раздел «Выбрать APK»)."))
        appendLine()
        appendLine("=== " + tr("ПОПЕРЕДЖЕННЯ ТА ПОМИЛКИ", "ПРЕДУПРЕЖДЕНИЯ И ОШИБКИ") + " (${issues.size}) ===")
        issues.take(150).forEach { appendLine("[${it.level}] ${it.file}: ${it.msg}") }
        if (issues.size > 150) appendLine("… +${issues.size - 150}")
    }
}

object Converter {
    private const val MAX_TEXT = 150L * 1024 * 1024
    private val ddsRe = Regex("\\.dds(?=[\"'<])", RegexOption.IGNORE_CASE)
    private val attrRe = Regex("\\b\\w*[Ff]ilename\\s*=\\s*\"([^\"]+)\"")
    private val elemRe = Regex("<(?:filename|image|xmlFilename|iconFilename)>\\s*([^<]+?)\\s*</")

    private val tl = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "h", 'ґ' to "g", 'д' to "d", 'е' to "e", 'є' to "ye", 'ж' to "zh",
        'з' to "z", 'и' to "y", 'і' to "i", 'ї' to "yi", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n",
        'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "kh", 'ц' to "ts",
        'ч' to "ch", 'ш' to "sh", 'щ' to "shch", 'ь' to "", 'ы' to "y", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ъ' to ""
    )

    /** FS25_DON_1500.zip → FS26_DON_1500.zip; кирилицю транслітеруємо, ім'я має починатися з літери. */
    fun outputName(src: String, target: String = "FS26"): String {
        var b = src.substringBeforeLast('.')
        b = b.map { c ->
            val t = tl[c.lowercaseChar()]
            if (t == null) c.toString() else if (c.isUpperCase()) t.replaceFirstChar { it.uppercaseChar() } else t
        }.joinToString("")
        b = b.replace(Regex("[^A-Za-z0-9_]+"), "_").trim('_')
        if (target == "FS22") {
            // FS22→FS23: ім'я zip = modName у <knw>, тому назву не міняємо (лише безпечні символи)
            if (b.isEmpty()) b = "FS22_MOD"
            if (!b[0].isLetter()) b = "MOD_$b"
            return "$b.zip"
        }
        b = b.replace(Regex("^(?i)FS(25|26|23)_?"), "").trim('_')
        if (b.isEmpty()) b = "MOD"
        if (b[0].isDigit()) b = "MOD_$b"
        return "${target}_$b.zip"
    }

    fun run(src: File, out: File?, opt: Options, isCancelled: () -> Boolean = { false }, progress: (String, Float) -> Unit): ConvertReport {
        val rep = ConvertReport()
        rep.sourceName = src.name
        rep.analyzeOnly = out == null
        rep.outName = out?.name ?: outputName(src.name, opt.target)
        val zf = try { ZipFile(src) } catch (e: Exception) {
            rep.issues += Issue("ERROR", src.name, tr("Не вдалося відкрити архів (пошкоджений або не ZIP): ${e.message}", "Не удалось открыть архив (повреждён или не ZIP): ${e.message}"))
            return rep
        }
        try { zf.use { process(it, src, out, opt, rep, isCancelled, progress) } }
        catch (e: Exception) {
            rep.issues += Issue("ERROR", src.name, tr("Збій під час обробки: ${e.message}", "Сбой при обработке: ${e.message}"))
        }
        return rep
    }

    private fun strictUtf8(b: ByteArray): String? = try {
        Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString()
    } catch (e: CharacterCodingException) { null }

    private fun isJunk(rel: String) =
        rel.startsWith("__MACOSX/") || rel.endsWith(".DS_Store") || rel.endsWith("Thumbs.db")

    private fun norm(p: String): String? {
        val st = ArrayList<String>()
        for (s in p.replace('\\', '/').split('/')) {
            when (s) { "", "." -> {}; ".." -> { if (st.isEmpty()) return null; st.removeAt(st.size - 1) }; else -> st.add(s) }
        }
        return st.joinToString("/")
    }

    fun refsIn(text: String, isXml: Boolean, includeData: Boolean = false): List<String> {
        val r = ArrayList<String>()
        attrRe.findAll(text).forEach { r += it.groupValues[1] }
        if (isXml) elemRe.findAll(text).forEach { r += it.groupValues[1] }
        return r.filter { it.isNotBlank() && !it.contains("://") && (!it.contains('$') || (includeData && it.startsWith("\$data/"))) }
    }

    private fun fixModDesc(src: String, opt: Options, rep: ConvertReport, descV: String?, modName: String = ""): String {
        var t = src
        val m = Regex("<modDesc\\b[^>]*>").find(t)
        if (m == null) {
            rep.issues += Issue("ERROR", "modDesc.xml", tr("Не знайдено тег <modDesc>", "Не найден тег <modDesc>"))
            return t
        }
        var tag = m.value
        val old = Regex("descVersion\\s*=\\s*\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
        if (opt.target == "FS26") {
            tag = Regex("\\s+(descVersion|titleId)\\s*=\\s*\"[^\"]*\"").replace(tag, "")
            tag = tag.replaceFirst("<modDesc", "<modDesc descVersion=\"2\" titleId=\"fs26mobile\"")
            t = t.replaceRange(m.range, tag)
            rep.changes += "modDesc.xml: descVersion ${old ?: "—"} → 2, titleId=\"fs26mobile\""
        } else if (opt.target == "FS22") {
            t = Fs23Rules.fixModDesc(t, opt, rep, modName)
        } else if (descV != null && descV != old) {
            tag = Regex("\\s+descVersion\\s*=\\s*\"[^\"]*\"").replace(tag, "")
            tag = tag.replaceFirst("<modDesc", "<modDesc descVersion=\"$descV\"")
            t = t.replaceRange(m.range, tag)
            rep.changes += "modDesc.xml: descVersion ${old ?: "—"} → $descV (" + tr("з донора FS23", "из донора FS23") + ")"
        } else rep.issues += Issue("WARN", "modDesc.xml", tr("FS23: донора з modDesc немає — descVersion не змінено", "FS23: донора с modDesc нет — descVersion не изменён"))
        if (opt.signEnabled && opt.signNick.isNotBlank()) t = sign(t, opt.signNick, rep)
        if (opt.renameFs && opt.target != "FS22") {
            val before = t
            t = Regex("(?s)<title>.*?</title>").replace(t) { it.value.replace("FS25", opt.target).replace("FS 25", "FS " + opt.target.removePrefix("FS")) }
            if (t != before) rep.changes += tr("modDesc.xml: назву в <title> FS25 → FS26", "modDesc.xml: название в <title> FS25 → FS26")
        }
        if (opt.trimLang) {
            val before = t
            t = Regex("(?s)[ \\t]*<(de|fr|es|it|pl|cz|cs|hu|nl|pt|tr|jp|kr|zh|ct|fi|da|sv|ro)>.*?</\\1>[ \\t]*\\r?\\n?").replace(t, "")
            if (t != before) rep.changes += tr("modDesc.xml: прибрано зайві мови (залишено en/ru/uk/br)", "modDesc.xml: убраны лишние языки (оставлено en/ru/uk/br)")
        }
        return t
    }

    private val STORED_EXT = setOf("png", "ogg", "jpg", "jpeg", "mp3", "zip", "mp4")
    private fun lvl(n: String) = if (n.substringAfterLast('.', "").lowercase() in STORED_EXT) 0 else 6

    /** Видимий підпис (author) + прихований маркер для перевірки нашою ж програмою. Гру це не обмежує і не захищає від видалення. */
    private fun sign(xml: String, nick0: String, rep: ConvertReport): String {
        val badChars = Regex("[<>&\"]")
        val nick = badChars.replace(nick0.take(40), "")
        var t = xml
        var sum = 0L
        for (c in nick) sum = sum * 31 + c.code
        val sig = (sum and 0xFFFFFFFL).toString(16)
        val marker = "<!-- DON1500-SIGNATURE nick=\"" + nick + "\" sig=\"" + sig + "\" -->"
        val existing = Regex("<!--\\s*DON1500-SIGNATURE[^>]*-->")
        t = if (existing.containsMatchIn(t)) existing.replace(t, marker)
        else Regex("(<modDesc\\b[^>]*>)").replace(t, "$1\n    " + Regex.escapeReplacement(marker))
        val authorTag = Regex("<author>.*?</author>", RegexOption.DOT_MATCHES_ALL)
        t = if (authorTag.containsMatchIn(t)) authorTag.replace(t, "<author>" + nick + "</author>")
        else t.replaceFirst(marker, marker + "\n    <author>" + nick + "</author>")
        rep.changes += tr("Підпис «" + nick + "» додано (author + мітка DON1500-SIGNATURE)", "Подпись «" + nick + "» добавлена (author + метка DON1500-SIGNATURE)")
        return t
    }

    private fun process(z: ZipFile, src: File, out: File?, opt: Options, rep: ConvertReport, isCancelled: () -> Boolean, progress: (String, Float) -> Unit) {
        val files = ArrayList<Pair<String, ZipEntry>>()
        val en = z.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (e.isDirectory) continue
            val n = e.name.replace('\\', '/').trimStart('/')
            if (n.split('/').any { it == ".." }) {
                rep.issues += Issue("ERROR", e.name, tr("Небезпечний шлях в архіві (..) — пропущено", "Опасный путь в архиве (..) — пропущено")); continue
            }
            files += n to e
        }
        rep.entries = files.size
        val mdPath = files.map { it.first }.filter { it.substringAfterLast('/') == "modDesc.xml" }
            .minByOrNull { p -> p.count { it == '/' } }
        val gen = if (mdPath == null) Repack.synthesize(files.map { it.first }, src.name) else null
        if (mdPath == null && gen == null) {
            rep.type = tr("невідомо", "неизвестно")
            rep.issues += Issue("ERROR", src.name, tr("Немає ні modDesc.xml, ні map.xml — не вдалося визначити, що це за мод/карта", "Нет ни modDesc.xml, ни map.xml — не удалось определить, что это за мод/карта"))
            return
        }
        val virtualMd: String? = gen?.first
        if (virtualMd != null) rep.changes += tr("modDesc.xml створено автоматично за map.xml (дані гри / розпакована карта)", "modDesc.xml создан автоматически по map.xml (данные игры / распакованная карта)")
        val root = if (mdPath != null) mdPath.substringBeforeLast('/', "") else gen!!.second.first
        if (mdPath == null) {
            val icon = gen!!.second.second
            rep.changes += if (icon != null) tr("Знайдено іконку карти: $icon", "Найдена иконка карты: $icon") else tr("⚠ Іконку карти не знайдено автоматично — додайте iconFilename вручну, якщо карта не з'явиться коректно", "⚠ Иконка карты не найдена автоматически — добавьте iconFilename вручную, если карта не появится корректно")
        }
        val prefix = if (root.isEmpty()) "" else "$root/"
        if (root.isNotEmpty()) rep.changes += tr("Верхню папку «$root» прибрано: modDesc.xml тепер у корені архіву", "Верхняя папка «$root» убрана: modDesc.xml теперь в корне архива")

        if (out != null) {
            val free = (out.parentFile ?: out).usableSpace
            if (free < src.length() + 64L * 1024 * 1024) {
                rep.issues += Issue("ERROR", out.name, tr("Недостатньо вільного місця: ${Fs.human(free)}", "Недостаточно свободного места: ${Fs.human(free)}")); return
            }
        }

        val mdText = if (mdPath != null) z.getInputStream(z.getEntry(files.first { it.first == mdPath }.second.name)).use { it.readBytes() }.toString(Charsets.UTF_8) else virtualMd!!
        val luaCount = files.count { it.first.endsWith(".lua", true) }
        rep.type = when {
            "<maps>" in mdText -> tr("Карта", "Карта")
            luaCount > 0 || "<extraSourceFiles>" in mdText -> tr("Скриптовий мод", "Скриптовый мод")
            else -> tr("Техніка / обладнання / об'єкти", "Техника / оборудование / объекты")
        }
        if (luaCount > 0) rep.issues += Issue("WARN", "*.lua", tr("Скрипти ($luaCount) автоматично не конвертуються — потрібна ручна перевірка API FS26 Mobile", "Скрипты ($luaCount) автоматически не конвертируются — нужна ручная проверка API FS26 Mobile"))

        val outNames = HashSet<String>()
        var outside = 0
        for ((n, _) in files) {
            if (!n.startsWith(prefix)) { outside++; continue }
            val rel = n.removePrefix(prefix)
            if (isJunk(rel)) continue
            outNames += if (rel.endsWith(".dds", true) && opt.target == "FS26") rel.dropLast(4) + ".png" else rel
        }
        if (outside > 0) rep.issues += Issue("WARN", "", tr("$outside файл(ів) поза папкою мода — не включено", "$outside файл(ов) вне папки мода — не включено"))
        val dupRe = Regex("^(.*)\\s?\\(\\d+\\)(\\.[^/.]+)$")
        for (n in outNames.toList()) {
            val m = dupRe.find(n) ?: continue
            val orig = m.groupValues[1].trimEnd() + m.groupValues[2]
            if (orig in outNames) rep.issues += Issue("WARN", n, tr("Схоже на дублікат «$orig» — перевірте й видаліть зайве вручну", "Похоже на дубликат «$orig» — проверьте и удалите лишнее вручную"))
        }

        val d23 = if (opt.target == "FS23") DonorLib.descVersion(opt.donors) else null
        val modName = (out?.name ?: outputName(src.name, opt.target)).removeSuffix(".zip")
        if (opt.target == "FS22") {
            rep.changes += tr("Режим FS22 → FS23 Mobile: правила з інструкції (шляхи mapUS/mapFR → map, map.xml, farmlands, modDesc, MapFrameFix.lua)", "Режим FS22 → FS23 Mobile: правила из инструкции (пути mapUS/mapFR → map, map.xml, farmlands, modDesc, MapFrameFix.lua)")
            if (Donor.count == 0) rep.issues += Issue("WARN", "FS23", tr("Дані гри FS23 не завантажено («APK / ДАНІ ГРИ»): шляхи \$data не перевіряються, підстановки лише за таблицями інструкції", "Данные игры FS23 не загружены («APK / ДАННЫЕ ИГРЫ»): пути \$data не проверяются, подстановки только по таблицам инструкции"))
            if (files.any { it.first.endsWith(".dds", true) }) rep.issues += Issue("WARN", "*.dds", tr("Власні .dds карти не перетворюються: формат текстур FS23 Mobile для модів не підтверджено", "Собственные .dds карты не преобразуются: формат текстур FS23 Mobile для модов не подтверждён"))
        }
        if (opt.target == "FS23") rep.issues += Issue("WARN", "FS23", tr("Ціль FS23 експериментальна: правил конвертації немає — змінюється лише descVersion (з донора) і добираються файли з донорів", "Цель FS23 экспериментальная: правил конвертации нет — меняется только descVersion (из донора) и добираются файлы из доноров"))
        val zout = out?.let { ZipOutputStream(BufferedOutputStream(FileOutputStream(it), 1 shl 16)).apply { setLevel(Deflater.BEST_SPEED) } }
        val written = HashSet<String>()
        val refs = LinkedHashSet<Pair<String, String>>()
        fun put(name: String, bytes: ByteArray) {
            if (zout == null) return
            if (!written.add(name)) { rep.issues += Issue("WARN", name, tr("Дублікат запису — пропущено", "Дубликат записи — пропущено")); return }
            zout.setLevel(lvl(name)); zout.putNextEntry(ZipEntry(name)); zout.write(bytes); zout.closeEntry()
        }
        try {
            val total = files.size.coerceAtLeast(1)
            val totalBytes = files.filter { it.first.startsWith(prefix) }.sumOf { it.second.size.coerceAtLeast(0L) }.coerceAtLeast(1L)
            var doneBytes = 0L
            var i = 0
            for ((n, e) in files) {
                i++
                if (isCancelled()) { rep.cancelled = true; break }
                if (!n.startsWith(prefix)) continue
                val rel = n.removePrefix(prefix)
                if (isJunk(rel)) { rep.changes += tr("Службовий файл пропущено: $rel", "Служебный файл пропущен: $rel"); continue }
                if (opt.target == "FS22" && Fs23Rules.isCache(rel)) { rep.changes += tr("Кеш пропущено (гра створить заново): $rel", "Кэш пропущен (игра создаст заново): $rel"); continue }
                doneBytes += e.size.coerceAtLeast(0L)
                progress("[$i/$total] $rel", (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f))
                val ext = rel.substringAfterLast('.', "").lowercase()
                when {
                    ext == "dds" && opt.target == "FS26" -> {
                        val bytes = z.getInputStream(e).use { it.readBytes() }
                        val pngName = rel.dropLast(4) + ".png"
                        if (zout == null) {
                            val err = Dds.probe(bytes)
                            if (err != null) { rep.issues += Issue("ERROR", rel, tr("DDS не вдасться перетворити: $err", "DDS не удастся преобразовать: $err")); outNames.remove(pngName) }
                        } else {
                            val r = Dds.decode(bytes, opt.maxTex)
                            if (r.png != null) {
                                if (pngName in written) rep.issues += Issue("WARN", pngName, tr("PNG уже існує — DDS не перетворювався", "PNG уже существует — DDS не преобразовывался"))
                                else { put(pngName, r.png); rep.ddsConverted++; rep.changes += "DDS→PNG: $rel (${r.w}x${r.h})" }
                            } else {
                                rep.issues += Issue("ERROR", rel, tr("DDS не вдалося перетворити: ${r.error}. Оригінал збережено; потрібен PNG: $pngName", "DDS не удалось преобразовать: ${r.error}. Оригинал сохранён; нужен PNG: $pngName"))
                                outNames.remove(pngName); put(rel, bytes)
                            }
                        }
                    }
                    (ext == "xml" || ext == "i3d") && e.size <= MAX_TEXT -> {
                        val bigFile = e.size > 15_000_000L
                        if (bigFile) progress(tr("$rel (${Fs.human(e.size)}) — великий файл, обробка займе час…", "$rel (${Fs.human(e.size)}) — большой файл, обработка займёт время…"), (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f))
                        val raw = z.getInputStream(e).use { it.readBytes() }
                        val text = strictUtf8(raw)
                        if (text == null) {
                            rep.issues += Issue("WARN", rel, tr("Не UTF-8 — скопійовано без змін", "Не UTF-8 — скопировано без изменений"))
                            put(rel, raw)
                        } else {
                            var t = text
                            val hadBom = t.startsWith("\uFEFF")
                            if (hadBom) t = t.substring(1)
                            if (rel == "modDesc.xml") t = fixModDesc(t, opt, rep, d23, modName)
                            if (opt.target == "FS26") {
                                var cnt = 0
                                t = ddsRe.replace(t) { cnt++; ".png" }
                                if (cnt > 0) { rep.textureRewrites += cnt; rep.changes += tr("$rel: посилань .dds→.png: $cnt", "$rel: ссылок .dds→.png: $cnt") }
                            }
                            if (opt.target == "FS22") t = Fs23Rules.fixText(rel, t, rep)
                            if (hadBom) rep.changes += tr("$rel: прибрано BOM", "$rel: убран BOM")
                            if (!bigFile) refsIn(t, ext == "xml", true).forEach { refs += rel to it }
                            else rep.issues += Issue("WARN", rel, tr("Великий файл (${Fs.human(e.size)}) — посилання в ньому не перевірялись (для швидкості)", "Большой файл (${Fs.human(e.size)}) — ссылки в нём не проверялись (для скорости)"))
                            put(rel, if (t == text) raw else t.toByteArray(Charsets.UTF_8))
                        }
                    }
                    ext == "lua" && zout != null -> {
                        val raw = z.getInputStream(e).use { it.readBytes() }
                        if (raw.size < 20_000_000 && Regex("\\.dds", RegexOption.IGNORE_CASE).containsMatchIn(raw.toString(Charsets.ISO_8859_1)))
                            rep.issues += Issue("WARN", rel, tr("Скрипт згадує .dds — перевірте вручну", "Скрипт упоминает .dds — проверьте вручную"))
                        put(rel, raw)
                    }
                    else -> {
                        if (zout != null) {
                            if (!written.add(rel)) { rep.issues += Issue("WARN", rel, tr("Дублікат запису — пропущено", "Дубликат записи — пропущено")) }
                            else {
                                zout.setLevel(lvl(rel)); zout.putNextEntry(ZipEntry(rel))
                                val sz = e.size.coerceAtLeast(0L)
                                if (sz > 10_000_000L) {
                                    // Великий бінарний файл (.shapes, .gdm тощо) — оновлюємо відсоток прямо під час копіювання, а не лише до/після.
                                    val buf = ByteArray(1 shl 16)
                                    var copied = 0L; var lastShown = -1
                                    z.getInputStream(e).use { ins ->
                                        while (true) {
                                            val n = ins.read(buf); if (n < 0) break
                                            zout.write(buf, 0, n); copied += n
                                            val within = if (sz > 0) (copied.toFloat() / sz) else 0f
                                            val overall = ((doneBytes - sz + copied).toFloat() / totalBytes).coerceIn(0f, 1f)
                                            val pct = (within * 100).toInt()
                                            if (pct != lastShown) { lastShown = pct; progress("$rel — ${Fs.human(copied)} / ${Fs.human(sz)}", overall) }
                                        }
                                    }
                                } else z.getInputStream(e).use { it.copyTo(zout, 1 shl 16) }
                                zout.closeEntry()
                            }
                        }
                    }
                }
            }
            if (opt.target == "FS22" && !rep.cancelled) {
                for ((nm, bytes) in Fs23Rules.extraFiles(mdText)) {
                    if (nm in written) continue
                    put(nm, bytes); outNames += nm
                    rep.changes += tr("Додано файл: $nm", "Добавлен файл: $nm")
                }
            }
            if (virtualMd != null) {
                var vt = fixModDesc(virtualMd, opt, rep, d23, modName)
                if (opt.target == "FS26") vt = ddsRe.replace(vt, ".png")
                refsIn(vt, true, true).forEach { refs += "modDesc.xml" to it }
                outNames += "modDesc.xml"
                put("modDesc.xml", vt.toByteArray(Charsets.UTF_8))
            }
        } finally { zout?.close() }
        if (rep.cancelled) {
            out?.delete()
            rep.issues += Issue("WARN", rep.sourceName, tr("Скасовано користувачем; незавершений архів видалено", "Отменено пользователем; незавершённый архив удалён"))
            return
        }

        // Перевірка посилань
        val lower = HashMap<String, String>()
        outNames.forEach { lower[it.lowercase()] = it }
        for ((from, ref) in refs) {
            if (ref.startsWith("\$data/")) { if (Donor.count > 0 && !Donor.has(ref)) rep.missingData.putIfAbsent(ref, from); continue }
            val c1 = norm(ref)
            val dir = from.substringBeforeLast('/', "")
            val c2 = norm(if (dir.isEmpty()) ref else "$dir/$ref")
            if ((c1 != null && c1 in outNames) || (c2 != null && c2 in outNames)) continue
            val ci = listOfNotNull(c1, c2).firstNotNullOfOrNull { lower[it.lowercase()] }
            if (ci != null) rep.issues += Issue("WARN", from, tr("Регістр не збігається: «$ref» ≠ «$ci» (на Android регістр важливий)", "Регистр не совпадает: «$ref» ≠ «$ci» (на Android регистр важен)"))
            else rep.missing.putIfAbsent(c1 ?: ref, from)
        }

        if (out != null && opt.donors.isNotEmpty() && rep.missing.isNotEmpty()) {
            progress(tr("Беремо відсутні файли з донорів…", "Берём отсутствующие файлы из доноров…"), 1f)
            try { DonorFill.fill(File(out.parentFile, ".fill").also { it.mkdirs() }, out, rep, opt) }
            catch (e: Exception) { rep.issues += Issue("ERROR", out.name, tr("Збій добору з донора: ${e.message}", "Сбой добора из донора: ${e.message}")) }
        }

        if (out != null) {
            progress(tr("Перевірка архіву…", "Проверка архива…"), 1f)
            val err = ZipTools.verify(out)
            if (err != null) rep.issues += Issue("ERROR", out.name, tr("Вихідний ZIP не пройшов перевірку: $err", "Выходной ZIP не прошёл проверку: $err"))
            else {
                val ok = try { ZipFile(out).use { it.getEntry("modDesc.xml") != null } } catch (e: Exception) { false }
                if (!ok) rep.issues += Issue("ERROR", out.name, tr("У результаті немає modDesc.xml в корені", "В результате нет modDesc.xml в корне"))
                rep.verified = ok
            }
        }
    }
}
