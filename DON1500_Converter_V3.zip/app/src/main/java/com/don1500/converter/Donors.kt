@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/** Бібліотека донорів: робочі моди/карти для FS26 та FS23, з яких беруться відсутні файли. */
object DonorLib {
    fun dir(ctx: Context, target: String): File = File(Fs.base(ctx), "donors/" + target.lowercase()).also { it.mkdirs() }
    fun list(ctx: Context, target: String): List<File> =
        dir(ctx, target).listFiles()?.filter { it.extension.equals("zip", true) }?.sortedBy { it.name } ?: emptyList()

    /** descVersion першого знайденого донора (для цілі FS23). */
    fun descVersion(donors: List<File>): String? {
        for (d in donors) {
            try {
                ZipFile(d).use { z ->
                    var bestName: String? = null
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (!e.isDirectory && e.name.substringAfterLast('/') == "modDesc.xml") {
                            val cur = bestName
                            if (cur == null || e.name.count { it == '/' } < cur.count { it == '/' }) bestName = e.name
                        }
                    }
                    val bn = bestName
                    if (bn != null) {
                        val t = z.getInputStream(z.getEntry(bn)).use { it.readBytes() }.toString(Charsets.UTF_8)
                        val m = Regex("descVersion\\s*=\\s*\"([^\"]+)\"").find(t)
                        if (m != null) return m.groupValues[1]
                    }
                }
            } catch (_: Exception) { }
        }
        return null
    }
}

object DonorFill {
    private fun norm(p: String) = p.replace('\\', '/').trimStart('/')

    /** Бере з донорів файли, яких бракує у результаті, і дописує їх у вихідний ZIP. */
    fun fill(tmpDir: File, out: File, rep: ConvertReport, opt: Options) {
        val want = rep.missing.keys.toList()
        if (want.isEmpty() || opt.donors.isEmpty()) return
        val adds = LinkedHashMap<String, File>()
        for (d in opt.donors) {
            val zf = try { ZipFile(d) } catch (e: Exception) {
                rep.issues += Issue("WARN", d.name, tr("Донор не відкрився: ${e.message}", "Донор не открылся: ${e.message}")); continue
            }
            zf.use { z ->
                val names = ArrayList<String>()
                val en = z.entries()
                while (en.hasMoreElements()) { val e = en.nextElement(); if (!e.isDirectory) names += norm(e.name) }
                val md = names.filter { it.substringAfterLast('/') == "modDesc.xml" }.minByOrNull { p -> p.count { it == '/' } }
                val root = md?.substringBeforeLast('/', "") ?: ""
                val prefix = if (root.isEmpty()) "" else "$root/"
                val byPath = HashMap<String, String>()
                val byName = HashMap<String, MutableList<String>>()
                for (nm in names) {
                    if (!nm.startsWith(prefix)) continue
                    val rel = nm.removePrefix(prefix).lowercase()
                    byPath[rel] = nm
                    byName.getOrPut(rel.substringAfterLast('/')) { mutableListOf() }.add(nm)
                }
                for (m in want) {
                    if (m in adds) continue
                    val ml = m.lowercase()
                    val alt = if (ml.endsWith(".png")) ml.dropLast(4) + ".dds" else null
                    var found: String? = byPath[ml] ?: (if (alt != null) byPath[alt] else null)
                    var how = "path"
                    if (found == null && opt.donorByName) {
                        val cand = byName[ml.substringAfterLast('/')] ?: (if (alt != null) byName[alt.substringAfterLast('/')] else null)
                        if (cand != null && cand.size == 1) { found = cand[0]; how = "name" }
                    }
                    if (found == null) continue
                    val entry: ZipEntry = z.getEntry(found) ?: continue
                    val tmp = File(tmpDir, "fill_${adds.size}.bin")
                    try {
                        if (found.endsWith(".dds", true) && m.endsWith(".png", true)) {
                            val r = Dds.decode(z.getInputStream(entry).use { it.readBytes() }, opt.maxTex)
                            if (r.png == null) { rep.issues += Issue("WARN", m, tr("З донора ${d.name}: DDS не перетворився (${r.error})", "Из донора ${d.name}: DDS не преобразовался (${r.error})")); continue }
                            tmp.writeBytes(r.png)
                        } else {
                            z.getInputStream(entry).use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                        }
                    } catch (e: Exception) { rep.issues += Issue("WARN", m, "donor: ${e.message}"); continue }
                    adds[m] = tmp
                    rep.changes += tr("Із донора ${d.name}: $m", "Из донора ${d.name}: $m")
                    if (how == "name") rep.issues += Issue("WARN", m, tr("Знайдено лише за назвою («$found» у ${d.name}) — перевірте, що підходить", "Найдено только по названию («$found» в ${d.name}) — проверьте, что подходит"))
                }
            }
        }
        if (adds.isNotEmpty()) {
            ZipTools.addMany(out, adds)
            adds.keys.forEach { rep.missing.remove(it) }
        }
        tmpDir.deleteRecursively()
    }
}

@Composable
fun DonorsScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var cur by remember { mutableStateOf("") }
    var prog by remember { mutableStateOf(0f) }
    var msg by remember { mutableStateOf("") }
    var slot by remember { mutableStateOf("FS26") }
    var byName by remember { mutableStateOf(store.donorByName) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""; prog = 0f
            try {
                val name = Fs.displayName(ctx, uri)
                val size = Fs.sizeOf(ctx, uri)
                val dir = DonorLib.dir(ctx, slot)
                if (size > 0 && dir.usableSpace < size + 64L * 1024 * 1024) throw java.io.IOException(tr("Недостатньо вільного місця", "Недостаточно свободного места"))
                val dest = File(dir, name)
                var last = -1
                withContext(Dispatchers.IO) {
                    Fs.copyUri(ctx, uri, dest) { b ->
                        val pc = if (size > 0) (b * 100 / size).toInt() else 0
                        if (pc != last) { last = pc; prog = pc / 100f; cur = Fs.human(b) }
                    }
                    try { ZipFile(dest).close() } catch (e: Exception) { dest.delete(); throw java.io.IOException(tr("Це не ZIP або файл пошкоджений", "Это не ZIP или файл повреждён")) }
                }
                msg = "✔ " + tr("Донор додано в $slot: $name", "Донор добавлен в $slot: $name")
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false; tick++
        }
    }
    Frame(tr("Донори", "Доноры"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Text(tr("Донор — це робочий мод або карта для потрібної версії гри. Під час конвертації програма бере з донорів файли, яких бракує (текстури, звуки, моделі, XML), і пакує їх у результат. Збіг шукається за шляхом, потім (якщо ввімкнено) за унікальною назвою файлу. Кожну підстановку програма записує у звіт.", "Донор — это рабочий мод или карта для нужной версии игры. При конвертации программа берёт из доноров недостающие файлы (текстуры, звуки, модели, XML) и пакует их в результат. Совпадение ищется по пути, затем (если включено) по уникальному имени файла. Каждую подстановку программа записывает в отчёт."), fontSize = 12.sp)
            Text(tr("Це бібліотека файлів, а не навчання ШІ. Користуйтесь лише тими файлами, на які маєте право.", "Это библиотека файлов, а не обучение ИИ. Пользуйтесь только теми файлами, на которые имеете право."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Text(tr("Шукати також за назвою файлу", "Искать также по имени файла"), Modifier.weight(1f), fontSize = 13.sp)
                Switch(byName, { byName = it; store.donorByName = it })
            }
            for (t in listOf("FS26", "FS23")) {
                val list = remember(tick, t) { DonorLib.list(ctx, t) }
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(tr("Донори $t", "Доноры $t") + " (${list.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        list.forEach { f ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(f.name, fontSize = 13.sp); Text(Fs.human(f.length()), fontSize = 11.sp) }
                                TextButton(onClick = { f.delete(); tick++ }) { Text(tr("Видалити", "Удалить")) }
                            }
                        }
                        if (list.isEmpty()) Text(tr("Порожньо", "Пусто"), fontSize = 12.sp)
                        Button(enabled = !busy, onClick = { slot = t; picker.launch(arrayOf("*/*")) }, modifier = Modifier.padding(top = 6.dp)) {
                            Text(tr("Додати донор ($t): ZIP карти або мода", "Добавить донор ($t): ZIP карты или мода"))
                        }
                    }
                }
            }
            if (busy) { LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)); Text("${(prog * 100).toInt()}% · $cur", fontSize = 12.sp) }
            if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
