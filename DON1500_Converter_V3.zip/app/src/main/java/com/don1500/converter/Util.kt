package com.don1500.converter

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.*
import java.util.zip.*

/** Мова інтерфейсу: tr("укр", "рус") */
object Lang { var uk by mutableStateOf(true) }
fun tr(uk: String, ru: String) = if (Lang.uk) uk else ru

/** Стан поточної сесії (останнє джерело, звіт, результат). */
object Session {
    var sourceFile by mutableStateOf<File?>(null)
    var report by mutableStateOf<ConvertReport?>(null)
    var reportText by mutableStateOf("")
    var outputZip by mutableStateOf<File?>(null)
    var rev by mutableStateOf(0)
}

/** Налаштування. API-ключі — лише в EncryptedSharedPreferences. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("don_prefs", Context.MODE_PRIVATE)
    private val secure: SharedPreferences? = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "don_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) { null }

    val secureAvailable get() = secure != null
    var uk: Boolean get() = p.getBoolean("uk", true); set(v) { p.edit().putBoolean("uk", v).apply() }
    var dark: Boolean get() = p.getBoolean("dark", true); set(v) { p.edit().putBoolean("dark", v).apply() }
    var renameFs: Boolean get() = p.getBoolean("renameFs", true); set(v) { p.edit().putBoolean("renameFs", v).apply() }
    var trimLang: Boolean get() = p.getBoolean("trimLang", false); set(v) { p.edit().putBoolean("trimLang", v).apply() }
    var provider: String get() = p.getString("provider", "OpenAI") ?: "OpenAI"; set(v) { p.edit().putString("provider", v).apply() }
    fun model(provider: String): String = p.getString("model_$provider", "") ?: ""
    fun setModel(provider: String, m: String) { p.edit().putString("model_$provider", m).apply() }
    fun getKey(provider: String): String = secure?.getString("key_$provider", "") ?: ""
    fun setKey(provider: String, key: String): Boolean {
        val s = secure ?: return false
        s.edit().putString("key_$provider", key).apply(); return true
    }
}

object Fs {
    fun base(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    fun work(ctx: Context): File = File(base(ctx), "work").also { it.mkdirs() }
    fun outDir(ctx: Context): File = File(base(ctx), "out").also { it.mkdirs() }

    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) { val n = it.getString(0); if (!n.isNullOrBlank()) return n }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    fun copyUri(ctx: Context, uri: Uri, dest: File, onBytes: (Long) -> Unit = {}) {
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("openInputStream = null")
        ins.use { i ->
            FileOutputStream(dest).use { o ->
                val b = ByteArray(1 shl 16); var t = 0L
                while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); t += n; onBytes(t) }
            }
        }
    }

    fun human(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> "%.1f KB".format(n / 1024.0)
        n < 1024L * 1024 * 1024 -> "%.1f MB".format(n / 1048576.0)
        else -> "%.2f GB".format(n / 1073741824.0)
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name); if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name); val ext = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) { f = File(dir, if (ext.isEmpty() || base == name) "$name ($i)" else "$base ($i).$ext"); i++ }
        return f
    }

    /** Кладе копію файлу в Download/DON1500 (без додаткових дозволів). */
    fun publish(ctx: Context, file: File, mime: String): String {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/DON1500")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            ?: throw IOException("MediaStore insert failed")
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o, 1 shl 16) } }
        return "Download/DON1500/${file.name}"
    }
}

object ZipTools {
    /** Розпаковка з захистом від zip-slip. Повертає кількість файлів. */
    fun unzip(zip: File, dest: File, progress: (String) -> Unit = {}): Int {
        dest.mkdirs()
        val destPath = dest.canonicalPath + File.separator
        var n = 0
        ZipInputStream(BufferedInputStream(FileInputStream(zip), 1 shl 16)).use { zi ->
            while (true) {
                val e = zi.nextEntry ?: break
                val target = File(dest, e.name.replace('\\', '/'))
                if (!target.canonicalPath.startsWith(destPath)) continue
                if (e.isDirectory) { target.mkdirs(); continue }
                target.parentFile?.mkdirs()
                progress(e.name)
                FileOutputStream(target).use { zi.copyTo(it, 1 shl 16) }
                n++
            }
        }
        return n
    }

    fun zipPaths(items: List<File>, out: File, contentsAtRoot: Boolean, progress: (String) -> Unit = {}) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 1 shl 16)).use { zo ->
            fun add(f: File, rel: String) {
                if (f.isDirectory) {
                    f.listFiles()?.sortedBy { it.name }?.forEach { add(it, "$rel/${it.name}") }
                } else {
                    progress(rel)
                    zo.putNextEntry(ZipEntry(rel))
                    f.inputStream().use { it.copyTo(zo, 1 shl 16) }
                    zo.closeEntry()
                }
            }
            for (f in items) {
                if (contentsAtRoot && f.isDirectory) f.listFiles()?.forEach { add(it, it.name) } else add(f, f.name)
            }
        }
    }

    /** Додає/замінює один файл у ZIP (потокове перезаписування). */
    fun addOrReplace(zip: File, entryName: String, bytes: ByteArray) {
        val tmp = File(zip.parentFile, zip.name + ".tmp")
        ZipFile(zip).use { z ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)).use { zo ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.name == entryName) continue
                    zo.putNextEntry(ZipEntry(e.name))
                    if (!e.isDirectory) z.getInputStream(e).use { it.copyTo(zo, 1 shl 16) }
                    zo.closeEntry()
                }
                zo.putNextEntry(ZipEntry(entryName)); zo.write(bytes); zo.closeEntry()
            }
        }
        zip.delete()
        if (!tmp.renameTo(zip)) throw IOException("rename failed")
    }

    /** Перевірка цілісності (CRC усіх записів). Повертає null, якщо все гаразд. */
    fun verify(zip: File): String? = try {
        val buf = ByteArray(1 shl 16)
        ZipInputStream(BufferedInputStream(FileInputStream(zip), 1 shl 16)).use { zi ->
            while (zi.nextEntry != null) { while (zi.read(buf) >= 0) { } }
        }
        null
    } catch (e: Exception) { e.message ?: "ZIP error" }
}
