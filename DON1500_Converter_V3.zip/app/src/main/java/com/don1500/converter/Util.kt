package com.don1500.converter

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import android.os.Vibrator
import java.io.*
import java.util.zip.*

/** Мова інтерфейсу: tr("укр", "рус") */
object Lang { var uk by mutableStateOf(true) }
fun tr(uk: String, ru: String) = if (Lang.uk) uk else ru

/** Стан поточної сесії (останнє джерело, звіт, результат). */
object Session {
    var sourceFile by mutableStateOf<File?>(null)
    var report by mutableStateOf<ConvertReport?>(null)
    var reportText by mutableStateOf("")
    var outputZip by mutableStateOf<File?>(null)
    var rev by mutableStateOf(0)
    var aiAttach by mutableStateOf("")
    var pending by mutableStateOf("")
    var aiFile by mutableStateOf<File?>(null)
    val chat = mutableStateListOf<ChatMsg>()
}

data class ChatMsg(val role: String, val text: String, val api: String = text)

data class Profile(val id: String, val name: String, val provider: String, val model: String, val key: String, val baseUrl: String = "")

/** Налаштування. API-ключі — лише в EncryptedSharedPreferences. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("don_prefs", Context.MODE_PRIVATE)
    private val secure: SharedPreferences? = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "don_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) { null }

    val secureAvailable get() = secure != null
    var uk: Boolean get() = p.getBoolean("uk", true); set(v) { p.edit().putBoolean("uk", v).apply() }
    var dark: Boolean get() = p.getBoolean("dark", true); set(v) { p.edit().putBoolean("dark", v).apply() }
    var renameFs: Boolean get() = p.getBoolean("renameFs", true); set(v) { p.edit().putBoolean("renameFs", v).apply() }
    var trimLang: Boolean get() = p.getBoolean("trimLang", false); set(v) { p.edit().putBoolean("trimLang", v).apply() }
    var provider: String get() = p.getString("provider", "OpenAI") ?: "OpenAI"; set(v) { p.edit().putString("provider", v).apply() }
    fun model(provider: String): String = p.getString("model_$provider", "") ?: ""
    fun setModel(provider: String, m: String) { p.edit().putString("model_$provider", m).apply() }
    fun getKey(provider: String): String = secure?.getString("key_$provider", "") ?: ""
    fun setKey(provider: String, key: String): Boolean {
        val s = secure ?: return false
        s.edit().putString("key_$provider", key).apply(); return true
    }

    var target: String get() = p.getString("target", "FS26") ?: "FS26"; set(v) { p.edit().putString("target", v).apply() }
    var donorByName: Boolean get() = p.getBoolean("donorByName", true); set(v) { p.edit().putBoolean("donorByName", v).apply() }
    var accent: String get() = p.getString("accent", "orange") ?: "orange"; set(v) { p.edit().putString("accent", v).apply() }
    var vibeLevel: Int get() = p.getInt("vibeLevel", 1); set(v) { p.edit().putInt("vibeLevel", v).apply() }
    var signNick: String get() = p.getString("signNick", "") ?: ""; set(v) { p.edit().putString("signNick", v).apply() }
    var signEnabled: Boolean get() = p.getBoolean("signEnabled", false); set(v) { p.edit().putBoolean("signEnabled", v).apply() }
    var maxTex: Int get() = p.getInt("maxTex", 2048); set(v) { p.edit().putInt("maxTex", v).apply() }
    var activeProfile: String get() = p.getString("activeProfile", "") ?: ""; set(v) { p.edit().putString("activeProfile", v).apply() }

    fun profiles(): List<Profile> {
        val s = secure?.getString("profiles", "[]") ?: "[]"
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Profile(o.getString("id"), o.optString("name"), o.optString("provider", "OpenAI"), o.optString("model"), o.optString("key"), o.optString("baseUrl"))
            }
        } catch (e: Exception) { emptyList() }
    }

    fun saveProfiles(l: List<Profile>): Boolean {
        val s = secure ?: return false
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("provider", it.provider).put("model", it.model).put("key", it.key).put("baseUrl", it.baseUrl)) }
        s.edit().putString("profiles", a.toString()).apply()
        return true
    }
}

object Fs {
    fun base(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    fun work(ctx: Context): File = File(base(ctx), "work").also { it.mkdirs() }
    fun outDir(ctx: Context): File = File(base(ctx), "out").also { it.mkdirs() }

    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) { val n = it.getString(0); if (!n.isNullOrBlank()) return n }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    fun sizeOf(ctx: Context, uri: Uri): Long {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
        }
        return -1L
    }

    fun subOf(ctx: Context, f: File): String {
        val p = f.parentFile ?: return ""
        return if (p == outDir(ctx)) "" else p.name
    }

    fun copyUri(ctx: Context, uri: Uri, dest: File, onBytes: (Long) -> Unit = {}) {
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("openInputStream = null")
        ins.use { i ->
            FileOutputStream(dest).use { o ->
                val b = ByteArray(1 shl 16); var t = 0L
                while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); t += n; onBytes(t) }
            }
        }
    }

    fun human(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> "%.1f KB".format(n / 1024.0)
        n < 1024L * 1024 * 1024 -> "%.1f MB".format(n / 1048576.0)
        else -> "%.2f GB".format(n / 1073741824.0)
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name); if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name); val ext = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) { f = File(dir, if (ext.isEmpty() || base == name) "$name ($i)" else "$base ($i).$ext"); i++ }
        return f
    }

    /** Кладе копію файлу в Download/DON1500/<sub> (без додаткових дозволів). */
    fun publish(ctx: Context, file: File, mime: String, sub: String = ""): String {
        val rel = "Download/DON1500" + (if (sub.isNotEmpty()) "/$sub" else "")
        try {
            ctx.contentResolver.delete(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?",
                arrayOf(file.name, "$rel/")
            )
        } catch (_: Exception) { }
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, rel)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            ?: throw IOException("MediaStore insert failed")
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o, 1 shl 16) } }
        return "$rel/${file.name}"
    }
}

object ZipTools {
    /** Розпаковка з захистом від zip-slip. Повертає кількість файлів. */
    fun unzip(zip: File, dest: File, progress: (String) -> Unit = {}): Int {
        dest.mkdirs()
        val destPath = dest.canonicalPath + File.separator
        var n = 0
        ZipInputStream(BufferedInputStream(FileInputStream(zip), 1 shl 16)).use { zi ->
            while (true) {
                val e = zi.nextEntry ?: break
                val target = File(dest, e.name.replace('\\', '/'))
                if (!target.canonicalPath.startsWith(destPath)) continue
                if (e.isDirectory) { target.mkdirs(); continue }
                target.parentFile?.mkdirs()
                progress(e.name)
                FileOutputStream(target).use { zi.copyTo(it, 1 shl 16) }
                n++
            }
        }
        return n
    }

    fun zipPaths(items: List<File>, out: File, contentsAtRoot: Boolean, progress: (String) -> Unit = {}) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 1 shl 16)).use { zo ->
            fun add(f: File, rel: String) {
                if (f.isDirectory) {
                    f.listFiles()?.sortedBy { it.name }?.forEach { add(it, "$rel/${it.name}") }
                } else {
                    progress(rel)
                    zo.putNextEntry(ZipEntry(rel))
                    f.inputStream().use { it.copyTo(zo, 1 shl 16) }
                    zo.closeEntry()
                }
            }
            for (f in items) {
                if (contentsAtRoot && f.isDirectory) f.listFiles()?.forEach { add(it, it.name) } else add(f, f.name)
            }
        }
    }

    /** Дописує набір файлів у ZIP (потокове перезаписування). */
    fun addMany(zip: File, adds: Map<String, File>) {
        val tmp = File(zip.parentFile, zip.name + ".tmp")
        ZipFile(zip).use { z ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)).use { zo ->
                zo.setLevel(Deflater.BEST_SPEED)
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.name in adds) continue
                    zo.putNextEntry(ZipEntry(e.name))
                    if (!e.isDirectory) z.getInputStream(e).use { it.copyTo(zo, 1 shl 16) }
                    zo.closeEntry()
                }
                for ((n, f) in adds) { zo.putNextEntry(ZipEntry(n)); f.inputStream().use { it.copyTo(zo, 1 shl 16) }; zo.closeEntry() }
            }
        }
        zip.delete()
        if (!tmp.renameTo(zip)) throw IOException("rename failed")
    }

    /** Додає/замінює один файл у ZIP (потокове перезаписування). */
    fun addOrReplace(zip: File, entryName: String, bytes: ByteArray) {
        val tmp = File(zip.parentFile, zip.name + ".tmp")
        ZipFile(zip).use { z ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)).use { zo ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.name == entryName) continue
                    zo.putNextEntry(ZipEntry(e.name))
                    if (!e.isDirectory) z.getInputStream(e).use { it.copyTo(zo, 1 shl 16) }
                    zo.closeEntry()
                }
                zo.putNextEntry(ZipEntry(entryName)); zo.write(bytes); zo.closeEntry()
            }
        }
        zip.delete()
        if (!tmp.renameTo(zip)) throw IOException("rename failed")
    }

    /** Перевірка цілісності (CRC усіх записів). Повертає null, якщо все гаразд. */
    fun verify(zip: File): String? = try {
        val buf = ByteArray(1 shl 16)
        ZipInputStream(BufferedInputStream(FileInputStream(zip), 1 shl 16)).use { zi ->
            while (zi.nextEntry != null) { while (zi.read(buf) >= 0) { } }
        }
        null
    } catch (e: Exception) { e.message ?: "ZIP error" }
}

/** «Донор»: індекс файлів гри FS26 Mobile (з APK або ZIP папки data) для перевірки посилань $data/... */
object Donor {
    var count by mutableStateOf(0)
    var name by mutableStateOf("")
    private var idx = HashSet<String>()

    private fun addName(n0: String, into: HashSet<String>) {
        val n = n0.replace('\\', '/').lowercase()
        into.add(n)
        var i = n.indexOf("data/")
        while (i >= 0) {
            if (i == 0 || n[i - 1] == '/') into.add(n.substring(i + 5))
            i = n.indexOf("data/", i + 1)
        }
    }

    fun load(ctx: Context) {
        val f = File(Fs.base(ctx), "donor_index.txt")
        if (!f.exists()) return
        val s = HashSet<String>()
        f.forEachLine { s.add(it) }
        idx = s; count = s.size
        val nf = File(Fs.base(ctx), "donor_name.txt")
        name = if (nf.exists()) nf.readText() else ""
    }

    fun clear(ctx: Context) {
        idx = HashSet(); count = 0; name = ""
        File(Fs.base(ctx), "donor_index.txt").delete(); File(Fs.base(ctx), "donor_name.txt").delete()
    }

    fun build(ctx: Context, uri: Uri, label: String, onTick: (Int) -> Unit): Int {
        val s = HashSet<String>()
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("openInputStream = null")
        var n = 0
        ZipInputStream(BufferedInputStream(ins, 1 shl 16)).use { zi ->
            while (true) {
                val e = zi.nextEntry ?: break
                if (!e.isDirectory) { addName(e.name, s); n++; if (n % 500 == 0) onTick(n) }
            }
        }
        File(Fs.base(ctx), "donor_index.txt").bufferedWriter().use { w -> s.forEach { w.write(it); w.newLine() } }
        File(Fs.base(ctx), "donor_name.txt").writeText(label)
        idx = s; name = label; count = s.size
        return n
    }

    fun has(ref: String): Boolean {
        val p = ref.replace('\\', '/').lowercase().removePrefix("\$data/")
        if (p in idx) return true
        val dot = p.lastIndexOf('.')
        if (dot < 0) return false
        val b = p.substring(0, dot)
        val alt = when (p.substring(dot)) { ".png" -> ".dds"; ".dds" -> ".png"; else -> return false }
        return (b + alt) in idx
    }
}

class CountingStream(ins: InputStream) : FilterInputStream(ins) {
    var count = 0L
    override fun read(): Int { val r = super.read(); if (r >= 0) count++; return r }
    override fun read(b: ByteArray, off: Int, len: Int): Int { val r = super.read(b, off, len); if (r > 0) count += r; return r }
}

/** Реальна вібрація з керованою силою (на відміну від системних HapticFeedback-констант). level: 0=вимк, 1=слабка, 2=середня. */
object Haptics {
    fun tap(ctx: Context, store: Store) {
        val level = store.vibeLevel
        if (level <= 0) return
        try {
            val v: Vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                val m = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager
                m.defaultVibrator
            } else @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (!v.hasVibrator()) return
            val (dur, amp) = if (level == 1) 10L to 40 else 18L to 130
            if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(dur, amp))
            else @Suppress("DEPRECATION") v.vibrate(dur)
        } catch (_: Exception) { }
    }
}
