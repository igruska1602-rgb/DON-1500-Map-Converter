package com.don1500.converter

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    val providers = listOf("OpenAI", "Gemini", "Claude", "OpenRouter", "Groq", "Mistral", "Custom")

    fun defaultModel(p: String) = when (p) {
        "OpenAI" -> "gpt-4o-mini"
        "Gemini" -> "gemini-2.0-flash"
        "Claude" -> "claude-haiku-5-5"
        "OpenRouter" -> "openai/gpt-4o-mini"
        "Groq" -> "llama-3.3-70b-versatile"
        "Custom" -> ""
        else -> "mistral-small-latest"
    }

    class HttpEx(val code: Int, msg: String) : IOException(msg)

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw HttpEx(code, "HTTP $code: ${s.take(400)}")
        return s
    }

    private fun get(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"; c.connectTimeout = 15000; c.readTimeout = 30000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw HttpEx(code, "HTTP $code: ${s.take(300)}")
        return s
    }

    private fun baseFor(provider: String, baseUrl: String): String = when (provider) {
        "OpenAI" -> "https://api.openai.com/v1"
        "OpenRouter" -> "https://openrouter.ai/api/v1"
        "Groq" -> "https://api.groq.com/openai/v1"
        "Mistral" -> "https://api.mistral.ai/v1"
        else -> baseUrl.trim().trimEnd('/').removeSuffix("/chat/completions")
    }

    private val BAD = listOf("embed", "tts", "image", "audio", "live", "imagen", "veo", "aqa", "robotics", "moderation", "whisper", "dall", "transcribe", "realtime", "search", "guard", "vision")

    private fun score(provider: String, id: String): Double {
        val l = id.lowercase()
        val v = Regex("(\\d+(?:\\.\\d+)?)").find(l)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        var s = v * 10
        if (l.contains("preview") || l.contains("exp")) s -= 3
        if (provider == "Gemini") { if (l.contains("flash")) s += 2; if (l.contains("lite")) s -= 1; if (l.contains("pro")) s -= 1 }
        if (l.contains("mini") || l.contains("small") || l.contains("haiku")) s += 0.5
        return s
    }

    /** Список моделей, доступних для ключа (відсортований: найновіші першими). */
    fun listModels(provider: String, key: String, baseUrl: String): List<String> {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа", "Нет API-ключа"))
        val out = ArrayList<String>()
        when (provider) {
            "Gemini" -> {
                val r = JSONObject(get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", mapOf("x-goog-api-key" to key)))
                val a = r.optJSONArray("models") ?: JSONArray()
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val methods = o.optJSONArray("supportedGenerationMethods")
                    var ok = methods == null
                    if (methods != null) for (k in 0 until methods.length()) if (methods.getString(k) == "generateContent") ok = true
                    if (ok) out += o.getString("name").removePrefix("models/")
                }
            }
            "Claude" -> {
                val r = JSONObject(get("https://api.anthropic.com/v1/models?limit=100", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")))
                val a = r.optJSONArray("data") ?: JSONArray()
                for (i in 0 until a.length()) out += a.getJSONObject(i).getString("id")
            }
            else -> {
                val b = baseFor(provider, baseUrl)
                if (b.isEmpty()) throw IOException(tr("Вкажіть Base URL", "Укажите Base URL"))
                val r = JSONObject(get("$b/models", mapOf("Authorization" to "Bearer $key")))
                val a = r.optJSONArray("data") ?: JSONArray()
                for (i in 0 until a.length()) out += a.getJSONObject(i).getString("id")
            }
        }
        return out.distinct().sortedByDescending { score(provider, it) }
    }

    private fun autoModels(provider: String, key: String, baseUrl: String): List<String> {
        val all = listModels(provider, key, baseUrl).filter { id -> BAD.none { id.lowercase().contains(it) } }
        val pool = if (provider == "Gemini") all.filter { it.lowercase().contains("flash") }.ifEmpty { all } else all
        return pool.take(4)
    }

    /** Порожня модель = авто: береться найкраща з доступних; при 503/429/404 — повтори й перехід на іншу модель. */
    fun chat(provider: String, key: String, model: String, system: String, user: String, baseUrl: String = ""): String {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа (Налаштування)", "Нет API-ключа (Настройки)"))
        val wantAuto = model.isBlank() || model.equals("auto", true)
        val list = ArrayList<String>()
        if (!wantAuto) list.add(model.trim())
        var loaded = false
        if (wantAuto) {
            loaded = true
            try { list.addAll(autoModels(provider, key, baseUrl)) } catch (_: Exception) { }
            if (list.isEmpty() && defaultModel(provider).isNotBlank()) list.add(defaultModel(provider))
        }
        if (list.isEmpty()) throw IOException(tr("Вкажіть модель або натисніть «Показати доступні моделі»", "Укажите модель или нажмите «Показать доступные модели»"))
        var last: Exception? = null
        var idx = 0
        while (idx < list.size && idx < 4) {
            val m = list[idx]
            for (attempt in 0 until 3) {
                try {
                    val r = chatOnce(provider, key, m, system, user, baseUrl)
                    return if (wantAuto || idx > 0) tr("Модель: ", "Модель: ") + m + "\n\n" + r else r
                } catch (e: HttpEx) {
                    last = e
                    if (e.code == 503 || e.code == 429 || e.code >= 500) { try { Thread.sleep(1500L * (attempt + 1)) } catch (_: InterruptedException) { }; continue }
                    break
                }
            }
            if (!loaded) {
                loaded = true
                try { autoModels(provider, key, baseUrl).filter { it !in list }.forEach { list.add(it) } } catch (_: Exception) { }
            }
            idx++
        }
        throw last ?: IOException("AI error")
    }

    private fun chatOnce(provider: String, key: String, model: String, system: String, user: String, baseUrl: String): String {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа (Налаштування)", "Нет API-ключа (Настройки)"))
        val m = model.ifBlank { defaultModel(provider) }
        if (m.isBlank()) throw IOException(tr("Вкажіть назву моделі", "Укажите название модели"))
        return when (provider) {
            "Claude" -> {
                val body = JSONObject().put("model", m).put("max_tokens", 1500).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
                val r = JSONObject(post("https://api.anthropic.com/v1/messages",
                    mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString()))
                r.getJSONArray("content").getJSONObject(0).getString("text")
            }
            "Gemini" -> {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                val r = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                    mapOf("x-goog-api-key" to key), body.toString()))
                r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getString("text")
            }
            else -> {
                val url = when (provider) {
                    "OpenAI" -> "https://api.openai.com/v1/chat/completions"
                    "OpenRouter" -> "https://openrouter.ai/api/v1/chat/completions"
                    "Groq" -> "https://api.groq.com/openai/v1/chat/completions"
                    "Custom" -> customUrl(baseUrl, "chat/completions")
                    else -> "https://api.mistral.ai/v1/chat/completions"
                }
                val body = JSONObject().put("model", m).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
                val r = JSONObject(post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }
    }

    private fun customUrl(base: String, tail: String): String {
        val b = base.trim().trimEnd('/')
        if (b.isEmpty()) throw IOException(tr("Вкажіть Base URL (наприклад https://api.deepseek.com/v1)", "Укажите Base URL (например https://api.deepseek.com/v1)"))
        return if (b.endsWith("/$tail")) b else "$b/$tail"
    }

    /** Генерація зображення: OpenAI та сумісні (Custom) через /images/generations, Gemini через generateContent. */
    fun image(provider: String, key: String, model: String, baseUrl: String, prompt: String): ByteArray {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа (Налаштування)", "Нет API-ключа (Настройки)"))
        return when (provider) {
            "Gemini" -> {
                val m = model.ifBlank { "gemini-2.5-flash-image" }
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
                val r = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", mapOf("x-goog-api-key" to key), body.toString()))
                val parts = r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val d = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    if (d != null) return android.util.Base64.decode(d.getString("data"), android.util.Base64.DEFAULT)
                }
                throw IOException(tr("Модель не повернула зображення", "Модель не вернула изображение"))
            }
            "OpenAI", "Custom", "OpenRouter", "Mistral", "Groq" -> {
                val url = when (provider) {
                    "OpenAI" -> "https://api.openai.com/v1/images/generations"
                    "OpenRouter" -> "https://openrouter.ai/api/v1/images/generations"
                    "Mistral" -> "https://api.mistral.ai/v1/images/generations"
                    "Groq" -> "https://api.groq.com/openai/v1/images/generations"
                    else -> customUrl(baseUrl, "images/generations")
                }
                val m = model.ifBlank { if (provider == "OpenAI") "gpt-image-1" else "" }
                val body = JSONObject().put("prompt", prompt).put("n", 1).put("size", "1024x1024")
                if (m.isNotBlank()) body.put("model", m)
                val r = JSONObject(post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                val d = r.getJSONArray("data").getJSONObject(0)
                if (d.has("b64_json")) return android.util.Base64.decode(d.getString("b64_json"), android.util.Base64.DEFAULT)
                if (d.has("url")) return java.net.URL(d.getString("url")).openStream().use { it.readBytes() }
                throw IOException(tr("Сервіс не повернув зображення", "Сервис не вернул изображение"))
            }
            else -> throw IOException(tr("Цей провайдер не підтримує створення зображень (Claude — лише текст)", "Этот провайдер не поддерживает создание изображений (Claude — только текст)"))
        }
    }

    fun detectProvider(key: String): String? = when {
        key.startsWith("AIza") -> "Gemini"
        key.startsWith("sk-ant-") -> "Claude"
        key.startsWith("sk-or-") -> "OpenRouter"
        key.startsWith("gsk_") -> "Groq"
        key.startsWith("sk-") -> "OpenAI"
        else -> null
    }

    fun bestModel(provider: String, key: String, baseUrl: String): String? = autoModels(provider, key, baseUrl).firstOrNull()

    private fun <T> runWithModels(provider: String, key: String, model: String, baseUrl: String, call: (String) -> T): Pair<String, T> {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа (Налаштування)", "Нет API-ключа (Настройки)"))
        val wantAuto = model.isBlank() || model.equals("auto", true)
        val list = ArrayList<String>()
        if (!wantAuto) list.add(model.trim())
        var loaded = false
        if (wantAuto) {
            loaded = true
            try { list.addAll(autoModels(provider, key, baseUrl)) } catch (_: Exception) { }
            if (list.isEmpty() && defaultModel(provider).isNotBlank()) list.add(defaultModel(provider))
        }
        if (list.isEmpty()) throw IOException(tr("Вкажіть модель або натисніть «Моделі»", "Укажите модель или нажмите «Модели»"))
        var last: Exception? = null
        var idx = 0
        while (idx < list.size && idx < 4) {
            val m = list[idx]
            for (attempt in 0 until 3) {
                try { return m to call(m) }
                catch (e: HttpEx) {
                    last = e
                    if (e.code == 503 || e.code == 429 || e.code >= 500) { try { Thread.sleep(1500L * (attempt + 1)) } catch (_: InterruptedException) { }; continue }
                    break
                }
            }
            if (!loaded) {
                loaded = true
                try { autoModels(provider, key, baseUrl).filter { it !in list }.forEach { list.add(it) } } catch (_: Exception) { }
            }
            idx++
        }
        throw last ?: IOException("AI error")
    }

    private fun streamPost(url: String, headers: Map<String, String>, body: String, onLine: (String) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 120000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        if (code !in 200..299) {
            val s = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw HttpEx(code, "HTTP $code: ${s.take(400)}")
        }
        c.inputStream.bufferedReader().useLines { lines -> for (l in lines) onLine(l) }
    }

    private fun streamOnce(provider: String, key: String, model: String, system: String, history: List<Pair<String, String>>, baseUrl: String, onDelta: (String) -> Unit) {
        when (provider) {
            "Claude" -> {
                val msgs = JSONArray()
                history.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
                val body = JSONObject().put("model", model).put("max_tokens", 2000).put("system", system).put("messages", msgs).put("stream", true)
                streamPost("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString()) { l ->
                    if (l.startsWith("data:")) {
                        try {
                            val o = JSONObject(l.removePrefix("data:").trim())
                            if (o.optString("type") == "content_block_delta") { val t = o.getJSONObject("delta").optString("text"); if (t.isNotEmpty()) onDelta(t) }
                        } catch (_: Exception) { }
                    }
                }
            }
            "Gemini" -> {
                val contents = JSONArray()
                history.forEach { (r, t) ->
                    contents.put(JSONObject().put("role", if (r == "assistant") "model" else "user").put("parts", JSONArray().put(JSONObject().put("text", t))))
                }
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", contents)
                streamPost("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse", mapOf("x-goog-api-key" to key), body.toString()) { l ->
                    if (l.startsWith("data:")) {
                        try {
                            val cs = JSONObject(l.removePrefix("data:").trim()).optJSONArray("candidates")
                            if (cs != null && cs.length() > 0) {
                                val ps = cs.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                                if (ps != null) for (i in 0 until ps.length()) { val t = ps.getJSONObject(i).optString("text"); if (t.isNotEmpty()) onDelta(t) }
                            }
                        } catch (_: Exception) { }
                    }
                }
            }
            else -> {
                val url = when (provider) {
                    "OpenAI" -> "https://api.openai.com/v1/chat/completions"
                    "OpenRouter" -> "https://openrouter.ai/api/v1/chat/completions"
                    "Groq" -> "https://api.groq.com/openai/v1/chat/completions"
                    "Custom" -> customUrl(baseUrl, "chat/completions")
                    else -> "https://api.mistral.ai/v1/chat/completions"
                }
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
                history.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
                val body = JSONObject().put("model", model).put("messages", msgs).put("stream", true)
                streamPost(url, mapOf("Authorization" to "Bearer $key"), body.toString()) { l ->
                    if (l.startsWith("data:")) {
                        val d = l.removePrefix("data:").trim()
                        if (d != "[DONE]") {
                            try {
                                val ch = JSONObject(d).optJSONArray("choices")
                                if (ch != null && ch.length() > 0) { val t = ch.getJSONObject(0).optJSONObject("delta")?.optString("content") ?: ""; if (t.isNotEmpty() && t != "null") onDelta(t) }
                            } catch (_: Exception) { }
                        }
                    }
                }
            }
        }
    }

    /** Багатоходовий чат із потоковою відповіддю. Повертає назву моделі, що відповіла. */
    fun chatStream(provider: String, key: String, model: String, system: String, history: List<Pair<String, String>>, baseUrl: String, onDelta: (String) -> Unit): String {
        val r = runWithModels(provider, key, model, baseUrl) { m -> streamOnce(provider, key, m, system, history, baseUrl, onDelta) }
        return r.first
    }

    const val SYSTEM_CHAT = "You are the built-in assistant of the Android app DON-1500 Converter (it converts Farming Simulator 25 PC mods and maps to FS26 Mobile or FS23). " +
        "Be brief, direct and fast: do what the user asks, no lectures, no repeated disclaimers. Reply in the user's language. " +
        "You only see files the user attaches. When you write Lua or XML, put each file in its own fenced code block. " +
        "To trigger app features, add lines exactly like these at the end of the reply, each on its own line (the user taps a button to run them): " +
        "ACTION: {\"do\":\"open\",\"screen\":\"files|apk|donors|converter|editor|textures|images|errors|results|settings\"} ; " +
        "ACTION: {\"do\":\"analyze\"} ; ACTION: {\"do\":\"convert\"} ; ACTION: {\"do\":\"texsize\",\"value\":2048} ; ACTION: {\"do\":\"target\",\"value\":\"FS23\"}"

    const val SYSTEM = "You help convert Farming Simulator 25 PC mods and maps to Farming Simulator 26 Mobile. " +
        "Explain converter reports, missing files, XML/i3D/Lua compatibility problems and suggest concrete fixes. " +
        "Be honest: say when something cannot be converted automatically. Answer in the user's language."
}
