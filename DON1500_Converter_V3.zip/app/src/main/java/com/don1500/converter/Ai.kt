package com.don1500.converter

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    val providers = listOf("OpenAI", "Gemini", "Claude", "OpenRouter", "Groq", "Mistral", "Custom")

    fun defaultModel(p: String) = when (p) {
        "OpenAI" -> "gpt-4o-mini"
        "Gemini" -> "gemini-2.0-flash"
        "Claude" -> "claude-haiku-5-5"
        "OpenRouter" -> "openai/gpt-4o-mini"
        "Groq" -> "llama-3.3-70b-versatile"
        "Custom" -> ""
        else -> "mistral-small-latest"
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw IOException("HTTP $code: ${s.take(400)}")
        return s
    }

    fun chat(provider: String, key: String, model: String, system: String, user: String, baseUrl: String = ""): String {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа (Налаштування)", "Нет API-ключа (Настройки)"))
        val m = model.ifBlank { defaultModel(provider) }
        if (m.isBlank()) throw IOException(tr("Вкажіть назву моделі", "Укажите название модели"))
        return when (provider) {
            "Claude" -> {
                val body = JSONObject().put("model", m).put("max_tokens", 1500).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
                val r = JSONObject(post("https://api.anthropic.com/v1/messages",
                    mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString()))
                r.getJSONArray("content").getJSONObject(0).getString("text")
            }
            "Gemini" -> {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                val r = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                    mapOf("x-goog-api-key" to key), body.toString()))
                r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getString("text")
            }
            else -> {
                val url = when (provider) {
                    "OpenAI" -> "https://api.openai.com/v1/chat/completions"
                    "OpenRouter" -> "https://openrouter.ai/api/v1/chat/completions"
                    "Groq" -> "https://api.groq.com/openai/v1/chat/completions"
                    "Custom" -> customUrl(baseUrl, "chat/completions")
                    else -> "https://api.mistral.ai/v1/chat/completions"
                }
                val body = JSONObject().put("model", m).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
                val r = JSONObject(post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }
    }

    private fun customUrl(base: String, tail: String): String {
        val b = base.trim().trimEnd('/')
        if (b.isEmpty()) throw IOException(tr("Вкажіть Base URL (наприклад https://api.deepseek.com/v1)", "Укажите Base URL (например https://api.deepseek.com/v1)"))
        return if (b.endsWith("/$tail")) b else "$b/$tail"
    }

    /** Генерація зображення: OpenAI та сумісні (Custom) через /images/generations, Gemini через generateContent. */
    fun image(provider: String, key: String, model: String, baseUrl: String, prompt: String): ByteArray {
        if (key.isBlank()) throw IOException(tr("Немає API-ключа (Налаштування)", "Нет API-ключа (Настройки)"))
        return when (provider) {
            "Gemini" -> {
                val m = model.ifBlank { "gemini-2.5-flash-image" }
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
                val r = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", mapOf("x-goog-api-key" to key), body.toString()))
                val parts = r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val d = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    if (d != null) return android.util.Base64.decode(d.getString("data"), android.util.Base64.DEFAULT)
                }
                throw IOException(tr("Модель не повернула зображення", "Модель не вернула изображение"))
            }
            "OpenAI", "Custom", "OpenRouter", "Mistral", "Groq" -> {
                val url = when (provider) {
                    "OpenAI" -> "https://api.openai.com/v1/images/generations"
                    "OpenRouter" -> "https://openrouter.ai/api/v1/images/generations"
                    "Mistral" -> "https://api.mistral.ai/v1/images/generations"
                    "Groq" -> "https://api.groq.com/openai/v1/images/generations"
                    else -> customUrl(baseUrl, "images/generations")
                }
                val m = model.ifBlank { if (provider == "OpenAI") "gpt-image-1" else "" }
                val body = JSONObject().put("prompt", prompt).put("n", 1).put("size", "1024x1024")
                if (m.isNotBlank()) body.put("model", m)
                val r = JSONObject(post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                val d = r.getJSONArray("data").getJSONObject(0)
                if (d.has("b64_json")) return android.util.Base64.decode(d.getString("b64_json"), android.util.Base64.DEFAULT)
                if (d.has("url")) return java.net.URL(d.getString("url")).openStream().use { it.readBytes() }
                throw IOException(tr("Сервіс не повернув зображення", "Сервис не вернул изображение"))
            }
            else -> throw IOException(tr("Цей провайдер не підтримує створення зображень (Claude — лише текст)", "Этот провайдер не поддерживает создание изображений (Claude — только текст)"))
        }
    }

    const val SYSTEM = "You help convert Farming Simulator 25 PC mods and maps to Farming Simulator 26 Mobile. " +
        "Explain converter reports, missing files, XML/i3D/Lua compatibility problems and suggest concrete fixes. " +
        "Be honest: say when something cannot be converted automatically. Answer in the user's language."
}
