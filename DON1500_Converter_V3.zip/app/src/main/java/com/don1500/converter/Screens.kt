@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipFile

private fun fmtSec(s: Long) = if (s < 60) "$s ${tr("с", "с")}" else "${s / 60} ${tr("хв", "мин")} ${s % 60} ${tr("с", "с")}"

@Composable
fun ConverterScreen(store: Store, autoPick: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val cancelFlag = remember { java.util.concurrent.atomic.AtomicBoolean(false) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var cur by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var startMs by remember { mutableStateOf(0L) }
    var target by remember { mutableStateOf(store.target) }
    val src = Session.sourceFile
    val rep = Session.report

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""; prog = 0f; startMs = System.currentTimeMillis()
            cur = tr("Копіювання джерела…", "Копирование источника…")
            try {
                val name = Fs.displayName(ctx, uri)
                val size = Fs.sizeOf(ctx, uri)
                val dest = File(Fs.work(ctx), name)
                if (size > 0 && Fs.work(ctx).usableSpace < size + 64L * 1024 * 1024) throw java.io.IOException(tr("Недостатньо вільного місця", "Недостаточно свободного места"))
                var last = -1
                withContext(Dispatchers.IO) {
                    Fs.copyUri(ctx, uri, dest) { b ->
                        val pc = if (size > 0) (b * 100 / size).toInt() else 0
                        if (pc != last) { last = pc; cur = tr("Копіювання: ", "Копирование: ") + Fs.human(b); if (size > 0) prog = pc / 100f }
                    }
                }
                Session.sourceFile = dest; Session.report = null; Session.reportText = ""; Session.outputZip = null
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false
        }
    }
    LaunchedEffect(Unit) { if (autoPick && Session.sourceFile == null) picker.launch(arrayOf("*/*")) }

    fun run(analyzeOnly: Boolean) = scope.launch {
        val s = Session.sourceFile ?: return@launch
        busy = true; prog = 0f; msg = ""; cancelFlag.set(false); startMs = System.currentTimeMillis()
        try {
            val r = withContext(Dispatchers.IO) {
                val base = Converter.outputName(s.name, store.target).removeSuffix(".zip")
                val folder = File(Fs.outDir(ctx), base).also { it.mkdirs() }
                val out = if (analyzeOnly) null else File(folder, "$base.zip").also { if (it.exists()) it.delete() }
                val r = Converter.run(s, out, Options(store.renameFs, store.trimLang, store.maxTex, store.target, DonorLib.list(ctx, store.target), store.donorByName), isCancelled = { cancelFlag.get() }) { f, p -> cur = f; prog = p }
                if (!r.cancelled) {
                    if (out != null && out.exists() && r.verified) {
                        Session.outputZip = out
                        try { r.savedTo = Fs.publish(ctx, out, "application/zip", base) } catch (e: Exception) { r.issues += Issue("WARN", out.name, "Download: ${e.message}") }
                    }
                    val tag = if (analyzeOnly) "_analysis" else "_report"
                    val rf = File(folder, base + tag + ".txt"); rf.writeText(r.render())
                    try { Fs.publish(ctx, rf, "text/plain", base) } catch (_: Exception) { }
                    if (r.missing.isNotEmpty()) {
                        val mf = File(folder, base + "_missing.txt")
                        mf.writeText(r.missing.entries.joinToString("\n") { "${it.key}   <- ${it.value}" })
                        try { Fs.publish(ctx, mf, "text/plain", base) } catch (_: Exception) { }
                    }
                } else if (folder.listFiles().isNullOrEmpty()) folder.delete()
                r
            }
            Session.report = r; Session.reportText = r.render(); Session.rev++
            if (r.cancelled) msg = tr("⛔ Скасовано", "⛔ Отменено")
        } catch (e: Exception) { msg = "✖ ${e.message}" }
        busy = false
    }

    Frame(tr("Конвертер FS25 → FS26", "Конвертер FS25 → FS26"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Button(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); picker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Вибрати ZIP мода / карти FS25", "Выбрать ZIP мода / карты FS25"))
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Ціль: ", "Цель: "))
                FilterChip(target == "FS26", { target = "FS26"; store.target = "FS26" }, { Text("FS26 Mobile") }); Spacer(Modifier.width(8.dp))
                FilterChip(target == "FS23", { target = "FS23"; store.target = "FS23" }, { Text(tr("FS23 (експеримент)", "FS23 (эксперимент)")) })
            }
            Spacer(Modifier.height(8.dp))
            if (src != null) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(src.name, fontWeight = FontWeight.Bold)
                        Text(Fs.human(src.length()), fontSize = 12.sp)
                        val base = Converter.outputName(src.name, target).removeSuffix(".zip")
                        Text(tr("Буде створено: ", "Будет создано: ") + "Download/DON1500/$base/$base.zip", fontSize = 12.sp)
                        Text(tr("Текстури: ", "Текстуры: ") + (if (store.maxTex == 0) tr("оригінальний розмір", "оригинальный размер") else tr("до ${store.maxTex} px", "до ${store.maxTex} px")) + tr(" (змінюється в Налаштуваннях)", " (меняется в Настройках)"), fontSize = 11.sp)
                        Text(if (Donor.count > 0) tr("Донор: ${Donor.name}", "Донор: ${Donor.name}") else tr("Донор не завантажено", "Донор не загружен"), fontSize = 11.sp)
                        Text(tr("Донорів $target: ${DonorLib.list(ctx, target).size} (розділ «Донори»)", "Доноров $target: ${DonorLib.list(ctx, target).size} (раздел «Доноры»)"), fontSize = 11.sp)
                    }
                }
                Row(Modifier.padding(top = 8.dp)) {
                    OutlinedButton(enabled = !busy, onClick = { run(true) }) { Text(tr("Аналіз", "Анализ")) }
                    Spacer(Modifier.width(8.dp))
                    Button(enabled = !busy, onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); run(false) }) { Text(tr("Конвертувати", "Конвертировать")) }
                }
            }
            if (busy) {
                val pct = (prog * 100).toInt()
                val el = (System.currentTimeMillis() - startMs) / 1000
                val eta = if (prog > 0.02f) (el * (1 - prog) / prog).toLong() else -1L
                Spacer(Modifier.height(10.dp))
                Text("$pct%", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
                Text(tr("Минуло ", "Прошло ") + fmtSec(el) + (if (eta >= 0) tr(" · залишилось ~", " · осталось ~") + fmtSec(eta) else ""), fontSize = 12.sp)
                Text(cur, fontSize = 11.sp, maxLines = 2)
                OutlinedButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); cancelFlag.set(true); cur = tr("Скасовую…", "Отменяю…") }) { Text(tr("Скасувати", "Отменить")) }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
            if (rep != null) {
                Spacer(Modifier.height(10.dp))
                SelectionContainer { Text(Session.reportText, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}

@Composable
fun ApkScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(listOf<String>()) }
    var apk by remember { mutableStateOf<File?>(null) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""
            try {
                val res = withContext(Dispatchers.IO) {
                    val name = Fs.displayName(ctx, uri)
                    val f = File(Fs.work(ctx), name)
                    Fs.copyUri(ctx, uri, f)
                    val pi = ctx.packageManager.getPackageArchiveInfo(f.absolutePath, PackageManager.GET_PERMISSIONS)
                    val list = ZipFile(f).use { z -> z.entries().asSequence().map { it.name }.toList() }
                    val bad = ZipTools.verify(f)
                    val signed = list.any { it.startsWith("META-INF/") && (it.endsWith(".RSA") || it.endsWith(".SF") || it.endsWith(".EC") || it.endsWith(".DSA")) }
                    val t = buildString {
                        appendLine(name + " — " + Fs.human(f.length()))
                        if (pi != null) { appendLine("package: ${pi.packageName}"); appendLine("version: ${pi.versionName}"); appendLine(tr("дозволів: ", "разрешений: ") + (pi.requestedPermissions?.size ?: 0)) }
                        else appendLine(tr("Не вдалося прочитати маніфест (можливо, split/пошкоджений APK)", "Не удалось прочитать манифест (возможно, split/повреждённый APK)"))
                        appendLine(tr("Цілісність ZIP: ", "Целостность ZIP: ") + (bad ?: "OK"))
                        appendLine(tr("Підпис v1 (META-INF): ", "Подпись v1 (META-INF): ") + (if (signed) tr("є", "есть") else tr("немає", "нет")) + tr(" (v2/v3 тут не перевіряються)", " (v2/v3 здесь не проверяются)"))
                        appendLine(tr("Записів: ", "Записей: ") + list.size)
                        appendLine(tr("Зміна вмісту APK ламає підпис — потрібне повторне підписування.", "Изменение содержимого APK ломает подпись — нужна повторная подпись."))
                    }
                    Triple(f, list, t)
                }
                apk = res.first; entries = res.second; info = res.third
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false
        }
    }
    var dcount by remember { mutableStateOf(0) }
    val donorPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""; dcount = 0
            msg = withContext(Dispatchers.IO) {
                try { val n = Donor.build(ctx, uri, Fs.displayName(ctx, uri)) { c -> dcount = c }; "✔ " + tr("Донор готовий: записів $n", "Донор готов: записей $n") }
                catch (e: Exception) { "✖ ${e.message}" }
            }
            busy = false
        }
    }
    Frame(tr("Вибрати APK", "Выбрать APK"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text(tr("Донор (файли гри FS26 Mobile)", "Донор (файлы игры FS26 Mobile)"), fontWeight = FontWeight.Bold)
                    Text(if (Donor.count > 0) tr("Завантажено: ${Donor.name} — ${Donor.count} шляхів", "Загружено: ${Donor.name} — ${Donor.count} путей") else tr("Не завантажено", "Не загружено"), fontSize = 12.sp)
                    Text(tr("Оберіть APK гри або ZIP папки data. Конвертер перевірить, чи є в грі файли, на які посилається мод (\$data/…).", "Выберите APK игры или ZIP папки data. Конвертер проверит, есть ли в игре файлы, на которые ссылается мод (\$data/…)."), fontSize = 11.sp)
                    if (busy && dcount > 0) Text(tr("Прочитано записів: $dcount", "Прочитано записей: $dcount"), fontSize = 11.sp)
                    Row {
                        Button(enabled = !busy, onClick = { donorPicker.launch(arrayOf("*/*")) }) { Text(tr("Вибрати донор", "Выбрать донор")) }
                        Spacer(Modifier.width(8.dp))
                        if (Donor.count > 0) OutlinedButton(onClick = { Donor.clear(ctx) }) { Text(tr("Очистити", "Очистить")) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { picker.launch(arrayOf("application/vnd.android.package-archive", "*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(tr("Вибрати APK", "Выбрать APK")) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            if (msg.isNotEmpty()) Text(msg)
            SelectionContainer { Text(info, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)) }
            if (entries.isNotEmpty()) Text(tr("Натисніть запис, щоб витягти його в Download/DON1500/apk_extract", "Нажмите запись, чтобы извлечь её в Download/DON1500/apk_extract"), fontSize = 11.sp)
            entries.take(400).forEach { n ->
                TextButton(onClick = {
                    val f = apk ?: return@TextButton
                    scope.launch {
                        msg = withContext(Dispatchers.IO) {
                            try {
                                ZipFile(f).use { z ->
                                    val e = z.getEntry(n)
                                    val tmp = File(Fs.work(ctx), n.substringAfterLast('/'))
                                    z.getInputStream(e).use { i -> tmp.outputStream().use { i.copyTo(it) } }
                                    "✔ " + Fs.publish(ctx, tmp, "application/octet-stream", "apk_extract")
                                }
                            } catch (e: Exception) { "✖ ${e.message}" }
                        }
                    }
                }, contentPadding = PaddingValues(2.dp)) { Text(n, fontSize = 11.sp, maxLines = 1) }
            }
            if (entries.size > 400) Text("… +${entries.size - 400}")
        }
    }
}

private fun pow2(n: Int): Int { var p = 1; while (p * 2 <= n) p *= 2; return if (n - p > p * 2 - n) p * 2 else p }

private fun addTexture(ctx: Context, uri: Uri, path: String, zip: File, rep: ConvertReport): String {
    val name = Fs.displayName(ctx, uri)
    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    val png: ByteArray
    var note = ""
    if (name.endsWith(".dds", true)) {
        val r = Dds.decode(bytes)
        png = r.png ?: return "✖ DDS: ${r.error}"
    } else {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return "✖ " + tr("Не вдалося прочитати зображення", "Не удалось прочитать изображение")
        val w = pow2(bmp.width); val h = pow2(bmp.height)
        val b2 = if (w != bmp.width || h != bmp.height) { note = " (${bmp.width}x${bmp.height} → ${w}x$h)"; Bitmap.createScaledBitmap(bmp, w, h, true) } else bmp
        val bo = ByteArrayOutputStream(); b2.compress(Bitmap.CompressFormat.PNG, 100, bo); png = bo.toByteArray()
    }
    ZipTools.addOrReplace(zip, path, png)
    rep.missing.remove(path)
    rep.changes += tr("Додано вручну: $path$note", "Добавлено вручную: $path$note")
    Session.reportText = rep.render(); Session.rev++
    return "✔ " + tr("Додано в ZIP: $path$note", "Добавлено в ZIP: $path$note")
}

@Composable
fun TexturesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var target by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val rev = Session.rev
    val rep = Session.report
    val zip = Session.outputZip
    val tex = rep?.missing?.keys?.filter { it.substringAfterLast('.').lowercase() in setOf("png", "dds", "jpg", "jpeg") } ?: emptyList()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val z = Session.outputZip; val r = Session.report
        if (uri != null && target.isNotEmpty() && z != null && r != null) scope.launch {
            msg = withContext(Dispatchers.IO) { try { addTexture(ctx, uri, target, z, r) } catch (e: Exception) { "✖ ${e.message}" } }
        }
    }
    val ddsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = withContext(Dispatchers.IO) {
                try {
                    val r = Dds.decode(ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() })
                    if (r.png == null) "✖ DDS: ${r.error}" else {
                        val f = File(Fs.work(ctx), Fs.displayName(ctx, uri).substringBeforeLast('.') + ".png"); f.writeBytes(r.png)
                        "✔ " + Fs.publish(ctx, f, "image/png", "textures")
                    }
                } catch (e: Exception) { "✖ ${e.message}" }
            }
        }
    }
    Frame(tr("Текстури та ресурси", "Текстуры и ресурсы"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            OutlinedButton(onClick = { ddsPicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(tr("Конвертувати окремий DDS → PNG", "Конвертировать отдельный DDS → PNG")) }
            Spacer(Modifier.height(10.dp))
            Text(tr("Відсутні текстури після конвертації (рев. $rev)", "Отсутствующие текстуры после конвертации (рев. $rev)"), fontWeight = FontWeight.Bold)
            if (zip == null) Text(tr("Спочатку виконайте конвертацію — тут з'явиться список відсутніх файлів.", "Сначала выполните конвертацию — здесь появится список отсутствующих файлов."), fontSize = 13.sp)
            else if (tex.isEmpty()) Text(tr("Відсутніх текстур немає ✔", "Отсутствующих текстур нет ✔"))
            Text(tr("Натисніть файл і виберіть картинку (PNG/JPG/DDS): вона буде перетворена на PNG, приведена до розміру 2^n і покладена за потрібним шляхом у ZIP.", "Нажмите файл и выберите картинку (PNG/JPG/DDS): она будет преобразована в PNG, приведена к размеру 2^n и положена по нужному пути в ZIP."), fontSize = 11.sp)
            tex.take(300).forEach { p ->
                TextButton(onClick = { target = p; picker.launch(arrayOf("image/*", "*/*")) }, contentPadding = PaddingValues(2.dp)) { Text(p, fontSize = 12.sp, maxLines = 2) }
            }
            if (zip != null) Button(onClick = {
                scope.launch { msg = withContext(Dispatchers.IO) { try { "✔ " + Fs.publish(ctx, zip, "application/zip", Fs.subOf(ctx, zip)) } catch (e: Exception) { "✖ ${e.message}" } } }
            }, modifier = Modifier.padding(top = 8.dp)) { Text(tr("Зберегти оновлений ZIP у Download", "Сохранить обновлённый ZIP в Download")) }
            if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 8.dp))
            Text(tr("Створення текстур через AI — наступний етап.", "Создание текстур через AI — следующий этап."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
