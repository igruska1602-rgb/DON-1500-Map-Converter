@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipFile

private fun fmtSec(s: Long) = if (s < 60) "$s ${tr("с", "с")}" else "${s / 60} ${tr("хв", "мин")} ${s % 60} ${tr("с", "с")}"

@Composable
fun ConverterScreen(store: Store, autoPick: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val cancelFlag = remember { java.util.concurrent.atomic.AtomicBoolean(false) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var cur by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var startMs by remember { mutableStateOf(0L) }
    var target by remember { mutableStateOf(store.target) }
    var texSize by remember { mutableStateOf(store.maxTex) }
    var autoNote by remember { mutableStateOf("") }
    val src = Session.sourceFile
    val rep = Session.report

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) Session.pending = ""
        if (uri != null) scope.launch {
            busy = true; msg = ""; prog = 0f; startMs = System.currentTimeMillis()
            cur = tr("Копіювання джерела…", "Копирование источника…")
            try {
                val name = Fs.displayName(ctx, uri)
                val size = Fs.sizeOf(ctx, uri)
                val dest = File(Fs.work(ctx), name)
                if (size > 0 && Fs.work(ctx).usableSpace < size + 64L * 1024 * 1024) throw java.io.IOException(tr("Недостатньо вільного місця", "Недостаточно свободного места"))
                var last = -1
                withContext(Dispatchers.IO) {
                    Fs.copyUri(ctx, uri, dest) { b ->
                        val pc = if (size > 0) (b * 100 / size).toInt() else 0
                        if (pc != last) { last = pc; cur = tr("Копіювання: ", "Копирование: ") + Fs.human(b); if (size > 0) prog = pc / 100f }
                    }
                }
                Session.sourceFile = dest; Session.report = null; Session.reportText = ""; Session.outputZip = null
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false
        }
    }
    // "Вибрати FS25" з головного меню веде саме сюди, на екран Конвертера, а не одразу в системний
    // вибір файлів: так його видно, що це окремий, інший екран, ніж "Файловий менеджер", і вибір
    // файлу ви робите самі, натиснувши кнопку нижче — без автоматичного стрибка з програми.

    // Запускається через Session.appScope, а не через scope.launch (прив'язаний до цього екрана):
    // так конвертація триває, навіть якщо людина вийшла з екрана чи перейшла в інший розділ —
    // раніше вона скасовувалась, щойно екран конвертера зникав з composable-дерева.
    fun run(analyzeOnly: Boolean) {
        val s = Session.sourceFile ?: return
        if (Session.converting) return
        Session.converting = true; Session.convProg = 0f; msg = ""; Session.convCancel.set(false); Session.convStartMs = System.currentTimeMillis()
        val appCtx = ctx.applicationContext
        Session.appScope.launch(Dispatchers.IO) {
            val r = try {
                val base = Converter.outputName(s.name, target).removeSuffix(".zip")
                val folder = File(Fs.outDir(appCtx), base).also { it.mkdirs() }
                val out = if (analyzeOnly) null else File(folder, "$base.zip").also { if (it.exists()) it.delete() }
                val rr = Converter.run(s, out, Options(store.renameFs, store.trimLang, texSize, target, DonorLib.list(appCtx, target), store.donorByName, store.signNick, store.signEnabled), isCancelled = { Session.convCancel.get() }) { f, p -> Session.convLabel = f; Session.convProg = p }
                if (!rr.cancelled) {
                    if (out != null && out.exists() && rr.verified) {
                        Session.outputZip = out
                        try { rr.savedTo = Fs.publish(appCtx, out, "application/zip", base) } catch (e: Exception) { rr.issues += Issue("WARN", out.name, "Download: ${e.message}") }
                    }
                    val tag = if (analyzeOnly) "_analysis" else "_report"
                    val rf = File(folder, base + tag + ".txt"); rf.writeText(rr.render())
                    try { Fs.publish(appCtx, rf, "text/plain", base) } catch (_: Exception) { }
                    if (rr.missing.isNotEmpty()) {
                        val mf = File(folder, base + "_missing.txt")
                        mf.writeText(rr.missing.entries.joinToString("\n") { "${it.key}   <- ${it.value}" })
                        try { Fs.publish(appCtx, mf, "text/plain", base) } catch (_: Exception) { }
                    }
                } else if (folder.listFiles().isNullOrEmpty()) folder.delete()
                rr
            } catch (e: Exception) { ConvertReport().also { it.sourceName = s.name; it.issues += Issue("ERROR", s.name, e.message ?: "error") } }
            Session.report = r; Session.reportText = r.render(); Session.rev++
            if (r.cancelled) msg = tr("⛔ Скасовано", "⛔ Отменено")
            Session.converting = false
        }
    }

    LaunchedEffect(Session.sourceFile, Session.pending) {
        val a = Session.pending
        if (a.isNotEmpty() && Session.sourceFile != null && !Session.converting) { Session.pending = ""; run(a == "analyze") }
        else if (a.isNotEmpty() && Session.sourceFile == null) picker.launch(arrayOf("*/*"))
    }
    Frame(tr("Конвертер FS25 → FS26", "Конвертер FS25 → FS26"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Button(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); picker.launch(arrayOf("*/*")) }, enabled = !busy && !Session.converting, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Вибрати ZIP мода / карти FS25", "Выбрать ZIP мода / карты FS25"))
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Ціль: ", "Цель: "))
                FilterChip(target == "FS26", { target = "FS26"; store.target = "FS26" }, { Text("FS26 Mobile") }); Spacer(Modifier.width(8.dp))
                FilterChip(target == "FS23", { target = "FS23"; store.target = "FS23" }, { Text(tr("FS23 (експеримент)", "FS23 (эксперимент)")) })
            }
            Text(tr("Розмір текстур (DDS → PNG)", "Размер текстур (DDS → PNG)"), Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                listOf(-1 to tr("Авто", "Авто"), 0 to tr("Оригінал", "Оригинал"), 512 to "512", 1024 to "1024", 2048 to "2048", 4096 to "4096").forEach { (v, l) ->
                    FilterChip(texSize == v || (v == -1 && autoNote.isNotEmpty() && texSize == texSize), {
                        if (v == -1) {
                            val sz = src?.length() ?: 0L
                            val pick = when { sz > 500L * 1024 * 1024 -> 1024; sz > 120L * 1024 * 1024 -> 2048; else -> 0 }
                            texSize = pick; store.maxTex = pick
                            autoNote = tr("Авто обрав: ", "Авто выбрал: ") + (if (pick == 0) tr("оригінал", "оригинал") else "$pick") + tr(" (за розміром джерела)", " (по размеру источника)")
                        } else { texSize = v; store.maxTex = v; autoNote = "" }
                    }, { Text(l, fontSize = 12.sp) })
                    Spacer(Modifier.width(4.dp))
                }
            }
            if (autoNote.isNotEmpty()) Text(autoNote, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            if (src != null) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(src.name, fontWeight = FontWeight.Bold)
                        Text(Fs.human(src.length()), fontSize = 12.sp)
                        val base = Converter.outputName(src.name, target).removeSuffix(".zip")
                        Text(tr("Буде створено: ", "Будет создано: ") + "Download/DON1500/$base/$base.zip", fontSize = 12.sp)
                        Text(tr("Текстури: ", "Текстуры: ") + (if (texSize == 0) tr("оригінальний розмір", "оригинальный размер") else tr("до $texSize px", "до $texSize px")), fontSize = 11.sp)
                        Text(if (Donor.count > 0) tr("Донор: ${Donor.name}", "Донор: ${Donor.name}") else tr("Донор не завантажено", "Донор не загружен"), fontSize = 11.sp)
                        Text(tr("Донорів $target: ${DonorLib.list(ctx, target).size} (розділ «Донори»)", "Доноров $target: ${DonorLib.list(ctx, target).size} (раздел «Доноры»)"), fontSize = 11.sp)
                    }
                }
                Row(Modifier.padding(top = 8.dp)) {
                    OutlinedButton(enabled = !busy && !Session.converting, onClick = { run(true) }) { Text(tr("Аналіз", "Анализ")) }
                    Spacer(Modifier.width(8.dp))
                    Button(enabled = !busy && !Session.converting, onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); run(false) }) { Text(tr("Конвертувати", "Конвертировать")) }
                }
            }
            if (Session.converting) {
                val pct = (Session.convProg * 100).toInt()
                val el = (System.currentTimeMillis() - Session.convStartMs) / 1000
                val eta = if (Session.convProg > 0.02f) (el * (1 - Session.convProg) / Session.convProg).toLong() else -1L
                Spacer(Modifier.height(10.dp))
                Text("$pct%", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                LinearProgressIndicator(progress = { Session.convProg }, modifier = Modifier.fillMaxWidth())
                Text(tr("Минуло ", "Прошло ") + fmtSec(el) + (if (eta >= 0) tr(" · залишилось ~", " · осталось ~") + fmtSec(eta) else ""), fontSize = 12.sp)
                Text(Session.convLabel, fontSize = 11.sp, maxLines = 2)
                Text(tr("Можна вийти з цього екрана — конвертація продовжиться у фоні.", "Можно выйти с этого экрана — конвертация продолжится в фоне."), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); Session.convCancel.set(true); Session.convLabel = tr("Скасовую…", "Отменяю…") }) { Text(tr("Скасувати", "Отменить")) }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
            if (rep != null) {
                Spacer(Modifier.height(10.dp))
                SelectionContainer { Text(Session.reportText, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}

private class FolderStat(var count: Int = 0, var bytes: Long = 0)

@Composable
fun ApkScreen(onConvert: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var cur by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var srcUri by remember { mutableStateOf<Uri?>(null) }
    var srcName by remember { mutableStateOf("") }
    var folders by remember { mutableStateOf(listOf<Pair<String, FolderStat>>()) }
    var maps by remember { mutableStateOf(listOf<String>()) }
    var total by remember { mutableStateOf(0) }
    var extracted by remember { mutableStateOf<File?>(null) }
    var dcount by remember { mutableStateOf(0) }
    var startMs by remember { mutableStateOf(0L) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""; prog = 0f; folders = emptyList(); maps = emptyList(); extracted = null
            startMs = System.currentTimeMillis()
            try {
                val name = Fs.displayName(ctx, uri)
                val size = Fs.sizeOf(ctx, uri)
                val res = withContext(Dispatchers.IO) {
                    val stats = HashMap<String, FolderStat>()
                    val mp = ArrayList<String>()
                    var n = 0
                    val ins = ctx.contentResolver.openInputStream(uri) ?: throw java.io.IOException("open")
                    val counting = CountingStream(ins)
                    var last = -1
                    java.util.zip.ZipInputStream(java.io.BufferedInputStream(counting, 1 shl 16)).use { zi ->
                        while (true) {
                            val e = zi.nextEntry ?: break
                            if (e.isDirectory) continue
                            n++
                            val parts = e.name.replace('\\', '/').split('/')
                            val key = if (parts.size >= 3) parts[0] + "/" + parts[1] else if (parts.size == 2) parts[0] else "(root)"
                            val st = stats.getOrPut(key) { FolderStat() }
                            st.count++; st.bytes += maxOf(0L, e.size)
                            if (parts.last().equals("map.xml", true) && mp.size < 20) mp += e.name
                            if (size > 0) { val pc = (counting.count * 100 / size).toInt(); if (pc != last) { last = pc; prog = pc / 100f; cur = e.name } }
                        }
                    }
                    Triple(stats.entries.sortedByDescending { it.value.count }.take(80).map { it.key to it.value }, mp.toList(), n)
                }
                srcUri = uri; srcName = name; folders = res.first; maps = res.second; total = res.third
                msg = "✔ " + tr("Прочитано файлів: ${res.third}", "Прочитано файлов: ${res.third}")
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false
        }
    }

    fun extract(key: String) = scope.launch {
        val uri = srcUri ?: return@launch
        busy = true; msg = ""; prog = 0f; extracted = null; startMs = System.currentTimeMillis()
        try {
            val res = withContext(Dispatchers.IO) {
                val tag = if (key.isEmpty()) "all" else key.replace(Regex("[^A-Za-z0-9]+"), "_")
                val out = File(Fs.work(ctx), srcName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_]+"), "_") + "_" + tag + ".zip")
                if (out.exists()) out.delete()
                val size = Fs.sizeOf(ctx, uri)
                val pref = if (key.isEmpty() || key == "(root)") "" else "$key/"
                val ins = ctx.contentResolver.openInputStream(uri) ?: throw java.io.IOException("open")
                val counting = CountingStream(ins)
                var n = 0
                var last = -1
                java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(java.io.FileOutputStream(out), 1 shl 16)).use { zo ->
                    zo.setLevel(java.util.zip.Deflater.BEST_SPEED)
                    java.util.zip.ZipInputStream(java.io.BufferedInputStream(counting, 1 shl 16)).use { zi ->
                        while (true) {
                            val e = zi.nextEntry ?: break
                            if (e.isDirectory) continue
                            val nm = e.name.replace('\\', '/')
                            if (size > 0) { val pc = (counting.count * 100 / size).toInt(); if (pc != last) { last = pc; prog = pc / 100f; cur = nm } }
                            val inside = if (key == "(root)") !nm.contains('/') else nm.startsWith(pref)
                            if (!inside) continue
                            zo.putNextEntry(java.util.zip.ZipEntry(nm.removePrefix(pref))); zi.copyTo(zo, 1 shl 16); zo.closeEntry(); n++
                        }
                    }
                }
                out to n
            }
            extracted = res.first
            msg = "✔ " + tr("Витягнуто файлів: ${res.second} → ${res.first.name} (${Fs.human(res.first.length())})", "Извлечено файлов: ${res.second} → ${res.first.name} (${Fs.human(res.first.length())})")
        } catch (e: Exception) { msg = "✖ ${e.message}" }
        busy = false
    }

    val donorPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""; dcount = 0
            msg = withContext(Dispatchers.IO) {
                try { val n = Donor.build(ctx, uri, Fs.displayName(ctx, uri)) { c -> dcount = c }; "✔ " + tr("Донор готовий: записів $n", "Донор готов: записей $n") }
                catch (e: Exception) { "✖ ${e.message}" }
            }
            busy = false
        }
    }

    Frame(tr("APK / дані гри", "APK / данные игры"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            InfoHint(tr("Оберіть APK гри (або ZIP з даними). Програма покаже, які папки всередині, і витягне потрібну в ZIP. Далі її можна конвертувати: якщо в архіві немає modDesc.xml, його буде створено автоматично за map.xml.", "Выберите APK игры (или ZIP с данными). Программа покажет, какие папки внутри, и извлечёт нужную в ZIP. Дальше её можно конвертировать: если в архиве нет modDesc.xml, он будет создан автоматически по map.xml."))
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text(tr("Вибрати APK або ZIP", "Выбрать APK или ZIP")) }
            if (busy) {
                val pct = (prog * 100).toInt()
                val el = (System.currentTimeMillis() - startMs) / 1000
                val eta = if (prog > 0.02f) (el * (1 - prog) / prog).toLong() else -1L
                Text("$pct%", fontSize = 26.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
                Text(tr("Минуло ", "Прошло ") + fmtSec(el) + (if (eta >= 0) tr(" · залишилось ~", " · осталось ~") + fmtSec(eta) else ""), fontSize = 12.sp)
                Text(cur, fontSize = 11.sp, maxLines = 1)
                if (dcount > 0) Text(tr("Прочитано записів: $dcount", "Прочитано записей: $dcount"), fontSize = 11.sp)
            }
            if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp)
            if (srcUri != null) {
                Text("$srcName · ${tr("файлів", "файлов")}: $total", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                if (maps.isNotEmpty()) Text(tr("Знайдено map.xml: ", "Найдено map.xml: ") + maps.joinToString(", ").take(300), fontSize = 12.sp)
                Text(tr("Натисніть папку, щоб витягти її в ZIP:", "Нажмите папку, чтобы извлечь её в ZIP:"), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                TextButton(enabled = !busy, onClick = { extract("") }, contentPadding = PaddingValues(2.dp)) { Text(tr("▸ весь архів", "▸ весь архив"), fontSize = 13.sp) }
                folders.forEach { (k, st) ->
                    TextButton(enabled = !busy, onClick = { extract(k) }, contentPadding = PaddingValues(2.dp)) {
                        Text("▸ $k  (${st.count} ${tr("файлів", "файлов")}" + (if (st.bytes > 0) ", ${Fs.human(st.bytes)}" else "") + ")", fontSize = 13.sp)
                    }
                }
            }
            val ex = extracted
            if (ex != null) {
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(ex.name, fontWeight = FontWeight.Bold)
                        Button(enabled = !busy, onClick = { Session.sourceFile = ex; Session.report = null; Session.reportText = ""; Session.outputZip = null; onConvert() }) {
                            Text(tr("Конвертувати цей ZIP у мод", "Конвертировать этот ZIP в мод"))
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text(tr("Донор (файли гри FS26 Mobile)", "Донор (файлы игры FS26 Mobile)"), fontWeight = FontWeight.Bold)
                    Text(if (Donor.count > 0) tr("Завантажено: ${Donor.name} — ${Donor.count} шляхів", "Загружено: ${Donor.name} — ${Donor.count} путей") else tr("Не завантажено", "Не загружено"), fontSize = 12.sp)
                    InfoHint(tr("APK гри або ZIP папки data. Конвертер перевірить, чи є в грі файли, на які посилається мод (\$data/…).", "APK игры или ZIP папки data. Конвертер проверит, есть ли в игре файлы, на которые ссылается мод (\$data/…)."))
                    Row {
                        Button(enabled = !busy, onClick = { donorPicker.launch(arrayOf("*/*")) }) { Text(tr("Вибрати донор", "Выбрать донор")) }
                        Spacer(Modifier.width(8.dp))
                        if (Donor.count > 0) OutlinedButton(onClick = { Donor.clear(ctx) }) { Text(tr("Очистити", "Очистить")) }
                    }
                }
            }
        }
    }
}

private fun pow2(n: Int): Int { var p = 1; while (p * 2 <= n) p *= 2; return if (n - p > p * 2 - n) p * 2 else p }

private fun addTexture(ctx: Context, uri: Uri, path: String, zip: File, rep: ConvertReport): String {
    val name = Fs.displayName(ctx, uri)
    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    val png: ByteArray
    var note = ""
    if (name.endsWith(".dds", true)) {
        val r = Dds.decode(bytes)
        png = r.png ?: return "✖ DDS: ${r.error}"
    } else {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return "✖ " + tr("Не вдалося прочитати зображення", "Не удалось прочитать изображение")
        val w = pow2(bmp.width); val h = pow2(bmp.height)
        val b2 = if (w != bmp.width || h != bmp.height) { note = " (${bmp.width}x${bmp.height} → ${w}x$h)"; Bitmap.createScaledBitmap(bmp, w, h, true) } else bmp
        val bo = ByteArrayOutputStream(); b2.compress(Bitmap.CompressFormat.PNG, 100, bo); png = bo.toByteArray()
    }
    ZipTools.addOrReplace(zip, path, png)
    rep.missing.remove(path)
    rep.changes += tr("Додано вручну: $path$note", "Добавлено вручную: $path$note")
    Session.reportText = rep.render(); Session.rev++
    return "✔ " + tr("Додано в ZIP: $path$note", "Добавлено в ZIP: $path$note")
}

@Composable
fun TexturesScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var target by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val rev = Session.rev
    val rep = Session.report
    val zip = Session.outputZip
    val tex = rep?.missing?.keys?.filter { it.substringAfterLast('.').lowercase() in setOf("png", "dds", "jpg", "jpeg") } ?: emptyList()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val z = Session.outputZip; val r = Session.report
        if (uri != null && target.isNotEmpty() && z != null && r != null) scope.launch {
            msg = withContext(Dispatchers.IO) { try { addTexture(ctx, uri, target, z, r) } catch (e: Exception) { "✖ ${e.message}" } }
        }
    }
    val ddsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = withContext(Dispatchers.IO) {
                try {
                    val r = Dds.decode(ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() })
                    if (r.png == null) "✖ DDS: ${r.error}" else {
                        val f = File(Fs.work(ctx), Fs.displayName(ctx, uri).substringBeforeLast('.') + ".png"); f.writeBytes(r.png)
                        "✔ " + Fs.publish(ctx, f, "image/png", "textures")
                    }
                } catch (e: Exception) { "✖ ${e.message}" }
            }
        }
    }
    val multiPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        val z = Session.outputZip; val r = Session.report
        if (l.isNotEmpty() && z != null && r != null) scope.launch {
            msg = withContext(Dispatchers.IO) { try { distribute(ctx, l, z, r, store.maxTex) } catch (e: Exception) { "✖ ${e.message}" } }
        }
    }
    Frame(tr("Текстури та ресурси", "Текстуры и ресурсы"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            OutlinedButton(onClick = { ddsPicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(tr("Конвертувати окремий DDS → PNG", "Конвертировать отдельный DDS → PNG")) }
            OutlinedButton(enabled = zip != null, onClick = { multiPicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                Text(tr("Розкидати файли по відсутніх шляхах…", "Разложить файлы по отсутствующим путям…"))
            }
            InfoHint(tr("Оберіть купу файлів: програма зіставить їх з відсутніми за назвою, перетворить у потрібний формат (PNG/DDS) і покладе куди треба.", "Выберите кучу файлов: программа сопоставит их с отсутствующими по имени, преобразует в нужный формат (PNG/DDS) и положит куда нужно."))
            Spacer(Modifier.height(10.dp))
            Text(tr("Відсутні текстури після конвертації (рев. $rev)", "Отсутствующие текстуры после конвертации (рев. $rev)"), fontWeight = FontWeight.Bold)
            if (zip == null) Text(tr("Спочатку виконайте конвертацію — тут з'явиться список відсутніх файлів.", "Сначала выполните конвертацию — здесь появится список отсутствующих файлов."), fontSize = 13.sp)
            else if (tex.isEmpty()) Text(tr("Відсутніх текстур немає ✔", "Отсутствующих текстур нет ✔"))
            Text(tr("Натисніть файл і виберіть картинку (PNG/JPG/DDS): вона буде перетворена на PNG, приведена до розміру 2^n і покладена за потрібним шляхом у ZIP.", "Нажмите файл и выберите картинку (PNG/JPG/DDS): она будет преобразована в PNG, приведена к размеру 2^n и положена по нужному пути в ZIP."), fontSize = 11.sp)
            tex.take(300).forEach { p ->
                TextButton(onClick = { target = p; picker.launch(arrayOf("image/*", "*/*")) }, contentPadding = PaddingValues(2.dp)) { Text(p, fontSize = 12.sp, maxLines = 2) }
            }
            if (zip != null) Button(onClick = {
                scope.launch { msg = withContext(Dispatchers.IO) { try { "✔ " + Fs.publish(ctx, zip, "application/zip", Fs.subOf(ctx, zip)) } catch (e: Exception) { "✖ ${e.message}" } } }
            }, modifier = Modifier.padding(top = 8.dp)) { Text(tr("Зберегти оновлений ZIP у Download", "Сохранить обновлённый ZIP в Download")) }
            if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 8.dp))
            Text(tr("Створення текстур через AI — наступний етап.", "Создание текстур через AI — следующий этап."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
