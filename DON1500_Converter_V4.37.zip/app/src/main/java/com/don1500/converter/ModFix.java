package com.don1500.converter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Універсальні виправлення XML модів для FS26 Mobile (за повідомленнями з реального логу гри). Без залежностей від Android. */
public final class ModFix {
    private ModFix() {}

    public static final class Result {
        public final String text; public final int count;
        Result(String text, int count) { this.text = text; this.count = count; }
    }

    private static final Pattern FOLDABLE = Pattern.compile("<foldable\\b[^>]*>(.*?)</foldable>", Pattern.DOTALL);

    /**
     * «'vehicle.foldable.foldingParts' is not supported anymore»: старий вигляд
     * &lt;foldable&gt;&lt;foldingParts&gt;…&lt;/foldingParts&gt;&lt;/foldable&gt; загортається в foldingConfigurations/foldingConfiguration.
     */
    public static Result fixFolding(String xml) {
        Matcher m = FOLDABLE.matcher(xml);
        StringBuilder sb = new StringBuilder(); int last = 0, n = 0;
        while (m.find()) {
            String inner = m.group(1);
            if (inner.contains("<foldingConfigurations") || !inner.contains("<foldingParts")) continue;
            int a = inner.indexOf("<foldingParts");
            int endTag = inner.lastIndexOf("</foldingParts>");
            int b;
            if (endTag >= 0) b = endTag + "</foldingParts>".length();
            else { int e = inner.indexOf("/>", a); if (e < 0) continue; b = e + 2; }
            // самозакрита <foldingParts .../> — теж підтримуємо
            String block = inner.substring(a, b);
            String wrapped = "<foldingConfigurations>\n            <foldingConfiguration>\n                " + block + "\n            </foldingConfiguration>\n        </foldingConfigurations>";
            String newInner = inner.substring(0, a) + wrapped + inner.substring(b);
            int s = m.start(1), e2 = m.end(1);
            sb.append(xml, last, s).append(newInner); last = e2; n++;
        }
        if (n == 0) return new Result(xml, 0);
        sb.append(xml, last, xml.length());
        return new Result(sb.toString(), n);
    }

    private static final Pattern DASHBOARD_FONT = Pattern.compile("\\s+font=\"DIGIT_BOLD\"");

    /** «Unknown font 'DIGIT_BOLD'»: такого шрифту в FS26 Mobile немає — прибираємо атрибут (діє шрифт за замовчуванням). */
    public static Result fixFonts(String xml) {
        Matcher m = DASHBOARD_FONT.matcher(xml);
        int n = 0; while (m.find()) n++;
        return n == 0 ? new Result(xml, 0) : new Result(DASHBOARD_FONT.matcher(xml).replaceAll(""), n);
    }

    private static final Pattern TYPE = Pattern.compile("<type\\b[^>]*>.*?</type>", Pattern.DOTALL);
    private static final Pattern SPEC = Pattern.compile("[ \\t]*<specialization\\s+name=\"([^\"]+)\"\\s*/>[ \\t]*\\r?\\n?");

    /**
     * «Specialization 'attacherJoints' already exists for vehicle type …»: власні типи техніки в modDesc повторюють специфікації,
     * які вже є в батьківському типі (підтверджено логом гри: baseTipper уже містить attacherJoints), або дублюють одна одну.
     */
    public static Result fixVehicleTypes(String modDesc) {
        Matcher m = TYPE.matcher(modDesc);
        StringBuilder sb = new StringBuilder(); int last = 0, n = 0;
        while (m.find()) {
            String block = m.group();
            String parent = attr(block, "parent");
            java.util.Set<String> inherited = new java.util.HashSet<>();
            if ("baseTipper".equals(parent)) inherited.add("attacherJoints");
            Matcher sm = SPEC.matcher(block);
            StringBuilder nb = new StringBuilder(); int l2 = 0; int removed = 0;
            java.util.Set<String> seen = new java.util.HashSet<>();
            while (sm.find()) {
                String name = sm.group(1);
                if (inherited.contains(name) || !seen.add(name)) { nb.append(block, l2, sm.start()); l2 = sm.end(); removed++; }
            }
            if (removed == 0) continue;
            nb.append(block, l2, block.length());
            sb.append(modDesc, last, m.start()).append(nb); last = m.end(); n += removed;
        }
        if (n == 0) return new Result(modDesc, 0);
        sb.append(modDesc, last, modDesc.length());
        return new Result(sb.toString(), n);
    }

    private static String attr(String tagBlock, String name) {
        int end = tagBlock.indexOf('>');
        Matcher m = Pattern.compile("\\b" + name + "=\"([^\"]*)\"").matcher(tagBlock.substring(0, Math.max(0, end)));
        return m.find() ? m.group(1) : "";
    }

    // ===================== FS23 → FS26: правила з пакета знань (див. docs/RULES_FS23_to_FS26.md) =====================
    private static final java.util.Set<String> BAD_VARIATIONS = new java.util.HashSet<String>(java.util.Arrays.asList("colorMask", "Decal", "uvScroll", "windBend"));
    private static final java.util.Set<String> OK_VARIATIONS = new java.util.HashSet<String>(java.util.Arrays.asList("staticLight", "staticLight_vertex", "tirePressureDeformation", "uvTransform", "vmaskUV2", "additive_colorScale"));
    private static final java.util.Set<String> DROP_PARAMS = new java.util.HashSet<String>(java.util.Arrays.asList(
        "RDT", "offsetUV", "directionBend", "prevDirectionBend", "blinkOffset", "prevMorphPosition",
        "colorMat0", "colorMat1", "colorMat2", "colorMat3", "colorMat4", "colorMat5", "colorMat6", "colorMat7"));
    private static final Pattern I3D_FILE = Pattern.compile("(<File\\b[^>]*?\\bfilename=\")([^\"]+)\"");
    private static final Pattern MATERIAL = Pattern.compile("<Material\\b[^>]*?(?<!/)>.*?</Material>", Pattern.DOTALL);
    private static final Pattern VARIATION = Pattern.compile("\\s+customShaderVariation=\"([^\"]*)\"");
    private static final Pattern BAD_TOKEN = Pattern.compile("(^|_)(colorMask|Decal|uvScroll|windBend)(?=_|$)");
    private static final Pattern CPARAM = Pattern.compile("[ \\t]*<CustomParameter name=\"([^\"]+)\" value=\"([^\"]*)\"\\s*/>[ \\t]*\\r?\\n?");
    private static final String DL = "$data/shared/detailLibrary/";
    private static final String[] D_PAINT = {DL + "nonMetallic/metal/metalPaintedOld_diffuse.png", DL + "flat_normal.png", DL + "nonMetallic/metal/metalPaintedOld_specular.png"};
    private static final String[] D_RUBBER = {DL + "nonMetallic/rubber/rubberBlack_diffuse.png", DL + "nonMetallic/rubber/rubber_normal.png", DL + "nonMetallic/rubber/rubber_specular.png"};
    private static final String[] D_CHROME = {DL + "metallic/clear_diffuse.png", DL + "flat_normal.png", DL + "metallic/clear_specular.png"};

    /**
     * i3d: (1) «\» → «/» у шляхах; (2) шейдер-варіації, яких немає у FS26 (colorMask, Decal, uvScroll, windBend) — ПІДТВЕРДЖЕНО ГРОЮ:
     * «Can't load resource data/shaders/vehicleShader.xml» і вильот; (3) лише для файлів FS23 (є colorMask/colorMat0): параметри FS22 прибираються,
     * morphPosition → morphPos, колір з маски → colorScale; (4) за бажанням — detail-maps (експеримент, у грі не перевірено).
     */
    public static Result fixI3d(String s, boolean detailMaps) { return fixI3d(s, detailMaps, null); }

    public static Result fixI3d(String s, boolean detailMaps, java.util.Set<String> slotNames) {
        int[] n = new int[1];
        Matcher fm = I3D_FILE.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (fm.find()) {
            String p = fm.group(2);
            if (p.indexOf('\\') >= 0) { n[0]++; p = p.replace('\\', '/'); }
            fm.appendReplacement(sb, Matcher.quoteReplacement(fm.group(1) + p + "\""));
        }
        fm.appendTail(sb);
        s = sb.toString();
        boolean fs23File = Pattern.compile("customShaderVariation=\"[^\"]*colorMask").matcher(s).find() || s.contains("name=\"colorMat0\"");
        Matcher mm = MATERIAL.matcher(s);
        sb = new StringBuffer();
        while (mm.find()) mm.appendReplacement(sb, Matcher.quoteReplacement(fixMaterial(mm.group(0), n, fs23File)));
        mm.appendTail(sb);
        s = sb.toString();
        s = fixCollisionBits(s, n);
        if (slotNames != null && !slotNames.isEmpty()) s = assignSlotNames(s, slotNames, n);
        if (detailMaps && fs23File) s = addDetailMaps(s, n);
        return new Result(s, n[0]);
    }

    private static final Pattern COMPONENT_NODE = Pattern.compile("<(?:TransformGroup|Shape)\\b[^>]*\\bname=\"[^\"]*main_component\\d*\"[^>]*>");
    private static final Pattern COLL_ATTR = Pattern.compile("\\b(collisionFilterGroup|collisionFilterMask)=\"(0[xX][0-9a-fA-F]+|\\d+)\"");

    /** Гра FS26: «Missing collision group/filter mask bit 16 (VEHICLE). Please add this bit to component node …_main_component1» — без цього біта немає колізій техніки. */
    private static String fixCollisionBits(String s, int[] n) {
        Matcher nm = COMPONENT_NODE.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (nm.find()) {
            String tag = nm.group(0);
            if (!tag.contains("collisionFilterGroup=") && tag.contains("collisionMask=")) {
                // FS22: один collisionMask; FS26 хоче Group+Mask з бітом VEHICLE. Значення — з робочого FS26-трактора (MTZ 82 UK): 0x10004 / 0xfe3ffb83.
                tag = tag.replaceFirst("collisionMask=\"[^\"]*\"", "collisionFilterGroup=\"0x10004\" collisionFilterMask=\"0xfe3ffb83\"");
                n[0]++;
            }
            Matcher am = COLL_ATTR.matcher(tag);
            StringBuffer tb = new StringBuffer();
            while (am.find()) {
                String rep = am.group(0);
                try {
                    long v = Long.decode(am.group(2));
                    if ((v & 0x10000L) == 0) { rep = am.group(1) + "=\"0x" + Long.toHexString(v | 0x10000L) + "\""; n[0]++; }
                } catch (NumberFormatException e) { /* лишаємо як є */ }
                am.appendReplacement(tb, Matcher.quoteReplacement(rep));
            }
            am.appendTail(tb);
            nm.appendReplacement(sb, Matcher.quoteReplacement(tb.toString()));
        }
        nm.appendTail(sb);
        return sb.toString();
    }

    private static String attrOf(String tag, String attr) {
        Matcher m = Pattern.compile("\\b" + attr + "=\"([^\"]*)\"").matcher(tag);
        return m.find() ? m.group(1) : null;
    }

    /** FS22: <material name="kuzov" shaderParameter=…> шукав матеріал вузла kuzov. FS26: materialSlotName у Material. Слот = ім'я вузла (або Material name / name+Mat). */
    private static String assignSlotNames(String s, java.util.Set<String> slotNames, int[] n) {
        java.util.Map<String, String> slotByMatId = new java.util.HashMap<String, String>();
        Matcher nm = Pattern.compile("<(?:Shape|TransformGroup)\\b[^>]*>").matcher(s);
        while (nm.find()) {
            String tag = nm.group(0), name = attrOf(tag, "name"), ids = attrOf(tag, "materialIds");
            if (name == null || ids == null || !slotNames.contains(name)) continue;
            String first = ids.split("[,\\s]+")[0];
            if (!first.isEmpty() && !slotByMatId.containsValue(name) && !slotByMatId.containsKey(first)) slotByMatId.put(first, name);
        }
        Matcher mm = MATERIAL.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (mm.find()) {
            String mat = mm.group(0);
            if (!mat.contains("materialSlotName=")) {
                String slot = slotByMatId.get(attrOf(mat, "materialId"));
                String mname = attrOf(mat, "name");
                if (slot == null && mname != null) {
                    for (String cand : slotNames) if (mname.equals(cand) || mname.equalsIgnoreCase(cand + "Mat") || mname.equalsIgnoreCase(cand + "_mat")) { if (!slotByMatId.containsValue(cand)) { slot = cand; break; } }
                }
                if (slot != null) {
                    Matcher h = Pattern.compile("^<Material\\b").matcher(mat);
                    if (h.find()) { mat = "<Material materialSlotName=\"" + slot + "\"" + mat.substring(h.end()); n[0]++; }
                }
            }
            mm.appendReplacement(sb, Matcher.quoteReplacement(mat));
        }
        mm.appendTail(sb);
        return sb.toString();
    }

    private static String fixMaterial(String mat, int[] n, boolean fs23File) {
        boolean wasMask = false;
        Matcher vm = VARIATION.matcher(mat);
        if (vm.find()) {
            String v = vm.group(1);
            Matcher bm = BAD_TOKEN.matcher(v);
            if (bm.find()) {
                wasMask = v.matches(".*(^|_)colorMask(_.*|$)");
                String rest = BAD_TOKEN.matcher(v).replaceAll("").replaceAll("^_+|_+$", "").replaceAll("_{2,}", "_");
                // Лишаємо тільки варіації, що є в робочому FS26 (staticLight, vmaskUV2…); решта (напр. motionPathRubber_secondUV) → базова
                mat = mat.replace(vm.group(0), OK_VARIATIONS.contains(rest) ? " customShaderVariation=\"" + rest + "\"" : "");
                n[0]++;
            }
        }
        if (!fs23File) return mat;
        boolean hasTex = mat.contains("<Texture ");
        String cm0 = null;
        Matcher p0 = Pattern.compile("<CustomParameter name=\"colorMat0\" value=\"([^\"]*)\"").matcher(mat);
        if (p0.find()) cm0 = p0.group(1);
        Matcher pm = CPARAM.matcher(mat);
        StringBuffer sb = new StringBuffer();
        while (pm.find()) {
            String name = pm.group(1), rep = pm.group(0);
            if (DROP_PARAMS.contains(name)) { rep = ""; n[0]++; }
            else if (name.equals("morphPosition")) { rep = rep.replace("morphPosition", "morphPos"); n[0]++; }
            pm.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        pm.appendTail(sb);
        mat = sb.toString();
        if (wasMask && !hasTex && cm0 != null && !mat.contains("name=\"colorScale\"")) {
            String[] c = cm0.trim().split("\\s+");
            int k = mat.lastIndexOf("</Material>");
            if (c.length >= 3 && k >= 0) {
                mat = mat.substring(0, k) + "  <CustomParameter name=\"colorScale\" value=\"" + c[0] + " " + c[1] + " " + c[2] + "\"/>\n    " + mat.substring(k);
                n[0]++;
            }
        }
        return mat;
    }

    private static String addDetailMaps(String s, int[] n) {
        int end = s.indexOf("</Files>");
        if (end < 0) return s;
        Matcher im = Pattern.compile("<File fileId=\"(\\d+)\"").matcher(s);
        int max = 0;
        while (im.find()) max = Math.max(max, Integer.parseInt(im.group(1)));
        int[] nxt = {max + 1};
        java.util.Set<String> vsIds = new java.util.HashSet<String>();
        Matcher vm = Pattern.compile("<File fileId=\"(\\d+)\" filename=\"[^\"]*vehicleShader\\.xml\"").matcher(s);
        while (vm.find()) vsIds.add(vm.group(1));
        if (vsIds.isEmpty()) return s;
        java.util.LinkedHashMap<String, Integer> added = new java.util.LinkedHashMap<String, Integer>();
        Matcher mm = MATERIAL.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (mm.find()) {
            String mat = mm.group(0);
            Matcher cs = Pattern.compile("customShaderId=\"(\\d+)\"").matcher(mat);
            if (!mat.contains("detailDiffuse") && cs.find() && vsIds.contains(cs.group(1))) {
                Matcher nm = Pattern.compile("name=\"([^\"]*)\"").matcher(mat);
                String name = nm.find() ? nm.group(1).toLowerCase() : "";
                String[] set = name.matches(".*(tire|rubber|tyre).*") ? D_RUBBER : name.matches(".*(chrome|mirror|metal).*") ? D_CHROME : D_PAINT;
                int[] ids = new int[3];
                for (int i = 0; i < 3; i++) {
                    Integer id = added.get(set[i]);
                    if (id == null) { id = nxt[0]++; added.put(set[i], id); }
                    ids[i] = id;
                }
                String add = "      <Custommap name=\"detailSpecular\" fileId=\"" + ids[2] + "\"/>\n"
                           + "      <Custommap name=\"detailNormal\" fileId=\"" + ids[1] + "\"/>\n"
                           + "      <Custommap name=\"detailDiffuse\" fileId=\"" + ids[0] + "\"/>";
                Matcher ins = Pattern.compile("(\\s*<CustomParameter|\\s*</Material>)").matcher(mat);
                if (ins.find()) { mat = mat.substring(0, ins.start()) + "\n" + add + mat.substring(ins.start()); n[0]++; }
            }
            mm.appendReplacement(sb, Matcher.quoteReplacement(mat));
        }
        mm.appendTail(sb);
        s = sb.toString();
        StringBuilder files = new StringBuilder();
        for (java.util.Map.Entry<String, Integer> e : added.entrySet()) files.append("    <File fileId=\"").append(e.getValue()).append("\" filename=\"").append(e.getKey()).append("\"/>\n");
        int k = s.indexOf("</Files>");
        return k < 0 ? s : s.substring(0, k) + files + s.substring(k);
    }

    private static final String[] DROP_BLOCKS = {"simpleIC", "baseMaterial", "audioMemoryUsage"};
    private static final Pattern RENAME_CFG = Pattern.compile("<(/?)(base|design)Material(\\d*)Configuration(s?)\\b");
    private static final Pattern COLOR_CFG = Pattern.compile("<((?:base|design)Color\\d*Configuration)(\\s[^>]*)");
    private static final Pattern RIM_COLOR = Pattern.compile("(<rimColorConfiguration\\s[^>]*?)color=\"([^\"]*)\"");
    private static final java.util.Map<String, String> COLOR_NAMES = new java.util.HashMap<String, String>();
    static {
        COLOR_NAMES.put("Blue", "Blue"); COLOR_NAMES.put("Red", "Red"); COLOR_NAMES.put("Black", "Black"); COLOR_NAMES.put("Green", "Green");
        COLOR_NAMES.put("Orange", "Orange"); COLOR_NAMES.put("Gray", "Grey"); COLOR_NAMES.put("White", "White");
    }

    private static boolean wellFormed(String xml) {
        try {
            javax.xml.parsers.DocumentBuilder b = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
            b.setErrorHandler(null);
            b.parse(new org.xml.sax.InputSource(new java.io.StringReader(xml)));
            return true;
        } catch (Throwable e) { return false; }
    }

    private static int countOf(Pattern p, String s) { Matcher m = p.matcher(s); int c = 0; while (m.find()) c++; return c; }

    /** XML техніки FS23: зламані коментарі «<!-->», блоки simpleIC/baseMaterial/audioMemoryUsage, *MaterialConfiguration → *ColorConfiguration,
     *  кольори «r g b m» → «r g b» + material (rim — підтверджено логом гри «Invalid rgb color»). Безпечно: якщо результат гірший за вхід — повертається вхід. */
    public static Result fixVehicleXml(String original) {
        String s = original;
        int n = 0;
        if (s.contains("<!-->")) {
            String a = s.replaceAll("<!-->[^\\n<]*<!-->", "");
            if (!a.equals(s)) { s = a; n++; }
            Pattern mp = Pattern.compile("[ \\t]*<!-->[^\\n]*?<!--.*?<!-->[ \\t]*\\r?\\n?", Pattern.DOTALL);
            if (mp.matcher(s).find()) { s = mp.matcher(s).replaceAll(""); n++; }
        }
        for (String tag : DROP_BLOCKS) {
            Pattern self = Pattern.compile("<" + tag + "(?=[\\s>/])[^>]*/>[ \\t]*\\r?\\n?");
            Pattern blk = Pattern.compile("<" + tag + "(?=[\\s>])[^>]*(?<!/)>.*?</" + tag + ">[ \\t]*\\r?\\n?", Pattern.DOTALL);
            n += countOf(self, s); s = self.matcher(s).replaceAll("");
            n += countOf(blk, s); s = blk.matcher(s).replaceAll("");
        }
        Pattern slotP = Pattern.compile("<material\\s+name=\"([^\"]+)\"\\s+shaderParameter=\"[^\"]*\"\\s*/>");
        n += countOf(slotP, s);
        s = slotP.matcher(s).replaceAll("<material materialSlotName=\"$1\" />");
        n += countOf(RENAME_CFG, s);
        s = RENAME_CFG.matcher(s).replaceAll("<$1$2Color$3Configuration$4");
        Matcher cm = COLOR_CFG.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (cm.find()) {
            String attrs = cm.group(2);
            Matcher col = Pattern.compile("color=\"([^\"]*)\"").matcher(attrs);
            if (col.find()) {
                String[] v = col.group(1).trim().split("\\s+");
                if (v.length >= 4) { attrs = attrs.replace(col.group(0), "color=\"" + v[0] + " " + v[1] + " " + v[2] + "\""); n++; }
            }
            Matcher nm = Pattern.compile("name=\"\\$l10n_(\\w+)\"").matcher(attrs);
            StringBuffer sb2 = new StringBuffer();
            while (nm.find()) {
                String to = COLOR_NAMES.get(nm.group(1));
                nm.appendReplacement(sb2, Matcher.quoteReplacement(to != null ? "name=\"$l10n_ui_color" + to + "\"" : nm.group(0)));
                if (to != null) n++;
            }
            nm.appendTail(sb2);
            cm.appendReplacement(sb, Matcher.quoteReplacement("<" + cm.group(1) + sb2));
        }
        cm.appendTail(sb);
        s = sb.toString();
        Matcher rm = RIM_COLOR.matcher(s);
        sb = new StringBuffer();
        while (rm.find()) {
            String[] v = rm.group(2).trim().split("\\s+");
            String rep = rm.group(0);
            if (v.length >= 4) {
                rep = rm.group(1) + "color=\"" + v[0] + " " + v[1] + " " + v[2] + "\"";
                n++;
            }
            rm.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        rm.appendTail(sb);
        s = sb.toString();
        if (n == 0) return new Result(original, 0);
        if (wellFormed(original) && !wellFormed(s)) return new Result(original, 0);
        return new Result(s, n);
    }

    /** wheels/*.xml: прибрати isCareWheel, додати схему fs25/wheel.xsd. */
    public static Result fixWheelXml(String s) {
        if (!s.contains("isCareWheel")) return new Result(s, 0);
        String t = s.replaceAll("\\s+isCareWheel=\"[^\"]*\"", "");
        if (t.contains("<wheel>")) t = t.replaceFirst("<wheel>", Matcher.quoteReplacement("<wheel xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"https://validation.gdn.giants-software.com/xml/fs25/wheel.xsd\">"));
        return new Result(t, 1);
    }
}
