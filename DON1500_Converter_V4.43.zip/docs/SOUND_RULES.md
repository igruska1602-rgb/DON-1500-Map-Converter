# Звук двигуна FS26 Mobile (зразок: CHTZ_T_170 → FIX_CHTZ_T_170)

Порівняння оригіналу й виправленого мода (sound/T_170.xml):
- `motorStart`, `motorStop`, `motor` (idle / offload / onload): `template="DEFAULT_MOTOR_START|STOP|IDLE|OFFLOAD_RUN|ONLOAD_RUN"` ПРИБРАНО, `file=…` та всі інші атрибути (volumeScale, outerRadius, linkNode) без змін.
- `gearbox template="transmissionSmall"` — шаблон ЗАЛИШЕНО.
- У FIX-версії також: `retarder` без `template="DEFAULT_RETARDER"` і `.wav` → `.ogg` (gearbox/retarder; у архіві були лише .ogg) — це не частина правила звуку двигуна; правило `.wav→.ogg` робить конвертер окремо.
- Інше, що змінилось у FIX: BOM прибрано, CRLF→LF, isCareWheel прибрано, `baseMaterial` → `baseColorConfigurations` (робота конвертера).

Правило в коді: `ModFix.fixMotorSoundTemplates` — лише елементи з DEFAULT_MOTOR_… І власним `file=`; решта звуків не чіпається. Спрацьовує в усіх режимах із ціллю FS26.

## Дополнення за досвідом T-150 (FS22_T150_05_09 → FIX_T150_05_09_1), v4.43
Мобільна гра не має ПК-шаблонів: `DEFAULT_MOTOR_START/STOP/IDLE/RUN/ONLOAD_RUN`, `SWITCH_01`, `SWITCH_TURNLIGHT`, `ATTACH_01`, `defaultHydraulicSound`, `HONK_*` → «Sound template … was not found», звуку немає.
Правило `ModFix.fixMobileSounds(xml, minRpm, maxRpm)`:
1. Регістр тегів: `motorstart`/`motorstop` → `motorStart`/`motorStop`.
2. `template="DEFAULT_MOTOR_*"` прибрати (файли `file=` лишаються).
3. `<motor>` із `<volume/>` без modifier: додати MOTOR_RPM/MOTOR_LOAD. Для minRpm=450, maxRpm=2100 збігається із зразком: idle volume 450→1, 800→1, 1000→0, pitch 450→0.9, 1000→1.1; run volume 700→0, 1000→1, 2100→1, pitch 700→0.8, 2100→1.4; onload volume MOTOR_LOAD 0.3→0, 0.8→1. Точки: idle (min, max(800,min+100), max(1000,min+300)); run (max(700,min+150), max(1000,min+400), max). Самозакриті `<motor …/>` без `<volume>` (CHTZ-тип) — лише прибирання template.
4. Елементи з шаблонами SWITCH_01, SWITCH_TURNLIGHT, ATTACH_01, defaultHydraulicSound, HONK_* видаляються разом з порожніми `<sounds>`, `<lights>`, `<attacherJoints>`. Назви мобільних аналогів НЕ вигадуються (потрібен зразок з базового трактора).
5. `.wav` → `.ogg` (окреме правило конвертера). Ризик: мобільна може віддавати перевагу `.gls`.
minRpm/maxRpm — з першого `<motor minRpm maxRpm>` у xml техніки (за замовчуванням 700/2100).

## Підпис DON-1500 (обов'язковий, усі режими)
`ModFix.addCredit` (константа `ModFix.CREDIT`): `<author>… , converted by DON-1500</author>`, у кожну мову `<description>` додається «Converted with DON-1500 Converter», у modDesc — XML-коментар. Не залежить від налаштувань підпису (окремий необов'язковий підпис ніком лишається). Звіт завжди починається з «DON-1500 Converter — ЗВІТ».

## Гусениці (досвід T-150)
trackArray: RGBA16F DDS → GS2D-.ast (0x05); у FS26-зразку FIX_T150 — scrollLength 2.0→1, scrollPosition→scrollPos, motionPathRubber_secondUV_colorMask→motionPathRubber_vmaskUV2, RDT/colorMat* прибрано, crawlerRealLength=2.0 (=стара scrollLength), mTrackArray→trackArray; numberShader→vehicleShader. Усе це робить конвертер ≥4.39.
