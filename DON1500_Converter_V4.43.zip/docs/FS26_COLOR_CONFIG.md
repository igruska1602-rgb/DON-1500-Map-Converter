# Вибір фарби (color configurations) FS22/23 → FS26 Mobile

Зразок: «Золотий Дон» (FS26): Don1500.xml / Pun.xml / Kopnitel.xml. Робочий FS26-формат:
```xml
<baseColorConfigurations>
  <baseColorConfiguration color="DEUTZ_RED1" isDefault="true"/>      <!-- або materialTemplateName="…", або color="r g b" -->
  <material materialSlotName="korpusA_mat"/>                           <!-- slotName = ІМ'Я МАТЕРІАЛУ в i3d (атрибута у Material нема) -->
  <material materialSlotName="boltiMost_mat"><detail diffuse="$data/shared/detailLibrary/…_diffuse.png" normal="…flat_normal.png" specular="…"/></material>
</baseColorConfigurations>
```
FS22: `<baseColorConfiguration name=… material="6" color="gomselmash_RED"/>` + `<material name="kuzov" shaderParameter="colorMat0"/>`; кольори `gomselmash_*` визначені в modDesc `<colors><color name value="r g b a"/>` — FS26 такого імені не знає («Failed to parse … vector 'gomselmash_RED'») → немає вибору фарби.

Правила конвертера (ModFix.fixVehicleXml(xml, nodeMat, colorDefs)):
1. `color="ІМ'Я"` з modDesc → `color="r g b"`.
2. `<material name="X" shaderParameter=…>` → `<material materialSlotName="М" />`, де М — ім'я матеріалу: X сам матеріал / вузол X / вузол X_vis / матеріал X+Mat, X+_mat / матеріал, що починається з X.
3. Дублі слотів у межах блока base/design/rim прибираються; залишок `material="N"` в *ColorConfiguration прибирається.
4. Атрибут materialSlotName в i3d НЕ додається (було в 4.35 — помилка).
Невирішено: вузли, які в xml задано index-шляхом (kuzov, stupici у 2PTS) — слот лишається за старим іменем.
