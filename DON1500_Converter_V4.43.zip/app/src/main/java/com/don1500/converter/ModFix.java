package com.don1500.converter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Універсальні виправлення XML модів для FS26 Mobile (за повідомленнями з реального логу гри). Без залежностей від Android. */
public final class ModFix {
    private ModFix() {}

    public static final class Result {
        public final String text; public final int count;
        Result(String text, int count) { this.text = text; this.count = count; }
    }

    private static final Pattern FOLDABLE = Pattern.compile("<foldable\\b[^>]*>(.*?)</foldable>", Pattern.DOTALL);

    /**
     * «'vehicle.foldable.foldingParts' is not supported anymore»: старий вигляд
     * &lt;foldable&gt;&lt;foldingParts&gt;…&lt;/foldingParts&gt;&lt;/foldable&gt; загортається в foldingConfigurations/foldingConfiguration.
     */
    public static Result fixFolding(String xml) {
        Matcher m = FOLDABLE.matcher(xml);
        StringBuilder sb = new StringBuilder(); int last = 0, n = 0;
        while (m.find()) {
            String inner = m.group(1);
            if (inner.contains("<foldingConfigurations") || !inner.contains("<foldingParts")) continue;
            int a = inner.indexOf("<foldingParts");
            int endTag = inner.lastIndexOf("</foldingParts>");
            int b;
            if (endTag >= 0) b = endTag + "</foldingParts>".length();
            else { int e = inner.indexOf("/>", a); if (e < 0) continue; b = e + 2; }
            // самозакрита <foldingParts .../> — теж підтримуємо
            String block = inner.substring(a, b);
            String wrapped = "<foldingConfigurations>\n            <foldingConfiguration>\n                " + block + "\n            </foldingConfiguration>\n        </foldingConfigurations>";
            String newInner = inner.substring(0, a) + wrapped + inner.substring(b);
            int s = m.start(1), e2 = m.end(1);
            sb.append(xml, last, s).append(newInner); last = e2; n++;
        }
        if (n == 0) return new Result(xml, 0);
        sb.append(xml, last, xml.length());
        return new Result(sb.toString(), n);
    }

    private static final Pattern DASHBOARD_FONT = Pattern.compile("\\s+font=\"DIGIT_BOLD\"");

    /** «Unknown font 'DIGIT_BOLD'»: такого шрифту в FS26 Mobile немає — прибираємо атрибут (діє шрифт за замовчуванням). */
    public static Result fixFonts(String xml) {
        Matcher m = DASHBOARD_FONT.matcher(xml);
        int n = 0; while (m.find()) n++;
        return n == 0 ? new Result(xml, 0) : new Result(DASHBOARD_FONT.matcher(xml).replaceAll(""), n);
    }

    private static final Pattern TYPE = Pattern.compile("<type\\b[^>]*>.*?</type>", Pattern.DOTALL);
    private static final Pattern SPEC = Pattern.compile("[ \\t]*<specialization\\s+name=\"([^\"]+)\"\\s*/>[ \\t]*\\r?\\n?");

    /**
     * «Specialization 'attacherJoints' already exists for vehicle type …»: власні типи техніки в modDesc повторюють специфікації,
     * які вже є в батьківському типі (підтверджено логом гри: baseTipper уже містить attacherJoints), або дублюють одна одну.
     */
    public static Result fixVehicleTypes(String modDesc) {
        Matcher m = TYPE.matcher(modDesc);
        StringBuilder sb = new StringBuilder(); int last = 0, n = 0;
        while (m.find()) {
            String block = m.group();
            String parent = attr(block, "parent");
            java.util.Set<String> inherited = new java.util.HashSet<>();
            if ("baseTipper".equals(parent)) inherited.add("attacherJoints");
            Matcher sm = SPEC.matcher(block);
            StringBuilder nb = new StringBuilder(); int l2 = 0; int removed = 0;
            java.util.Set<String> seen = new java.util.HashSet<>();
            while (sm.find()) {
                String name = sm.group(1);
                if (inherited.contains(name) || !seen.add(name)) { nb.append(block, l2, sm.start()); l2 = sm.end(); removed++; }
            }
            if (removed == 0) continue;
            nb.append(block, l2, block.length());
            sb.append(modDesc, last, m.start()).append(nb); last = m.end(); n += removed;
        }
        if (n == 0) return new Result(modDesc, 0);
        sb.append(modDesc, last, modDesc.length());
        return new Result(sb.toString(), n);
    }

    private static String attr(String tagBlock, String name) {
        int end = tagBlock.indexOf('>');
        Matcher m = Pattern.compile("\\b" + name + "=\"([^\"]*)\"").matcher(tagBlock.substring(0, Math.max(0, end)));
        return m.find() ? m.group(1) : "";
    }

    // ===================== FS23 → FS26: правила з пакета знань (див. docs/RULES_FS23_to_FS26.md) =====================
    private static final java.util.Set<String> BAD_VARIATIONS = new java.util.HashSet<String>(java.util.Arrays.asList("colorMask", "Decal", "uvScroll", "windBend"));
    private static final java.util.Set<String> OK_VARIATIONS = new java.util.HashSet<String>(java.util.Arrays.asList("staticLight", "staticLight_vertex", "tirePressureDeformation", "uvTransform", "vmaskUV2", "additive_colorScale",
        // з реальних FS26-гусениць (crawlers_Depends)
        "vmaskUV2_normalUV3", "motionPathRubber_vmaskUV2", "motionPathRubber", "motionPath", "motionPath_vmaskUV2", "vtxRotate", "reflector", "meshScroll", "meshScroll_vmaskUV2", "visibilityCut", "jiggling"));
    private static final Pattern SECOND_UV = Pattern.compile("(^|_)secondUV(?=_|$)");
    private static final java.util.Set<String> DROP_PARAMS = new java.util.HashSet<String>(java.util.Arrays.asList(
        "RDT", "offsetUV", "directionBend", "prevDirectionBend", "blinkOffset", "prevMorphPosition",
        "colorMat0", "colorMat1", "colorMat2", "colorMat3", "colorMat4", "colorMat5", "colorMat6", "colorMat7"));
    private static final Pattern I3D_FILE = Pattern.compile("(<File\\b[^>]*?\\bfilename=\")([^\"]+)\"");
    private static final Pattern MATERIAL = Pattern.compile("<Material\\b[^>]*?(?<!/)>.*?</Material>", Pattern.DOTALL);
    private static final Pattern VARIATION = Pattern.compile("\\s+customShaderVariation=\"([^\"]*)\"");
    private static final Pattern BAD_TOKEN = Pattern.compile("(^|_)(colorMask|Decal|uvScroll|windBend)(?=_|$)");
    private static final Pattern CPARAM = Pattern.compile("[ \\t]*<CustomParameter name=\"([^\"]+)\" value=\"([^\"]*)\"\\s*/>[ \\t]*\\r?\\n?");
    private static final String DL = "$data/shared/detailLibrary/";
    private static final String[] D_PAINT = {DL + "nonMetallic/metal/metalPaintedOld_diffuse.png", DL + "flat_normal.png", DL + "nonMetallic/metal/metalPaintedOld_specular.png"};
    private static final String[] D_RUBBER = {DL + "nonMetallic/rubber/rubberBlack_diffuse.png", DL + "nonMetallic/rubber/rubber_normal.png", DL + "nonMetallic/rubber/rubber_specular.png"};
    private static final String[] D_CHROME = {DL + "metallic/clear_diffuse.png", DL + "flat_normal.png", DL + "metallic/clear_specular.png"};

    /**
     * i3d: (1) «\» → «/» у шляхах; (2) шейдер-варіації, яких немає у FS26 (colorMask, Decal, uvScroll, windBend) — ПІДТВЕРДЖЕНО ГРОЮ:
     * «Can't load resource data/shaders/vehicleShader.xml» і вильот; (3) лише для файлів FS23 (є colorMask/colorMat0): параметри FS22 прибираються,
     * morphPosition → morphPos, колір з маски → colorScale; (4) за бажанням — detail-maps (експеримент, у грі не перевірено).
     */
    public static Result fixI3d(String s, boolean detailMaps) { return fixI3d(s, detailMaps, null); }

    public static Result fixI3d(String s, boolean detailMaps, java.util.Set<String> slotNames) { return fixI3d(s, detailMaps, slotNames, null); }

    /** crawlerLen — довжина гусениці (м) зі scrollLength у crawler-xml, що посилається на цей i3d (для crawlerRealLength). */
    public static Result fixI3d(String s, boolean detailMaps, java.util.Set<String> slotNames, String crawlerLen) {
        int[] n = new int[1];
        Matcher fm = I3D_FILE.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (fm.find()) {
            String p = fm.group(2);
            if (p.indexOf('\\') >= 0) { n[0]++; p = p.replace('\\', '/'); }
            fm.appendReplacement(sb, Matcher.quoteReplacement(fm.group(1) + p + "\""));
        }
        fm.appendTail(sb);
        s = sb.toString();
        if (s.contains("shaders/numberShader.xml")) { s = s.replace("shaders/numberShader.xml", "shaders/vehicleShader.xml"); n[0]++; }
        boolean fs23File = Pattern.compile("customShaderVariation=\"[^\"]*colorMask").matcher(s).find() || s.contains("name=\"colorMat0\"");
        Matcher mm = MATERIAL.matcher(s);
        sb = new StringBuffer();
        while (mm.find()) mm.appendReplacement(sb, Matcher.quoteReplacement(fixMaterial(mm.group(0), n, fs23File, crawlerLen)));
        mm.appendTail(sb);
        s = sb.toString();
        s = fixCollisionBits(s, n);
        if (detailMaps && fs23File) s = addDetailMaps(s, n);
        return new Result(s, n[0]);
    }

    private static final Pattern COMPONENT_NODE = Pattern.compile("<(?:TransformGroup|Shape)\\b[^>]*>");
    private static final Pattern COLL_ATTR = Pattern.compile("\\b(collisionFilterGroup|collisionFilterMask)=\"(0[xX][0-9a-fA-F]+|\\d+)\"");

    /** Гра FS26: «Missing collision group/filter mask bit 16 (VEHICLE). Please add this bit to component node …_main_component1» — без цього біта немає колізій техніки. */
    private static String fixCollisionBits(String s, int[] n) {
        Matcher nm = COMPONENT_NODE.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (nm.find()) {
            String tag = nm.group(0);
            boolean isComponent = tag.contains("main_component") || (tag.contains("dynamic=\"true\"") && tag.contains("compound=\"true\""));
            if (!isComponent) { nm.appendReplacement(sb, Matcher.quoteReplacement(tag)); continue; }
            if (!tag.contains("collisionFilterGroup=") && tag.contains("collisionMask=")) {
                // FS22: один collisionMask; FS26 хоче Group+Mask з бітом VEHICLE. Значення — з робочого FS26-трактора (MTZ 82 UK): 0x10004 / 0xfe3ffb83.
                tag = tag.replaceFirst("collisionMask=\"[^\"]*\"", "collisionFilterGroup=\"0x10004\" collisionFilterMask=\"0xfe3ffb83\"");
                n[0]++;
            }
            Matcher am = COLL_ATTR.matcher(tag);
            StringBuffer tb = new StringBuffer();
            while (am.find()) {
                String rep = am.group(0);
                try {
                    long v = Long.decode(am.group(2));
                    if ((v & 0x10000L) == 0) { rep = am.group(1) + "=\"0x" + Long.toHexString(v | 0x10000L) + "\""; n[0]++; }
                } catch (NumberFormatException e) { /* лишаємо як є */ }
                am.appendReplacement(tb, Matcher.quoteReplacement(rep));
            }
            am.appendTail(tb);
            nm.appendReplacement(sb, Matcher.quoteReplacement(tb.toString()));
        }
        nm.appendTail(sb);
        return sb.toString();
    }

    private static String attrOf(String tag, String attr) {
        Matcher m = Pattern.compile("\\b" + attr + "=\"([^\"]*)\"").matcher(tag);
        return m.find() ? m.group(1) : null;
    }

    /** FS22: <material name="kuzov" shaderParameter=…> шукав матеріал вузла kuzov. FS26: materialSlotName у Material. Слот = ім'я вузла (або Material name / name+Mat). */
    private static String assignSlotNames(String s, java.util.Set<String> slotNames, int[] n) {
        java.util.Map<String, String> slotByMatId = new java.util.HashMap<String, String>();
        Matcher nm = Pattern.compile("<(?:Shape|TransformGroup)\\b[^>]*>").matcher(s);
        while (nm.find()) {
            String tag = nm.group(0), name = attrOf(tag, "name"), ids = attrOf(tag, "materialIds");
            if (name == null || ids == null || !slotNames.contains(name)) continue;
            String first = ids.split("[,\\s]+")[0];
            if (!first.isEmpty() && !slotByMatId.containsValue(name) && !slotByMatId.containsKey(first)) slotByMatId.put(first, name);
        }
        Matcher mm = MATERIAL.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (mm.find()) {
            String mat = mm.group(0);
            if (!mat.contains("materialSlotName=")) {
                String slot = slotByMatId.get(attrOf(mat, "materialId"));
                String mname = attrOf(mat, "name");
                if (slot == null && mname != null) {
                    for (String cand : slotNames) if (mname.equals(cand) || mname.equalsIgnoreCase(cand + "Mat") || mname.equalsIgnoreCase(cand + "_mat")) { if (!slotByMatId.containsValue(cand)) { slot = cand; break; } }
                }
                if (slot != null) {
                    Matcher h = Pattern.compile("^<Material\\b").matcher(mat);
                    if (h.find()) { mat = "<Material materialSlotName=\"" + slot + "\"" + mat.substring(h.end()); n[0]++; }
                }
            }
            mm.appendReplacement(sb, Matcher.quoteReplacement(mat));
        }
        mm.appendTail(sb);
        return sb.toString();
    }

    private static String fixMaterial(String mat, int[] n, boolean fs23File, String crawlerLen) {
        boolean wasMask = false;
        Matcher vm = VARIATION.matcher(mat);
        if (vm.find()) {
            String v = vm.group(1);
            Matcher bm = BAD_TOKEN.matcher(v);
            if (bm.find() || SECOND_UV.matcher(v).find()) {
                wasMask = v.matches(".*(^|_)colorMask(_.*|$)");
                String rest = BAD_TOKEN.matcher(v).replaceAll("").replaceAll("^_+|_+$", "").replaceAll("_{2,}", "_");
                rest = SECOND_UV.matcher(rest).replaceAll("$1vmaskUV2");   // FS22 secondUV = друга UV-розгортка маски → FS26 vmaskUV2
                // Лишаємо тільки варіації, що є в робочому FS26 (staticLight, vmaskUV2…); решта (напр. motionPathRubber_secondUV) → базова
                mat = mat.replace(vm.group(0), OK_VARIATIONS.contains(rest) ? " customShaderVariation=\"" + rest + "\"" : "");
                n[0]++;
            }
        }
        if (mat.contains("name=\"mTrackArray\"") || (mat.contains("motionPath") && mat.contains("name=\"lengthAndRadius\""))) {
            // Гусениці FS22 → FS26: Custommap mTrackArray → trackArray; scrollPosition/prevScrollPosition/lengthAndRadius → crawlerRealLength (довжина гусениці в метрах)
            if (mat.contains("name=\"mTrackArray\"")) { mat = mat.replace("name=\"mTrackArray\"", "name=\"trackArray\""); n[0]++; }
            Matcher cp = CPARAM.matcher(mat);
            StringBuffer cb = new StringBuffer();
            while (cp.find()) {
                String nm = cp.group(1);
                boolean drop = nm.equals("scrollPosition") || nm.equals("prevScrollPosition") || nm.equals("lengthAndRadius");
                if (drop) n[0]++;
                cp.appendReplacement(cb, Matcher.quoteReplacement(drop ? "" : cp.group(0)));
            }
            cp.appendTail(cb);
            mat = cb.toString();
            int k = mat.lastIndexOf("</Material>");
            if (crawlerLen != null && !mat.contains("crawlerRealLength") && k >= 0) {
                mat = mat.substring(0, k) + "  <CustomParameter name=\"crawlerRealLength\" value=\"" + crawlerLen + "\"/>\n    " + mat.substring(k);
                n[0]++;
            }
        }
        if (!fs23File) return mat;
        boolean hasTex = mat.contains("<Texture ");
        String cm0 = null;
        Matcher p0 = Pattern.compile("<CustomParameter name=\"colorMat0\" value=\"([^\"]*)\"").matcher(mat);
        if (p0.find()) cm0 = p0.group(1);
        Matcher pm = CPARAM.matcher(mat);
        StringBuffer sb = new StringBuffer();
        while (pm.find()) {
            String name = pm.group(1), rep = pm.group(0);
            if (DROP_PARAMS.contains(name)) { rep = ""; n[0]++; }
            else if (name.equals("morphPosition")) { rep = rep.replace("morphPosition", "morphPos"); n[0]++; }
            pm.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        pm.appendTail(sb);
        mat = sb.toString();
        if (wasMask && !hasTex && cm0 != null && !mat.contains("name=\"colorScale\"")) {
            String[] c = cm0.trim().split("\\s+");
            int k = mat.lastIndexOf("</Material>");
            if (c.length >= 3 && k >= 0) {
                mat = mat.substring(0, k) + "  <CustomParameter name=\"colorScale\" value=\"" + c[0] + " " + c[1] + " " + c[2] + "\"/>\n    " + mat.substring(k);
                n[0]++;
            }
        }
        return mat;
    }

    private static String addDetailMaps(String s, int[] n) {
        int end = s.indexOf("</Files>");
        if (end < 0) return s;
        Matcher im = Pattern.compile("<File fileId=\"(\\d+)\"").matcher(s);
        int max = 0;
        while (im.find()) max = Math.max(max, Integer.parseInt(im.group(1)));
        int[] nxt = {max + 1};
        java.util.Set<String> vsIds = new java.util.HashSet<String>();
        Matcher vm = Pattern.compile("<File fileId=\"(\\d+)\" filename=\"[^\"]*vehicleShader\\.xml\"").matcher(s);
        while (vm.find()) vsIds.add(vm.group(1));
        if (vsIds.isEmpty()) return s;
        java.util.LinkedHashMap<String, Integer> added = new java.util.LinkedHashMap<String, Integer>();
        Matcher mm = MATERIAL.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (mm.find()) {
            String mat = mm.group(0);
            Matcher cs = Pattern.compile("customShaderId=\"(\\d+)\"").matcher(mat);
            if (!mat.contains("detailDiffuse") && !mat.contains("<Texture ") && cs.find() && vsIds.contains(cs.group(1))) {
                Matcher nm = Pattern.compile("name=\"([^\"]*)\"").matcher(mat);
                String name = nm.find() ? nm.group(1).toLowerCase() : "";
                String[] set = name.matches(".*(tire|rubber|tyre).*") ? D_RUBBER : name.matches(".*(chrome|mirror|metal).*") ? D_CHROME : D_PAINT;
                int[] ids = new int[3];
                for (int i = 0; i < 3; i++) {
                    Integer id = added.get(set[i]);
                    if (id == null) { id = nxt[0]++; added.put(set[i], id); }
                    ids[i] = id;
                }
                String add = "      <Custommap name=\"detailSpecular\" fileId=\"" + ids[2] + "\"/>\n"
                           + "      <Custommap name=\"detailNormal\" fileId=\"" + ids[1] + "\"/>\n"
                           + "      <Custommap name=\"detailDiffuse\" fileId=\"" + ids[0] + "\"/>";
                Matcher ins = Pattern.compile("(\\s*<CustomParameter|\\s*</Material>)").matcher(mat);
                if (ins.find()) { mat = mat.substring(0, ins.start()) + "\n" + add + mat.substring(ins.start()); n[0]++; }
            }
            mm.appendReplacement(sb, Matcher.quoteReplacement(mat));
        }
        mm.appendTail(sb);
        s = sb.toString();
        StringBuilder files = new StringBuilder();
        for (java.util.Map.Entry<String, Integer> e : added.entrySet()) files.append("    <File fileId=\"").append(e.getValue()).append("\" filename=\"").append(e.getKey()).append("\"/>\n");
        int k = s.indexOf("</Files>");
        return k < 0 ? s : s.substring(0, k) + files + s.substring(k);
    }

    private static final String[] DROP_BLOCKS = {"simpleIC", "baseMaterial", "audioMemoryUsage"};
    private static final Pattern RENAME_CFG = Pattern.compile("<(/?)(base|design)Material(\\d*)Configuration(s?)\\b");
    private static final Pattern COLOR_CFG = Pattern.compile("<((?:base|design)Color\\d*Configuration)(\\s[^>]*)");
    private static final Pattern RIM_COLOR = Pattern.compile("(<rimColorConfiguration\\s[^>]*?)color=\"([^\"]*)\"");
    private static final java.util.Map<String, String> COLOR_NAMES = new java.util.HashMap<String, String>();
    static {
        COLOR_NAMES.put("Blue", "Blue"); COLOR_NAMES.put("Red", "Red"); COLOR_NAMES.put("Black", "Black"); COLOR_NAMES.put("Green", "Green");
        COLOR_NAMES.put("Orange", "Orange"); COLOR_NAMES.put("Gray", "Grey"); COLOR_NAMES.put("White", "White");
    }

    private static boolean wellFormed(String xml) {
        try {
            javax.xml.parsers.DocumentBuilder b = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
            b.setErrorHandler(null);
            b.parse(new org.xml.sax.InputSource(new java.io.StringReader(xml)));
            return true;
        } catch (Throwable e) { return false; }
    }

    private static int countOf(Pattern p, String s) { Matcher m = p.matcher(s); int c = 0; while (m.find()) c++; return c; }

    /** XML техніки FS23: зламані коментарі «<!-->», блоки simpleIC/baseMaterial/audioMemoryUsage, *MaterialConfiguration → *ColorConfiguration,
     *  кольори «r g b m» → «r g b» + material (rim — підтверджено логом гри «Invalid rgb color»). Безпечно: якщо результат гірший за вхід — повертається вхід. */
    public static Result fixVehicleXml(String original) { return fixVehicleXml(original, null, null); }

    private static final Pattern MAT_TAG = Pattern.compile("<Material\\b[^>]*?(?<!/)>|<Material\\b[^>]*/>");
    private static final Pattern NODE_TAG = Pattern.compile("<(?:Shape|TransformGroup)\\b[^>]*>");

    /** i3d → {ім'я вузла → ім'я його (першого) матеріалу}. У FS22 <material name="kuzov"> — це ІМ'Я ВУЗЛА, у FS26 materialSlotName — ІМ'Я МАТЕРІАЛУ. */
    public static java.util.Map<String, String> nodeMaterialNames(String i3d) {
        java.util.Map<String, String> idToName = new java.util.HashMap<String, String>();
        Matcher mm = MAT_TAG.matcher(i3d);
        while (mm.find()) { String id = attrOf(mm.group(0), "materialId"), nm = attrOf(mm.group(0), "name"); if (id != null && nm != null) idToName.put(id, nm); }
        java.util.Map<String, String> out = new java.util.LinkedHashMap<String, String>();
        java.util.List<String> pending = new java.util.ArrayList<String>();   // групи без materialIds: беруть матеріал першого нащадка-Shape
        Matcher nm = NODE_TAG.matcher(i3d);
        while (nm.find()) {
            String tag = nm.group(0), name = attrOf(tag, "name"), ids = attrOf(tag, "materialIds");
            boolean selfClosed = tag.endsWith("/>");
            if (ids == null) { if (name != null && !selfClosed) pending.add(name); continue; }
            String mn = idToName.get(ids.trim().split("[,\\s]+")[0]);
            if (mn != null) {
                if (name != null && !out.containsKey(name)) out.put(name, mn);
                for (String p : pending) if (!out.containsKey(p)) out.put(p, mn);
            }
            pending.clear();
        }
        for (String mn : idToName.values()) if (!out.containsKey(mn)) out.put(mn, mn);   // матеріал → сам себе
        return out;
    }

    /** modDesc <color name="gomselmash_RED" value="0.591 0.05 0.023 1"/> → {ім'я → "r g b"}. */
    public static java.util.Map<String, String> modDescColors(String modDesc) {
        java.util.Map<String, String> out = new java.util.HashMap<String, String>();
        Matcher m = Pattern.compile("<color\\s+name=\"([^\"]+)\"\\s+value=\"([^\"]+)\"").matcher(modDesc);
        while (m.find()) { String[] v = m.group(2).trim().split("\\s+"); if (v.length >= 3) out.put(m.group(1), v[0] + " " + v[1] + " " + v[2]); }
        return out;
    }

    /** Ім'я зі старого xml → ім'я матеріалу: сам матеріал / вузол / вузол+_vis / матеріал «імʼя»+Mat|_mat / матеріал, що починається з імені. */
    static String resolveSlot(String x, java.util.Map<String, String> nodeMat) {
        if (nodeMat == null || nodeMat.isEmpty()) return x;
        String y = nodeMat.get(x);
        if (y == null) y = nodeMat.get(x + "_vis");
        if (y == null) for (String mn : new java.util.LinkedHashSet<String>(nodeMat.values())) {
            if (mn.equalsIgnoreCase(x + "Mat") || mn.equalsIgnoreCase(x + "_mat")) { y = mn; break; }
        }
        if (y == null) for (String mn : new java.util.LinkedHashSet<String>(nodeMat.values())) {
            if (mn.toLowerCase().startsWith(x.toLowerCase()) && !x.isEmpty()) { y = mn; break; }
        }
        return y != null ? y : x;
    }

    private static final Pattern SLOT_FS22 = Pattern.compile("<material\\s+name=\"([^\"]+)\"\\s+shaderParameter=\"[^\"]*\"\\s*/>");
    private static final Pattern SLOT_FS26 = Pattern.compile("<material\\s+materialSlotName=\"([^\"]+)\"\\s*/>");
    private static final Pattern COLOR_BLOCK = Pattern.compile("<((?:base|design|rim)ColorConfigurations)\\b[^>]*>.*?</\\1>", Pattern.DOTALL);
    private static final Pattern COLOR_NAME = Pattern.compile("(\\bcolor=\")([A-Za-z_][A-Za-z_0-9]*)(\")");

    /**
     * nodeMat — {вузол → матеріал} з i3d цієї техніки, colorDefs — кольори з modDesc (FS26 їх як ім'я не знає → RGB).
     * Слоти: <material name="kuzov" shaderParameter=…/> та вже перетворені <material materialSlotName="kuzov"/> → materialSlotName = ІМ'Я МАТЕРІАЛУ; дублі в блоці прибираються.
     */
    public static Result fixVehicleXml(String original, java.util.Map<String, String> nodeMat, java.util.Map<String, String> colorDefs) {
        String s = original;
        int n = 0;
        if (s.contains("<!-->")) {
            String a = s.replaceAll("<!-->[^\\n<]*<!-->", "");
            if (!a.equals(s)) { s = a; n++; }
            Pattern mp = Pattern.compile("[ \\t]*<!-->[^\\n]*?<!--.*?<!-->[ \\t]*\\r?\\n?", Pattern.DOTALL);
            if (mp.matcher(s).find()) { s = mp.matcher(s).replaceAll(""); n++; }
        }
        for (String tag : DROP_BLOCKS) {
            Pattern self = Pattern.compile("<" + tag + "(?=[\\s>/])[^>]*/>[ \\t]*\\r?\\n?");
            Pattern blk = Pattern.compile("<" + tag + "(?=[\\s>])[^>]*(?<!/)>.*?</" + tag + ">[ \\t]*\\r?\\n?", Pattern.DOTALL);
            n += countOf(self, s); s = self.matcher(s).replaceAll("");
            n += countOf(blk, s); s = blk.matcher(s).replaceAll("");
        }
        java.util.Set<String> matNames = nodeMat == null ? new java.util.HashSet<String>() : new java.util.HashSet<String>(nodeMat.values());
        for (Pattern sp : new Pattern[]{SLOT_FS22, SLOT_FS26}) {
            Matcher sm = sp.matcher(s);
            StringBuffer sb0 = new StringBuffer();
            while (sm.find()) {
                String x = sm.group(1);
                String y = resolveSlot(x, nodeMat);
                String rep = "<material materialSlotName=\"" + y + "\" />";
                if (!rep.equals(sm.group(0))) n++;
                sm.appendReplacement(sb0, Matcher.quoteReplacement(rep));
            }
            sm.appendTail(sb0);
            s = sb0.toString();
        }
        // дублі слотів у межах одного блоку *ColorConfigurations
        Matcher bm = COLOR_BLOCK.matcher(s);
        StringBuffer sb1 = new StringBuffer();
        while (bm.find()) {
            String blk = bm.group(0);
            java.util.Set<String> seen = new java.util.HashSet<String>();
            Matcher dm = SLOT_FS26.matcher(blk);
            StringBuffer sb2 = new StringBuffer();
            while (dm.find()) {
                boolean dup = !seen.add(dm.group(1));
                if (dup) n++;
                dm.appendReplacement(sb2, Matcher.quoteReplacement(dup ? "" : dm.group(0)));
            }
            dm.appendTail(sb2);
            bm.appendReplacement(sb1, Matcher.quoteReplacement(sb2.toString()));
        }
        bm.appendTail(sb1);
        s = sb1.toString();
        // кольори за іменем з modDesc → RGB (FS26: «Failed to parse parameter … vector 'gomselmash_RED'»)
        if (colorDefs != null && !colorDefs.isEmpty()) {
            Matcher cn = COLOR_NAME.matcher(s);
            StringBuffer sb3 = new StringBuffer();
            while (cn.find()) {
                String rgb = colorDefs.get(cn.group(2));
                if (rgb != null) { n++; cn.appendReplacement(sb3, Matcher.quoteReplacement(cn.group(1) + rgb + cn.group(3))); }
                else cn.appendReplacement(sb3, Matcher.quoteReplacement(cn.group(0)));
            }
            cn.appendTail(sb3);
            s = sb3.toString();
        }
        n += countOf(RENAME_CFG, s);
        s = RENAME_CFG.matcher(s).replaceAll("<$1$2Color$3Configuration$4");
        {   // FS22-залишок material="N" в елементах кольорів — в FS26 (зразок «Золотий Дон») його немає
            Pattern mp = Pattern.compile("(<(?:base|design|rim)ColorConfiguration\\b[^>]*?)\\s+material=\"\\d+\"");
            Matcher mq = mp.matcher(s);
            StringBuffer sb4 = new StringBuffer();
            while (mq.find()) { n++; mq.appendReplacement(sb4, Matcher.quoteReplacement(mq.group(1))); }
            mq.appendTail(sb4);
            s = sb4.toString();
        }
        Matcher cm = COLOR_CFG.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (cm.find()) {
            String attrs = cm.group(2);
            Matcher col = Pattern.compile("color=\"([^\"]*)\"").matcher(attrs);
            if (col.find()) {
                String[] v = col.group(1).trim().split("\\s+");
                if (v.length >= 4) { attrs = attrs.replace(col.group(0), "color=\"" + v[0] + " " + v[1] + " " + v[2] + "\""); n++; }
            }
            Matcher nm = Pattern.compile("name=\"\\$l10n_(\\w+)\"").matcher(attrs);
            StringBuffer sb2 = new StringBuffer();
            while (nm.find()) {
                String to = COLOR_NAMES.get(nm.group(1));
                nm.appendReplacement(sb2, Matcher.quoteReplacement(to != null ? "name=\"$l10n_ui_color" + to + "\"" : nm.group(0)));
                if (to != null) n++;
            }
            nm.appendTail(sb2);
            cm.appendReplacement(sb, Matcher.quoteReplacement("<" + cm.group(1) + sb2));
        }
        cm.appendTail(sb);
        s = sb.toString();
        Matcher rm = RIM_COLOR.matcher(s);
        sb = new StringBuffer();
        while (rm.find()) {
            String[] v = rm.group(2).trim().split("\\s+");
            String rep = rm.group(0);
            if (v.length >= 4) {
                rep = rm.group(1) + "color=\"" + v[0] + " " + v[1] + " " + v[2] + "\"";
                n++;
            }
            rm.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        rm.appendTail(sb);
        s = sb.toString();
        if (n == 0) return new Result(original, 0);
        if (wellFormed(original) && !wellFormed(s)) return new Result(original, 0);
        return new Result(s, n);
    }

    /** wheels/*.xml: прибрати isCareWheel, додати схему fs25/wheel.xsd. */
    public static Result fixWheelXml(String s) {
        if (!s.contains("isCareWheel")) return new Result(s, 0);
        String t = s.replaceAll("\\s+isCareWheel=\"[^\"]*\"", "");
        if (t.contains("<wheel>")) t = t.replaceFirst("<wheel>", Matcher.quoteReplacement("<wheel xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"https://validation.gdn.giants-software.com/xml/fs25/wheel.xsd\">"));
        return new Result(t, 1);
    }

    private static final Pattern CRAWLER_FILE = Pattern.compile("<file\\s+name=\"([^\"]+\\.i3d)\"");
    private static final Pattern SCROLL_LEN = Pattern.compile("scrollLength=\"([0-9.]+)\"");

    /** crawler-xml FS22: {ім'я i3d, scrollLength} або null. */
    public static String[] crawlerInfo(String xml) {
        if (!xml.contains("<crawler") || !xml.contains("scrollLength=")) return null;
        Matcher f = CRAWLER_FILE.matcher(xml), l = SCROLL_LEN.matcher(xml);
        if (!f.find() || !l.find()) return null;
        return new String[]{f.group(1), l.group(1)};
    }

    /** crawler-xml: shaderParameterName scrollPosition → scrollPos, scrollLength → 1 (у FS26 довжина йде в crawlerRealLength матеріалу). */
    public static Result fixCrawlerXml(String xml) {
        if (!xml.contains("<crawler") || !xml.contains("scrollPosition")) return new Result(xml, 0);
        String t = xml.replace("shaderParameterName=\"scrollPosition\"", "shaderParameterName=\"scrollPos\"");
        Matcher m = SCROLL_LEN.matcher(t);
        t = m.replaceAll("scrollLength=\"1\"");
        return new Result(t, 1);
    }

    private static final Pattern MOTOR_TEMPLATE = Pattern.compile("(<(?:motorStart|motorStop|motor)\\s+)template=\"DEFAULT_MOTOR_[A-Z_]*\"\\s+(?=[^>]*\\bfile=)");

    /**
     * Звук двигуна FS26 Mobile: motorStart / motorStop / motor (idle, offload, onload) з template="DEFAULT_MOTOR_…" І власним file= →
     * template прибирається, прямий файл лишається (зразок: CHTZ_T_170 → FIX_CHTZ_T_170). Інші елементи (gearbox, retarder, повітря…) не чіпаються.
     * Елементи без file= (чисто шаблонні) теж лишаються як є.
     */
    public static Result fixMotorSoundTemplates(String xml) {
        if (!xml.contains("DEFAULT_MOTOR_")) return new Result(xml, 0);
        Matcher m = MOTOR_TEMPLATE.matcher(xml);
        int n = 0;
        StringBuffer sb = new StringBuffer();
        while (m.find()) { n++; m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1))); }
        m.appendTail(sb);
        return n == 0 ? new Result(xml, 0) : new Result(sb.toString(), n);
    }

    // ============ Обов'язковий підпис DON-1500 (завжди, у всіх режимах) ============
    public static final String CREDIT = "DON-1500";

    /** modDesc.xml: author += ", converted by DON-1500"; у кожен мовний CDATA в <description> дописується «Converted with DON-1500 Converter»; XML-коментар-маркер. */
    public static Result addCredit(String xml) {
        if (xml == null || !xml.contains("<modDesc")) return new Result(xml, 0);
        if (xml.contains("Converted with " + CREDIT)) return new Result(xml, 0);
        String t = xml;
        int n = 0;
        Matcher am = Pattern.compile("<author>(.*?)</author>", Pattern.DOTALL).matcher(t);
        if (am.find()) {
            if (!am.group(1).contains(CREDIT)) {
                String a = am.group(1).trim();
                t = t.substring(0, am.start()) + "<author>" + (a.isEmpty() ? "" : a + ", ") + "converted by " + CREDIT + "</author>" + t.substring(am.end());
                n++;
            }
        } else {
            Matcher om = Pattern.compile("<modDesc\\b[^>]*>").matcher(t);
            if (om.find()) { t = t.substring(0, om.end()) + "\n    <author>converted by " + CREDIT + "</author>" + t.substring(om.end()); n++; }
        }
        Matcher dm = Pattern.compile("<description>(.*?)</description>", Pattern.DOTALL).matcher(t);
        if (dm.find()) {
            String block = dm.group(1);
            Matcher cd = Pattern.compile("(<!\\[CDATA\\[)(.*?)(\\]\\]>)", Pattern.DOTALL).matcher(block);
            StringBuffer sb = new StringBuffer();
            int c = 0;
            while (cd.find()) {
                c++;
                cd.appendReplacement(sb, Matcher.quoteReplacement(cd.group(1) + cd.group(2).replaceAll("\\s+$", "") + "\n\nConverted with " + CREDIT + " Converter" + cd.group(3)));
            }
            cd.appendTail(sb);
            if (c > 0) { t = t.substring(0, dm.start(1)) + sb + t.substring(dm.end(1)); n++; }
        }
        Matcher om2 = Pattern.compile("<modDesc\\b[^>]*>").matcher(t);
        if (om2.find()) { t = t.substring(0, om2.end()) + "\n    <!-- Converted with " + CREDIT + " Converter -->" + t.substring(om2.end()); n++; }
        return new Result(t, n);
    }

    // ============ Звуки FS26 Mobile: ПК-шаблони (досвід T-150: «Sound template … was not found») ============
    private static final Pattern PC_SOUND_ELEM = Pattern.compile("<(\\w+)\\s+template=\"(?:SWITCH_01|SWITCH_TURNLIGHT|ATTACH_01|defaultHydraulicSound|HONK_[A-Za-z0-9_]+)\"[^>]*?(?:/>|>.*?</\\1>)", Pattern.DOTALL);
    private static final Pattern MOTOR_BLOCK = Pattern.compile("<motor(\\s[^>]*?)template=\"DEFAULT_MOTOR_(IDLE|RUN|OFFLOAD_RUN|ONLOAD_RUN)\"([^>]*?)>(.*?)</motor>", Pattern.DOTALL);

    /** minRpm/maxRpm з першого <motor …> у xml техніки або null. */
    public static int[] motorRpm(String xml) {
        Matcher m = Pattern.compile("<motor\\s[^>]*?\\bminRpm=\"(\\d+)\"[^>]*?\\bmaxRpm=\"(\\d+)\"").matcher(xml);
        return m.find() ? new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2))} : null;
    }

    private static String mods(String type, int[][] pts) {
        StringBuilder b = new StringBuilder();
        for (int[] p : pts) b.append("<modifier type=\"").append(type).append("\" value=\"").append(p[0]).append("\" modifiedValue=\"").append(p[1] / 10.0).append("\"/>");
        return b.toString();
    }

    /**
     * Звук двигуна/сигналу/світла/зчіпки для FS26 Mobile (зразок T-150 → FIX_T150):
     * 1) регістр тегів motorstart/motorstop → motorStart/motorStop; 2) template=DEFAULT_MOTOR_* при наявності file= прибирається;
     * 3) якщо <motor> має <volume/> без modifier — додаються MOTOR_RPM (idle/run) і MOTOR_LOAD (onload) за minRpm/maxRpm;
     * 4) елементи з шаблонами SWITCH_01, SWITCH_TURNLIGHT, ATTACH_01, defaultHydraulicSound, HONK_* прибираються (мобільні назви невідомі), порожні обгортки теж.
     */
    public static Result fixMobileSounds(String xml, int minRpm, int maxRpm) {
        String t = xml;
        int n = 0;
        Matcher m = Pattern.compile("<(/?)motor(start|stop)\\b").matcher(t);
        StringBuffer sb = new StringBuffer();
        while (m.find()) { n++; m.appendReplacement(sb, "<" + m.group(1) + "motor" + Character.toUpperCase(m.group(2).charAt(0)) + m.group(2).substring(1)); }
        m.appendTail(sb);
        t = sb.toString();
        int lo = Math.max(1, minRpm), hi = Math.max(maxRpm, lo + 1);
        int idleMid = Math.max(800, lo + 100), idleHigh = Math.max(1000, lo + 300), runLow = Math.max(700, lo + 150), runMid = Math.max(1000, lo + 400);
        Matcher bm = MOTOR_BLOCK.matcher(t);
        sb = new StringBuffer();
        while (bm.find()) {
            String kind = bm.group(2), body = bm.group(4);
            Matcher vm = Pattern.compile("<volume\\s+([^>]*?)\\s*/>").matcher(body);
            if (body.contains("<modifier") || !vm.find()) { bm.appendReplacement(sb, Matcher.quoteReplacement(bm.group(0))); continue; }
            String vol, pitch;
            if (kind.equals("IDLE")) {
                vol = "<volume " + vm.group(1) + ">" + mods("MOTOR_RPM", new int[][]{{lo, 10}, {idleMid, 10}, {idleHigh, 0}}) + "</volume>";
                pitch = "<pitch indoor=\"1.0\" outdoor=\"1.0\">" + mods("MOTOR_RPM", new int[][]{{lo, 9}, {idleHigh, 11}}) + "</pitch>";
            } else if (kind.equals("ONLOAD_RUN")) {
                vol = "<volume " + vm.group(1) + "><modifier type=\"MOTOR_LOAD\" value=\"0.3\" modifiedValue=\"0.0\"/><modifier type=\"MOTOR_LOAD\" value=\"0.8\" modifiedValue=\"1.0\"/></volume>";
                pitch = "<pitch indoor=\"1.0\" outdoor=\"1.0\">" + mods("MOTOR_RPM", new int[][]{{runLow, 8}, {hi, 14}}) + "</pitch>";
            } else {
                vol = "<volume " + vm.group(1) + ">" + mods("MOTOR_RPM", new int[][]{{runLow, 0}, {runMid, 10}, {hi, 10}}) + "</volume>";
                pitch = "<pitch indoor=\"1.0\" outdoor=\"1.0\">" + mods("MOTOR_RPM", new int[][]{{runLow, 8}, {hi, 14}}) + "</pitch>";
            }
            String nb = body.substring(0, vm.start()) + vol + (body.contains("<pitch") ? "" : "\n            " + pitch) + body.substring(vm.end());
            n++;
            String head = bm.group(1).replaceAll("\\s+$", " ") + bm.group(3).replaceAll("^\\s+", "");
            bm.appendReplacement(sb, Matcher.quoteReplacement("<motor" + head + ">" + nb + "</motor>"));
        }
        bm.appendTail(sb);
        t = sb.toString();
        Result r = fixMotorSoundTemplates(t);
        t = r.text;
        n += r.count;
        Matcher pm = PC_SOUND_ELEM.matcher(t);
        int removed = 0;
        sb = new StringBuffer();
        while (pm.find()) { removed++; pm.appendReplacement(sb, ""); }
        pm.appendTail(sb);
        if (removed > 0) {
            t = sb.toString();
            n += removed;
            for (int k = 0; k < 3; k++) {
                t = t.replaceAll("<sounds>\\s*</sounds>[ \\t]*\\r?\\n?", "");
                t = t.replaceAll("<(lights|attacherJoints)>\\s*</\\1>[ \\t]*\\r?\\n?", "");
            }
        }
        return n == 0 ? new Result(xml, 0) : new Result(t, n);
    }
}
