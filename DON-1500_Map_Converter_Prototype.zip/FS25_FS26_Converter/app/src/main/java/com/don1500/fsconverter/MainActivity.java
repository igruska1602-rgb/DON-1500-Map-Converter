package com.don1500.fsconverter;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.Color;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final int PICK_ZIP = 101, SAVE_ZIP = 102;
    private Uri inputUri;
    private String inputName = "";
    private TextView status;
    private byte[] convertedZip;
    private String report = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,28,24,24); root.setBackgroundColor(Color.rgb(245,247,245));
        TextView title = new TextView(this); title.setText("FS25 → FS26 Mobile"); title.setTextSize(25); title.setTypeface(null, Typeface.BOLD); title.setTextColor(Color.rgb(23,61,36)); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Експериментальний конвертер модів техніки\nВибрати ZIP → перевірити → зберегти новий ZIP"); sub.setTextSize(16); sub.setPadding(0,12,0,20); root.addView(sub);
        Button choose = button("1. Вибрати мод FS25 (.zip)"); root.addView(choose); choose.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/zip"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_ZIP); });
        Button convert = button("2. Перевірити та підготувати для FS26"); root.addView(convert); convert.setOnClickListener(v -> runConvert());
        Button save = button("3. Зберегти результат ZIP"); root.addView(save); save.setOnClickListener(v -> { if(convertedZip==null){toast("Спочатку вибери ZIP і запусти перевірку");return;} Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/zip"); i.addCategory(Intent.CATEGORY_OPENABLE); i.putExtra(Intent.EXTRA_TITLE, safeBase(inputName)+"_FS26_experimental.zip"); startActivityForResult(i,SAVE_ZIP); });
        ScrollView sc = new ScrollView(this); status = new TextView(this); status.setTextSize(14); status.setTextColor(Color.DKGRAY); status.setPadding(0,20,0,0); status.setText("Готовий. Вибери ZIP-мод FS25.\n\nУвага: це рання експериментальна версія. Вона перевіряє структуру та виконує лише безпечні базові зміни XML. Вона не конвертує 3D-моделі, шейдери, фізику чи DDS-текстури автоматично."); sc.addView(status); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b; }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null||data.getData()==null)return; Uri u=data.getData(); if(req==PICK_ZIP){inputUri=u; inputName=getName(u); convertedZip=null; status.setText("Вибрано: "+inputName+"\nНатисни кнопку перевірки.");} else if(req==SAVE_ZIP && convertedZip!=null){try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(convertedZip);o.flush();status.append("\n\nЗбережено: "+getName(u)+"\n"+report);toast("ZIP збережено");}catch(Exception e){toast("Помилка збереження: "+e.getMessage());}} }
    private String getName(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)return c.getString(x);}}catch(Exception ignored){} return "mod.zip";}
    private String safeBase(String n){int i=n.toLowerCase().lastIndexOf(".zip");return i>0?n.substring(0,i):n;}

    private void runConvert(){ if(inputUri==null){toast("Спочатку вибери ZIP");return;} status.setText("Перевіряю архів…"); new Thread(()->{try{Map<String,byte[]> files=new LinkedHashMap<>(); List<String> notes=new ArrayList<>(); int count=0; long total=0;
        try(InputStream raw=getContentResolver().openInputStream(inputUri); ZipInputStream zin=new ZipInputStream(new BufferedInputStream(raw))){ZipEntry e; byte[] buf=new byte[65536]; while((e=zin.getNextEntry())!=null){if(e.isDirectory()){files.put(e.getName(),new byte[0]);continue;} ByteArrayOutputStream out=new ByteArrayOutputStream(); int n; while((n=zin.read(buf))>0){out.write(buf,0,n); total+=n; if(total>900L*1024*1024)throw new IOException("Архів після розпакування завеликий (>900 MB)");} files.put(e.getName(),out.toByteArray());count++;}}
        if(!files.containsKey("modDesc.xml")) notes.add("ПОМИЛКА: у корені архіву не знайдено modDesc.xml. Це може бути не ZIP-мод FS25.");
        else {String xml=new String(files.get("modDesc.xml"),java.nio.charset.StandardCharsets.UTF_8); String before=xml;
          // Only change the version marker when the source uses the known FS25-style descriptor.
          if(xml.matches("(?s).*<modDesc\\b[^>]*descVersion=\"[0-9]+\"[^>]*>.*") && !xml.contains("titleId=\"fs26mobile\"")){
            xml=xml.replaceFirst("<modDesc\\b([^>]*)descVersion=\"[0-9]+\"([^>]*)>","<modDesc$1descVersion=\"2\"$2 titleId=\"fs26mobile\">");
            notes.add("modDesc.xml: змінено заголовок версії на формат з твого прикладу FS26 Mobile (descVersion=2, titleId=fs26mobile).");
          } else notes.add("modDesc.xml: версію не змінено автоматично — формат не збігається з відомим зразком або вже має FS26 titleId.");
          if(!xml.equals(before)) files.put("modDesc.xml",xml.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        int xmlCount=0, badXml=0; for(Map.Entry<String,byte[]> ent:files.entrySet()){if(ent.getKey().toLowerCase().endsWith(".xml")){xmlCount++;try{DocumentBuilderFactory f=DocumentBuilderFactory.newInstance(); f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true); f.setFeature("http://xml.org/sax/features/external-general-entities",false); f.newDocumentBuilder().parse(new ByteArrayInputStream(ent.getValue()));}catch(Exception ex){badXml++;notes.add("XML не пройшов перевірку: "+ent.getKey());}}}
        notes.add("Файлів у ZIP: "+count+"; XML-файлів: "+xmlCount+"; XML з помилками читання: "+badXml+".");
        notes.add("НЕ виконано автоматично: конвертація DDS у PNG, оновлення шейдерів, i3d/shapes, скриптів і фізики. Ці зміни потрібні для повної сумісності з FS26 Mobile.");
        ByteArrayOutputStream bout=new ByteArrayOutputStream(); try(ZipOutputStream zout=new ZipOutputStream(new BufferedOutputStream(bout))){for(Map.Entry<String,byte[]> ent:files.entrySet()){ZipEntry ze=new ZipEntry(ent.getKey()); zout.putNextEntry(ze); if(!ent.getKey().endsWith("/")&&ent.getValue().length>0)zout.write(ent.getValue()); zout.closeEntry();} zout.putNextEntry(new ZipEntry("FS26_CONVERTER_REPORT.txt")); StringBuilder sb=new StringBuilder("FS25 → FS26 Mobile Converter — experimental report\n\nInput: "+inputName+"\n\n");for(String s:notes)sb.append("- ").append(s).append('\n');sb.append("\nThis is not a guarantee that the mod will run in FS26 Mobile. Keep the original ZIP.");zout.write(sb.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));zout.closeEntry();}
        convertedZip=bout.toByteArray(); report=String.join("\n",notes); runOnUiThread(()->status.setText("Перевірку завершено. Результат ще не збережено.\n\n"+report+"\n\nНатисни «Зберегти результат ZIP»."));
      }catch(Exception ex){runOnUiThread(()->status.setText("Не вдалося обробити ZIP: "+ex.getMessage()+"\n\nОригінальний файл не змінено."));}}).start(); }
}
