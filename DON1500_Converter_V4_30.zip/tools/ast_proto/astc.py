import struct
LIB=open('/mnt/user-data/uploads/libgame.so','rb').read()
def T(va,n): return list(LIB[va:va+n])
DQ_TRIT={1:T(0x49d8c0,6),2:T(0x49d8d0,12),3:T(0x49d8f0,24),4:T(0x49d930,48),5:T(0x49d9b0,96),6:T(0x49dab0,192)}
DQ_QUINT={1:T(0x49d8c6,10),2:T(0x49d8dc,20),3:T(0x49d908,40),4:T(0x49d960,80),5:T(0x49da10,160)}
CEM_NUMVALS=T(0x49a4c0,16); CEM_ALPHA=T(0x49a4d0,16); CEM_HDR=T(0x49a4b0,16)
# color ranges: (levels, nbits, trit?, quint?)
RANGES=[(2,1,0,0),(3,0,1,0),(4,2,0,0),(5,0,0,1),(6,1,1,0),(8,3,0,0),(10,1,0,1),(12,2,1,0),(16,4,0,0),(20,2,0,1),(24,3,1,0),(32,5,0,0),(40,3,0,1),(48,4,1,0),(64,6,0,0),(80,4,0,1),(96,5,1,0),(128,7,0,0),(192,6,1,0),(256,8,0,0)]
def ise_bits(n,r):
    lv,b,t,q=RANGES[r]
    return n*b+((8*n+4)//5 if t else 0)+((7*n+2)//3 if q else 0)
def trit_decode(Tb):
    b=lambda i:(Tb>>i)&1
    if (Tb>>2)&7==7:
        C=(((Tb>>5)&7)<<2)|(Tb&3); t4=2; t3=2
    else:
        C=Tb&31
        if (Tb>>5)&3==3: t4=2; t3=(Tb>>7)&1
        else: t4=(Tb>>7)&1; t3=(Tb>>5)&3
    if C&3==3:
        t2=2; t1=(C>>4)&1; t0=(((C>>3)&1)<<1)|(((C>>2)&1)&(~(C>>3)&1))
    elif (C>>2)&3==3:
        t2=2;t1=2;t0=C&3
    else:
        t2=(C>>4)&1; t1=(C>>2)&3; t0=(((C>>1)&1)<<1)|((C&1)&(~(C>>1)&1))
    return [t0,t1,t2,t3,t4]
def quint_decode(Q):
    g=lambda i:(Q>>i)&1
    if (Q>>1)&3==3 and (Q>>5)&3==0:
        q2=(g(0)<<2)|(((g(4))&(1-g(0)))<<1)|(g(3)&(1-g(0))); q1=q0=4
    else:
        if (Q>>1)&3==3:
            q2=4; C=(((Q>>3)&3)<<3)|((((~(Q>>5))&3))<<1)|g(0)
        else:
            q2=(Q>>5)&3; C=Q&31
        if C&7==5: q1=4; q0=(C>>3)&3
        else: q1=(C>>3)&3; q0=C&7
    return [q0,q1,q2]
class Bits:
    def __init__(s,data): s.v=int.from_bytes(data,'little')
    def get(s,pos,n): return (s.v>>pos)&((1<<n)-1) if n>0 else 0
def ise_decode(val,start,count,r):
    """val: int of bitstream; returns list of (index into dequant) values"""
    lv,nb,tr,qu=RANGES[r]
    total=ise_bits(count,r)
    mask=(1<<total)-1
    v=(val>>start)&mask
    out=[]
    pos=0
    def rd(n):
        nonlocal pos
        x=(v>>pos)&((1<<n)-1); pos+=n; return x
    if tr:
        i=0
        while i<count:
            m=[0]*5; Tb=0
            m[0]=rd(nb); Tb|=rd(2)
            m[1]=rd(nb); Tb|=rd(2)<<2
            m[2]=rd(nb); Tb|=rd(1)<<4
            m[3]=rd(nb); Tb|=rd(2)<<5
            m[4]=rd(nb); Tb|=rd(1)<<7
            ts=trit_decode(Tb)
            for k in range(5):
                if i<count: out.append((ts[k],m[k]))
                i+=1
    elif qu:
        i=0
        while i<count:
            m=[0]*3; Q=0
            m[0]=rd(nb); Q|=rd(3)
            m[1]=rd(nb); Q|=rd(2)<<3
            m[2]=rd(nb); Q|=rd(2)<<5
            qs=quint_decode(Q)
            for k in range(3):
                if i<count: out.append((qs[k],m[k]))
                i+=1
    else:
        for i in range(count): out.append((0,rd(nb)))
    return out
def unq_color(r,tm):
    lv,nb,tr,qu=RANGES[r]
    t,m=tm
    if tr:
        if nb==0: return [0,128,255][t]
        return DQ_TRIT[nb][t*(1<<nb)+m]
    if qu:
        if nb==0: return [0,64,128,191,255][t]
        return DQ_QUINT[nb][t*(1<<nb)+m]
    # bits only: replicate
    v=m; n=nb
    out=0; sh=8
    while sh>0:
        sh-=n
        out|= (v<<sh) if sh>=0 else (v>>(-sh))
    return out&255
def unq_weight(r,tm):
    lv,nb,tr,qu=RANGES[r]
    t,m=tm
    if not tr and not qu:
        # replicate to 6 bits
        v=m; n=nb; out=0; sh=6
        while sh>0:
            sh-=n
            out|=(v<<sh) if sh>=0 else (v>>(-sh))
        out&=63
        return out+1 if out>32 else out
    if nb==0:
        return (t*32 if tr else t*16)
    a=m&1
    A=0x7F if a else 0
    if tr:
        D=t
        if nb==1: C=50;B=0
        elif nb==2:
            b=(m>>1)&1; C=23; B=(b<<6)|(b<<2)|b
        elif nb==3:
            b=(m>>1)&1;c=(m>>2)&1; C=11; B=(c<<6)|(b<<5)|(c<<1)|b
        else: raise
    else:
        D=t
        if nb==1: C=28;B=0
        elif nb==2:
            b=(m>>1)&1; C=13; B=(b<<6)|(b<<1)
        else: raise
    X=D*C+B
    X^=A
    X=(A&0x20)|(X>>2)
    return X+1 if X>32 else X
def hash52(p):
    M=0xFFFFFFFF
    p^=p>>15; p=(p-(p<<17))&M; p=(p+(p<<7))&M; p=(p+(p<<4))&M
    p^=p>>5; p=(p+(p<<16))&M; p^=p>>7; p^=p>>3
    p=(p^(p<<6))&M; p^=p>>17
    return p
def select_partition(seed,x,y,pc,small):
    if small: x<<=1;y<<=1
    seed+=(pc-1)*1024
    r=hash52(seed)
    s=[ (r>>0)&15,(r>>4)&15,(r>>8)&15,(r>>12)&15,(r>>16)&15,(r>>20)&15,(r>>24)&15,(r>>28)&15,(r>>18)&15,(r>>22)&15,(r>>26)&15,((r>>30)|(r<<2))&15]
    s=[v*v for v in s]
    if seed&1:
        sh1=4 if seed&2 else 5; sh2=6 if pc==3 else 5
    else:
        sh1=6 if pc==3 else 5; sh2=4 if seed&2 else 5
    sh3=sh1 if seed&0x10 else sh2
    s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12=s
    s1>>=sh1;s2>>=sh2;s3>>=sh1;s4>>=sh2;s5>>=sh1;s6>>=sh2;s7>>=sh1;s8>>=sh2
    s9>>=sh3;s10>>=sh3;s11>>=sh3;s12>>=sh3
    a=(s1*x+s2*y+(r>>14))&63
    b=(s3*x+s4*y+(r>>10))&63
    c=(s5*x+s6*y+(r>>6))&63
    d=(s7*x+s8*y+(r>>2))&63
    if pc<4:d=0
    if pc<3:c=0
    if a>=b and a>=c and a>=d:return 0
    if b>=c and b>=d:return 1
    if c>=d:return 2
    return 3
def decode_block_mode(bm):
    base=(bm>>4)&1; H=(bm>>9)&1; D=(bm>>10)&1; A=(bm>>5)&3
    if bm&3:
        base|=(bm&3)<<1
        B=(bm>>7)&3
        k=(bm>>2)&3
        if k==0: xw=B+4;yw=A+2
        elif k==1: xw=B+8;yw=A+2
        elif k==2: xw=A+2;yw=B+8
        else:
            B&=1
            if bm&0x100: xw=B+2;yw=A+2
            else: xw=A+2;yw=B+6
    else:
        base|=((bm>>2)&3)<<1
        if (bm>>2)&3==0: return None
        B=(bm>>9)&3
        k=(bm>>7)&3
        if k==0: xw=12;yw=A+2
        elif k==1: xw=A+2;yw=12
        elif k==2: xw=A+6;yw=B+6;D=0;H=0
        else:
            kk=(bm>>5)&3
            if kk==0: xw=6;yw=10
            elif kk==1: xw=10;yw=6
            else: return None
    qm=(base-2)+6*H
    if base<2: return None
    # weight ranges list index
    WR=[0,1,2,3,4,5,6,7,8,9,10,11]  # indices into RANGES: 2,3,4,5,6,8,10,12,16,20,24,32
    return xw,yw,D,WR[qm] if qm<12 else None
def decode_block(blk,bw,bh,out,ox,oy,W,H):
    v=int.from_bytes(blk,'little')
    g=lambda p,n:(v>>p)&((1<<n)-1)
    bm=g(0,11)
    if bm&0x1FF==0x1FC:
        # void extent
        r=g(64,16);gg=g(80,16);b=g(96,16);a=g(112,16)
        col=(r>>8,gg>>8,b>>8,a>>8)
        for y in range(bh):
            for x in range(bw):
                if ox+x<W and oy+y<H: out[(oy+y)*W+ox+x]=col
        return 'void'
    mi=decode_block_mode(bm)
    if mi is None:
        for y in range(bh):
            for x in range(bw):
                if ox+x<W and oy+y<H: out[(oy+y)*W+ox+x]=(255,0,255,255)
        return 'err'
    xw,yw,D,wr=mi
    nw=xw*yw*(2 if D else 1)
    wbits=ise_bits(nw,wr)
    pc=g(11,2)+1
    if wbits>96 or wbits<24 or nw>64: 
        for y in range(bh):
            for x in range(bw):
                if ox+x<W and oy+y<H: out[(oy+y)*W+ox+x]=(255,0,255,255)
        return 'err'
    if pc==1:
        cem0=g(13,4); cems=[cem0]; cstart=17; hp=0
        pidx=0
    else:
        pidx=g(13,10)
        hp=3*pc-4
        below=128-wbits-hp
        et=g(23,6)|(g(below,hp)<<6)
        base=et&3
        if base==0:
            cems=[(et>>2)&15]*pc; hp=0
        else:
            cems=[]
            for i in range(pc):
                c=(et>>(2+i))&1
                m=(et>>(2+pc+2*i))&3
                cems.append(((base-1+c)<<2)|m)
        cstart=29
    dp_bits=2 if D else 0
    nvals=sum(CEM_NUMVALS[c] for c in cems)
    avail=128-wbits-hp-dp_bits-cstart
    qr=None
    for r in range(19,-1,-1):
        if ise_bits(nvals,r)<=avail: qr=r;break
    if qr is None or nvals>18 or qr<4 and False:
        return 'err'
    cvals=[unq_color(qr,tm) for tm in ise_decode(v,cstart,nvals,qr)]
    # endpoints
    eps=[];k=0
    for c in cems:
        n=CEM_NUMVALS[c]; vs=cvals[k:k+n];k+=n
        eps.append(decode_cem(c,vs))
    # weights: reversed
    rev=int(format(v,'0128b')[::-1],2)  # bit reversal
    wl=ise_decode(rev,0,nw,wr)
    ws=[unq_weight(wr,tm) for tm in wl]
    plane2=g(128-wbits-hp-2,2) if D else 0
    if D:
        w1=ws[0::2]; w2=ws[1::2]
    else: w1=ws; w2=None
    # infill
    Ds=(1024+bw//2)//(bw-1); Dt=(1024+bh//2)//(bh-1)
    def infill(w):
        res=[0]*(bw*bh)
        for y in range(bh):
            for x in range(bw):
                gs=((Ds*x)*(xw-1)+32)>>6; gt=((Dt*y)*(yw-1)+32)>>6
                js=gs>>4;fs=gs&15;jt=gt>>4;ft=gt&15
                v0=js+jt*xw
                w11=(fs*ft+8)>>4; w10=ft-w11; w01=fs-w11; w00=16-fs-ft+w11
                p00=w[v0]
                p01=w[v0+1] if fs or js+1<xw else w[v0]
                p10=w[v0+xw] if ft or jt+1<yw else w[v0]
                p11=w[v0+xw+1] if (fs and ft) else (w[min(v0+xw+1,len(w)-1)])
                res[y*bw+x]=(p00*w00+p01*w01+p10*w10+p11*w11+8)>>4
        return res
    f1=infill(w1); f2=infill(w2) if D else None
    for y in range(bh):
        for x in range(bw):
            if ox+x>=W or oy+y>=H: continue
            p=0 if pc==1 else select_partition(pidx,x,y,pc,bw*bh<31)
            e0,e1=eps[p]
            col=[]
            for ch in range(4):
                w=f1[y*bw+x]
                if D and ch==plane2: w=f2[y*bw+x]
                c0=(e0[ch]<<8)|e0[ch]; c1=(e1[ch]<<8)|e1[ch]
                col.append(((c0*(64-w)+c1*w+32)>>6)>>8)
            out[(oy+y)*W+ox+x]=tuple(col)
    return 'ok'
def bt(a,b):
    # bit transfer
    b>>=1 if False else 0
    return a,b
def clamp(x): return 0 if x<0 else 255 if x>255 else x
def bit_transfer(a,b):
    b=(b>>1)|(a&0x80); a=(a>>1)&0x3F
    if a&0x20: a-=0x40
    return a,b
def decode_cem(c,v):
    if c==0: return (v[0],v[0],v[0],255),(v[1],v[1],v[1],255)
    if c==1:
        l0=(v[0]>>2)|(v[1]&0xC0); l1=min(255,l0+(v[1]&0x3F)); return (l0,l0,l0,255),(l1,l1,l1,255)
    if c==4: return (v[0],v[0],v[0],v[2]),(v[1],v[1],v[1],v[3])
    if c==5:
        a=bit_transfer(v[1],v[0]); a0=v[0]
        x1,y1=bit_transfer(v[1],v[0]); x3,y3=bit_transfer(v[3],v[2])
        l0=y1; l1=clamp(y1+x1); a0_=y3; a1_=clamp(y3+x3)
        return (l0,l0,l0,a0_),(l1,l1,l1,a1_)
    if c==6:
        return (v[0]*v[3]>>8,v[1]*v[3]>>8,v[2]*v[3]>>8,255),(v[0],v[1],v[2],255)
    if c==8:
        s0=v[0]+v[2]+v[4]; s1=v[1]+v[3]+v[5]
        if s1>=s0: return (v[0],v[2],v[4],255),(v[1],v[3],v[5],255)
        return ((v[1]+v[5])>>1,(v[3]+v[5])>>1,v[5],255),((v[0]+v[4])>>1,(v[2]+v[4])>>1,v[4],255)
    if c==9 or c==13:
        x0,y0=bit_transfer(v[1],v[0]); x1,y1=bit_transfer(v[3],v[2]); x2,y2=bit_transfer(v[5],v[4])
        e0=[y0,y1,y2,255]; e1=[clamp(y0+x0),clamp(y1+x1),clamp(y2+x2),255]
        if c==13:
            xa,ya=bit_transfer(v[7],v[6]); e0[3]=ya; e1[3]=clamp(ya+xa)
        if x0+x1+x2<0:
            bc=lambda e:[(e[0]+e[2])>>1,(e[1]+e[2])>>1,e[2],e[3]]
            e0,e1=bc(e1),bc(e0)
        return tuple(e0),tuple(e1)
    if c==10:
        e0,e1=decode_cem(6,v[:4]); return (e0[0],e0[1],e0[2],v[4]),(e1[0],e1[1],e1[2],v[5])
    if c==12:
        s0=v[0]+v[2]+v[4]; s1=v[1]+v[3]+v[5]
        if s1>=s0: return (v[0],v[2],v[4],v[6]),(v[1],v[3],v[5],v[7])
        return ((v[1]+v[5])>>1,(v[3]+v[5])>>1,v[5],v[7]),((v[0]+v[4])>>1,(v[2]+v[4])>>1,v[4],v[6])
    return (255,0,255,255),(255,0,255,255)
