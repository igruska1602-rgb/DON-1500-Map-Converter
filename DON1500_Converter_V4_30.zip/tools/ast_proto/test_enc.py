import numpy as np,time
from enc import *
from PIL import Image
im=np.array(Image.open('/home/claude/t/222/1.1.png').convert('RGBA'))[300:300+126,300:300+126]
H,W=im.shape[:2]; bx=W//6; by=H//6
out=[None]*(W*H); t=time.time()
for j in range(by):
    for i in range(bx):
        blk=im[j*6:j*6+6,i*6:i*6+6].reshape(36,4)
        b=encode_block(blk)
        decode_block(b,6,6,out,i*6,j*6,W,H)
print('time',time.time()-t)
arr=np.array(out,dtype=float).reshape(H,W,4)
mse=((arr[:,:,:3]-im[:,:,:3])**2).mean(); print('PSNR',10*np.log10(255**2/mse))
Image.fromarray(np.hstack([im[:,:,:3],arr[:,:,:3].astype(np.uint8)])).resize((W*6,H*3),Image.NEAREST).save('enc_cmp.png')
