import com.don1500.converter.*;
import java.io.*; import java.nio.file.*; import javax.imageio.ImageIO; import java.awt.image.BufferedImage;
public class AstSelfTest {
  static double psnr(int[] a,int[] b){double se=0;for(int i=0;i<a.length;i++)for(int s=0;s<24;s+=8){int d=((a[i]>>s)&255)-((b[i]>>s)&255);se+=d*d;}return 10*Math.log10(255.0*255/(se/(a.length*3.0)));}
  public static void main(String[] x) throws Exception {
    // 1) читання справжнього файлу: заголовок і розклад
    for (String n : new String[]{"1.1","1.2","1.4","1"}) {
      byte[] d=Files.readAllBytes(Paths.get("/home/claude/t/222/"+n+".ast"));
      System.out.println(n+" probe="+Gs2d.probe(d));
    }
    byte[] d=Files.readAllBytes(Paths.get("/home/claude/t/222/1.1.ast"));
    Gs2d.Img a=Gs2d.decode(d,0);
    BufferedImage r=ImageIO.read(new File("/home/claude/t/222/1.1.png"));
    int[] rp=new int[1024*1024]; r.getRGB(0,0,1024,1024,rp,0,1024); for(int i=0;i<rp.length;i++)rp[i]|=0xFF000000;
    System.out.println("game AST vs PNG (upright) PSNR "+psnr(a.px,rp));
    Gs2d.Img sm=Gs2d.decode(d,256); System.out.println("maxDim 256 -> "+sm.w+"x"+sm.h);
    // 2) наше кодування PNG->AST
    long t=System.currentTimeMillis();
    byte[] mine=Gs2d.encode(rp,1024,1024,null);
    System.out.println("encode 1024: "+(System.currentTimeMillis()-t)+" ms, size "+mine.length+" (game "+d.length+") probe="+Gs2d.probe(mine));
    Gs2d.Img b=Gs2d.decode(mine,0); System.out.println("my AST vs PNG PSNR "+psnr(b.px,rp));
    System.out.println("header mine: "+java.util.HexFormat.of().formatHex(mine,0,52));
    System.out.println("header game: "+java.util.HexFormat.of().formatHex(d,0,52));
    Files.write(Paths.get("/home/claude/jv/mine_1024.ast"),mine);
    // 3) неквадратна і непарна
    int W=2048,H=1834; int[] big=new int[W*H]; for(int y=0;y<H;y++)for(int xx=0;xx<W;xx++)big[y*W+xx]=0xFF000000|((xx*255/W)<<16)|((y*255/H)<<8)|((xx^y)&255);
    t=System.currentTimeMillis(); byte[] m2=Gs2d.encode(big,W,H,null); System.out.println("2048x1834 enc "+(System.currentTimeMillis()-t)+"ms size "+m2.length+" (game 1.ast 2235060) probe="+Gs2d.probe(m2));
    System.out.println("size equal to game's 1.ast: "+(m2.length==2235060));
    // 4) альфа
    int[] al=new int[64*64]; for(int i=0;i<al.length;i++)al[i]=((i%64)*4<<24)|0x336699+(i%7);
    Gs2d.Img c=Gs2d.decode(Gs2d.encode(al,64,64,null),0); double e=0;for(int i=0;i<al.length;i++)e+=Math.abs((al[i]>>>24)-(c.px[i]>>>24)); System.out.println("alpha mean abs err "+e/al.length);
  }
}
