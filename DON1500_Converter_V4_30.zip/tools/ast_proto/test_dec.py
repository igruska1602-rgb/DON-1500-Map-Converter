import sys,time,struct,collections
from astc import *
from PIL import Image
import numpy as np
def levels(w,h,bs=6):
    L=[]
    while True:
        L.append((w,h,((w+bs-1)//bs),((h+bs-1)//bs)))
        if w==1 and h==1:break
        w=max(1,w//2);h=max(1,h//2)
    return L
f=sys.argv[1]; png=sys.argv[2]; order=sys.argv[3]; lvl=int(sys.argv[4])
d=open(f,'rb').read()
W,H=struct.unpack_from('<II',d,8)
L=levels(W,H)
offs=[];o=52
seq=L if order=='big' else L[::-1]
pos={}
for l in seq:
    pos[l[:2]]=o; o+=l[2]*l[3]*16
print('end',o,len(d))
w,h,bx,by=L[lvl]
base=pos[(w,h)]
print('decoding level',lvl,w,h,'at',base)
out=[None]*(w*h)
stats=collections.Counter()
t=time.time()
# decode only a crop for speed: top-left 60x60 blocks max
for j in range(by):
    for i in range(bx):
        blk=d[base+(j*bx+i)*16: base+(j*bx+i)*16+16]
        stats[decode_block(blk,6,6,out,i*6,j*6,w,h)]+=1
print(stats,time.time()-t)
arr=np.array([c if c else (0,0,0,0) for c in out],dtype=np.uint8).reshape(h,w,4)[::-1].copy()
ref=Image.open(png).convert('RGBA')
if ref.size!=(w,h): ref=ref.resize((w,h),Image.BOX)
r=np.array(ref).astype(float)
mse=((arr[:,:,:3].astype(float)-r[:,:,:3])**2).mean()
print('PSNR',10*np.log10(255*255/max(mse,1e-9)))
Image.fromarray(arr[:,:,:3]).save('dec_%d.png'%lvl)
