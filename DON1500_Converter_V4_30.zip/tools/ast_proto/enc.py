import numpy as np, itertools
from astc import *
# ---- ISE encode helpers
TRIT_ENC={}
for Tb in range(256):
    ts=tuple(trit_decode(Tb))
    if all(t<3 for t in ts) and ts not in TRIT_ENC: TRIT_ENC[ts]=Tb
QUINT_ENC={}
for Q in range(128):
    qs=tuple(quint_decode(Q))
    if all(q<5 for q in qs) and qs not in QUINT_ENC: QUINT_ENC[qs]=Q
assert len(TRIT_ENC)==243 and len(QUINT_ENC)==125,(len(TRIT_ENC),len(QUINT_ENC))
def ise_encode(vals,r):
    """vals: list of (t,m) pairs; returns int bitstream (LSB first)"""
    lv,nb,tr,qu=RANGES[r]
    out=0;pos=0
    def wr(x,n):
        nonlocal out,pos
        out|=(x&((1<<n)-1))<<pos; pos+=n
    if tr:
        for i in range(0,len(vals),5):
            g=vals[i:i+5]+[(0,0)]*(5-len(vals[i:i+5]))
            Tb=TRIT_ENC[tuple(t for t,m in g)]
            wr(g[0][1],nb); wr(Tb&3,2)
            wr(g[1][1],nb); wr((Tb>>2)&3,2)
            wr(g[2][1],nb); wr((Tb>>4)&1,1)
            wr(g[3][1],nb); wr((Tb>>5)&3,2)
            wr(g[4][1],nb); wr((Tb>>7)&1,1)
    elif qu:
        for i in range(0,len(vals),3):
            g=vals[i:i+3]+[(0,0)]*(3-len(vals[i:i+3]))
            Q=QUINT_ENC[tuple(t for t,m in g)]
            wr(g[0][1],nb); wr(Q&7,3)
            wr(g[1][1],nb); wr((Q>>3)&3,2)
            wr(g[2][1],nb); wr((Q>>5)&3,2)
    else:
        for t,m in vals: wr(m,nb)
    total=ise_bits(len(vals),r)
    return out&((1<<total)-1)
def level_table(r,weights=False):
    """sorted list of (unq_value, (t,m)) for all transmitted values in range r"""
    lv,nb,tr,qu=RANGES[r]
    pairs=[]
    if tr:
        for t in range(3):
            for m in range(1<<nb): pairs.append((t,m))
    elif qu:
        for t in range(5):
            for m in range(1<<nb): pairs.append((t,m))
    else:
        for m in range(1<<nb): pairs.append((0,m))
    f=unq_weight if weights else unq_color
    lst=sorted(((f(r,p),p) for p in pairs),key=lambda x:x[0])
    return lst
CT={r:level_table(r) for r in range(20)}
WT={r:level_table(r,True) for r in range(4)}   # 2,3,4,5 levels (r idx 0..3) etc
WT[2]=level_table(2,True); WT[3]=level_table(3,True)
def quant_color(r,x):
    lst=CT[r]; vals=np.array([v for v,p in lst])
    k=int(np.argmin(np.abs(vals-x)))
    return lst[k]
# ---- block encode
def bm_for(rw):  # 6x6 grid weights, weight range index rw (2:4 levels, 3:5 levels)
    base=rw+2
    return (1<<8)|(((base>>1)&3)<<2)|((base&1)<<4)
def best_cr(ncv,avail):
    for r in range(19,-1,-1):
        if ise_bits(ncv,r)<=avail: return r
def endpoints_pca(px,has_a):
    n=px.shape[1]
    mean=px.mean(0)
    c=px-mean
    cov=c.T@c
    w,v=np.linalg.eigh(cov)
    ax=v[:,-1]
    t=c@ax
    lo=mean+ax*t.min(); hi=mean+ax*t.max()
    return lo,hi
def encode_candidate(px,rw,alpha):
    """px: (36,4) float. returns (block int, sse)"""
    ncv=8 if alpha else 6
    cem=12 if alpha else 8
    wr_bits=ise_bits(36,rw)
    avail=128-wr_bits-17
    cr=best_cr(ncv,avail)
    if cr is None or cr<2: return None
    nl=[4,5][rw-2]
    wvals=[v for v,p in WT[rw]]  # ascending unq weights
    wmap=[p for v,p in WT[rw]]
    ch=4 if alpha else 3
    P=px[:,:ch]
    lo,hi=endpoints_pca(P,alpha)
    best=None
    for it in range(3):
        lo=np.clip(lo,0,255);hi=np.clip(hi,0,255)
        # quantize endpoints
        q0=[quant_color(cr,x) for x in lo]; q1=[quant_color(cr,x) for x in hi]
        e0=np.array([a for a,b in q0],float); e1=np.array([a for a,b in q1],float)
        # cem8/12 direct requires sum(e1)>=sum(e0) (rgb only)
        if e1[:3].sum()<e0[:3].sum():
            q0,q1=q1,q0; e0,e1=e1,e0
        # weights
        d=e1-e0; dd=(d*d).sum()
        wi=np.zeros(36,int)
        W=np.array(wvals)/64.0
        for i in range(36):
            # nearest weight level by actual interpolation error
            cand=e0[None,:]+W[:,None]*d[None,:]
            err=((cand-P[i])**2).sum(1)
            wi[i]=int(np.argmin(err))
        wv=W[wi]
        rec=e0[None,:]+wv[:,None]*d[None,:]
        sse=((rec-P)**2).sum()
        if best is None or sse<best[0]:
            best=(sse,q0,q1,wi.copy())
        # least squares refinement of endpoints given weights
        A=np.stack([1-wv,wv],1)
        if np.linalg.matrix_rank(A)<2: break
        sol,_,_,_=np.linalg.lstsq(A,P,rcond=None)
        lo,hi=sol[0],sol[1]
    sse,q0,q1,wi=best
    # assemble values: v0,v1 (r), v2,v3 (g), v4,v5 (b), [v6,v7 (a)]
    vals=[]
    for c in range(ch):
        vals.append(q0[c][1]); vals.append(q1[c][1])
    cbits=ise_encode(vals,cr)
    wbits=ise_encode([wmap[k] for k in wi],rw)
    v=bm_for(rw)|(cem<<13)|(cbits<<17)
    # reversed weights at top
    for i in range(wr_bits):
        if (wbits>>i)&1: v|=1<<(127-i)
    return v,sse
def encode_block(px):
    """px (36,4) uint8-ish float array, row-major 6x6"""
    px=px.astype(float)
    if (px==px[0]).all():
        c=(px[0]*257).astype(int)
        v=0x1FC|(1<<9)*0   # void extent LDR, bit9=0
        v|=((1<<12)-1)<<12 | ((1<<12)-1)<<24 | ((1<<12)-1)<<36 | ((1<<12)-1)<<48
        v|=int(c[0])<<64|int(c[1])<<80|int(c[2])<<96|int(c[3])<<112
        return v.to_bytes(16,'little')
    alpha=not (px[:,3]==255).all()
    best=None
    for rw in ((2,) if alpha else (2,3)):
        r=encode_candidate(px,rw,alpha)
        if r and (best is None or r[1]<best[1]): best=r
    return best[0].to_bytes(16,'little')
