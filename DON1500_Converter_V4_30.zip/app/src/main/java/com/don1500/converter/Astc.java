package com.don1500.converter;

/**
 * ASTC LDR 2D: повний декодер (будь-які режими блоків, розділи, подвійна площина) та простий кодувальник блоків 6x6.
 * Без залежностей від Android — код перевірено окремо на реальних .ast файлах гри.
 * Піксель = ARGB (Int).
 */
public final class Astc {
    private Astc() {}

    static final int[] R_NB = {1, 0, 2, 0, 1, 3, 1, 2, 4, 2, 3, 5, 3, 4, 6, 4, 5, 7, 6, 8};
    static final int[] R_TR = {0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0};
    static final int[] R_QU = {0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0};
    static final int[] CEM_N = {2, 2, 2, 2, 4, 4, 4, 4, 6, 6, 6, 6, 8, 8, 8, 8};

    static int iseBits(int n, int r) {
        int b = n * R_NB[r];
        if (R_TR[r] != 0) b += (8 * n + 4) / 5;
        if (R_QU[r] != 0) b += (7 * n + 2) / 3;
        return b;
    }

    // ---------- trit / quint ----------
    static void tritDecode(int T, int[] o) {
        int c, t4, t3;
        if (((T >> 2) & 7) == 7) { c = (((T >> 5) & 7) << 2) | (T & 3); t4 = 2; t3 = 2; }
        else {
            c = T & 31;
            if (((T >> 5) & 3) == 3) { t4 = 2; t3 = (T >> 7) & 1; } else { t4 = (T >> 7) & 1; t3 = (T >> 5) & 3; }
        }
        int t2, t1, t0;
        if ((c & 3) == 3) { t2 = 2; t1 = (c >> 4) & 1; t0 = (((c >> 3) & 1) << 1) | (((c >> 2) & 1) & (~(c >> 3) & 1)); }
        else if (((c >> 2) & 3) == 3) { t2 = 2; t1 = 2; t0 = c & 3; }
        else { t2 = (c >> 4) & 1; t1 = (c >> 2) & 3; t0 = (((c >> 1) & 1) << 1) | ((c & 1) & (~(c >> 1) & 1)); }
        o[0] = t0; o[1] = t1; o[2] = t2; o[3] = t3; o[4] = t4;
    }

    static void quintDecode(int Q, int[] o) {
        int q0, q1, q2;
        if (((Q >> 1) & 3) == 3 && ((Q >> 5) & 3) == 0) {
            q2 = ((Q & 1) << 2) | ((((Q >> 4) & 1) & (1 - (Q & 1))) << 1) | (((Q >> 3) & 1) & (1 - (Q & 1)));
            q1 = 4; q0 = 4;
        } else {
            int c;
            if (((Q >> 1) & 3) == 3) { q2 = 4; c = (((Q >> 3) & 3) << 3) | (((~(Q >> 5)) & 3) << 1) | (Q & 1); }
            else { q2 = (Q >> 5) & 3; c = Q & 31; }
            if ((c & 7) == 5) { q1 = 4; q0 = (c >> 3) & 3; } else { q1 = (c >> 3) & 3; q0 = c & 7; }
        }
        o[0] = q0; o[1] = q1; o[2] = q2;
    }

    static final int[] TRIT_ENC = new int[243];
    static final int[] QUINT_ENC = new int[125];
    static {
        java.util.Arrays.fill(TRIT_ENC, -1); java.util.Arrays.fill(QUINT_ENC, -1);
        int[] o = new int[5];
        for (int T = 0; T < 256; T++) {
            tritDecode(T, o);
            boolean ok = true; for (int k = 0; k < 5; k++) if (o[k] > 2) ok = false;
            if (!ok) continue;
            int idx = o[0] + 3 * o[1] + 9 * o[2] + 27 * o[3] + 81 * o[4];
            if (TRIT_ENC[idx] < 0) TRIT_ENC[idx] = T;
        }
        for (int Q = 0; Q < 128; Q++) {
            quintDecode(Q, o);
            boolean ok = true; for (int k = 0; k < 3; k++) if (o[k] > 4) ok = false;
            if (!ok) continue;
            int idx = o[0] + 5 * o[1] + 25 * o[2];
            if (QUINT_ENC[idx] < 0) QUINT_ENC[idx] = Q;
        }
    }

    // ---------- бітові допоміжні ----------
    static int bits(long lo, long hi, int pos, int n) {
        if (n <= 0) return 0;
        long r;
        if (pos >= 64) r = hi >>> (pos - 64);
        else if (pos + n <= 64) r = lo >>> pos;
        else r = (lo >>> pos) | (hi << (64 - pos));
        return (int) (r & ((1L << n) - 1));
    }

    /** ISE-декодування: повертає пари (t, m) у tt[], mm[]. */
    static void iseDecode(long lo, long hi, int start, int count, int r, int[] tt, int[] mm) {
        final int nb = R_NB[r];
        final int end = start + iseBits(count, r);
        int pos = start;
        int[] tmp = new int[5];
        if (R_TR[r] != 0) {
            for (int i = 0; i < count; i += 5) {
                int[] m = new int[5]; int T = 0;
                for (int k = 0; k < 5; k++) {
                    int n1 = Math.max(0, Math.min(nb, end - pos)); m[k] = bits(lo, hi, pos, n1); pos += nb;
                    int tb = (k == 0 || k == 1 || k == 3) ? 2 : 1;
                    int n2 = Math.max(0, Math.min(tb, end - pos)); int v = bits(lo, hi, pos, n2); pos += tb;
                    if (k == 0) T |= v; else if (k == 1) T |= v << 2; else if (k == 2) T |= v << 4; else if (k == 3) T |= v << 5; else T |= v << 7;
                }
                tritDecode(T, tmp);
                for (int k = 0; k < 5 && i + k < count; k++) { tt[i + k] = tmp[k]; mm[i + k] = m[k]; }
            }
        } else if (R_QU[r] != 0) {
            for (int i = 0; i < count; i += 3) {
                int[] m = new int[3]; int Q = 0;
                for (int k = 0; k < 3; k++) {
                    int n1 = Math.max(0, Math.min(nb, end - pos)); m[k] = bits(lo, hi, pos, n1); pos += nb;
                    int qb = (k == 0) ? 3 : 2;
                    int n2 = Math.max(0, Math.min(qb, end - pos)); int v = bits(lo, hi, pos, n2); pos += qb;
                    if (k == 0) Q |= v; else if (k == 1) Q |= v << 3; else Q |= v << 5;
                }
                quintDecode(Q, tmp);
                for (int k = 0; k < 3 && i + k < count; k++) { tt[i + k] = tmp[k]; mm[i + k] = m[k]; }
            }
        } else {
            for (int i = 0; i < count; i++) {
                int n1 = Math.max(0, Math.min(nb, end - pos)); mm[i] = bits(lo, hi, pos, n1); pos += nb; tt[i] = 0;
            }
        }
    }

    // ---------- розквантування ----------
    static int unqColor(int r, int t, int m) {
        int nb = R_NB[r];
        if (R_TR[r] != 0) { if (nb == 0) return new int[]{0, 128, 255}[t]; return AstcTables.DQ_TRIT[nb][t * (1 << nb) + m]; }
        if (R_QU[r] != 0) { if (nb == 0) return new int[]{0, 64, 128, 191, 255}[t]; return AstcTables.DQ_QUINT[nb][t * (1 << nb) + m]; }
        int out = 0, sh = 8;
        while (sh > 0) { sh -= nb; out |= (sh >= 0) ? (m << sh) : (m >> (-sh)); }
        return out & 255;
    }

    static int unqWeight(int r, int t, int m) {
        int nb = R_NB[r];
        boolean tr = R_TR[r] != 0, qu = R_QU[r] != 0;
        if (!tr && !qu) {
            int out = 0, sh = 6;
            while (sh > 0) { sh -= nb; out |= (sh >= 0) ? (m << sh) : (m >> (-sh)); }
            out &= 63;
            return out > 32 ? out + 1 : out;
        }
        if (nb == 0) return tr ? t * 32 : t * 16;
        int a = m & 1;
        int A = a != 0 ? 0x7F : 0;
        int C, B;
        if (tr) {
            if (nb == 1) { C = 50; B = 0; }
            else if (nb == 2) { int b = (m >> 1) & 1; C = 23; B = (b << 6) | (b << 2) | b; }
            else { int b = (m >> 1) & 1, c = (m >> 2) & 1; C = 11; B = (c << 6) | (b << 5) | (c << 1) | b; }
        } else {
            if (nb == 1) { C = 28; B = 0; }
            else { int b = (m >> 1) & 1; C = 13; B = (b << 6) | (b << 1); }
        }
        int X = t * C + B;
        X ^= A;
        X = (A & 0x20) | (X >> 2);
        return X > 32 ? X + 1 : X;
    }

    // ---------- режим блоку ----------
    /** {xw, yw, dualPlane, rangeIndex} або null. */
    static int[] blockMode(int bm) {
        int base = (bm >> 4) & 1, H = (bm >> 9) & 1, D = (bm >> 10) & 1, A = (bm >> 5) & 3, xw, yw;
        if ((bm & 3) != 0) {
            base |= (bm & 3) << 1;
            int B = (bm >> 7) & 3;
            switch ((bm >> 2) & 3) {
                case 0: xw = B + 4; yw = A + 2; break;
                case 1: xw = B + 8; yw = A + 2; break;
                case 2: xw = A + 2; yw = B + 8; break;
                default:
                    B &= 1;
                    if ((bm & 0x100) != 0) { xw = B + 2; yw = A + 2; } else { xw = A + 2; yw = B + 6; }
            }
        } else {
            base |= ((bm >> 2) & 3) << 1;
            if (((bm >> 2) & 3) == 0) return null;
            int B = (bm >> 9) & 3;
            switch ((bm >> 7) & 3) {
                case 0: xw = 12; yw = A + 2; break;
                case 1: xw = A + 2; yw = 12; break;
                case 2: xw = A + 6; yw = B + 6; D = 0; H = 0; break;
                default:
                    switch ((bm >> 5) & 3) {
                        case 0: xw = 6; yw = 10; break;
                        case 1: xw = 10; yw = 6; break;
                        default: return null;
                    }
            }
        }
        if (base < 2) return null;
        int qm = (base - 2) + 6 * H;
        if (qm >= 12) return null;
        return new int[]{xw, yw, D, qm};
    }

    // ---------- розділи ----------
    static int hash52(int p) {
        p ^= p >>> 15; p -= p << 17; p += p << 7; p += p << 4;
        p ^= p >>> 5; p += p << 16; p ^= p >>> 7; p ^= p >>> 3;
        p ^= p << 6; p ^= p >>> 17;
        return p;
    }

    static int selectPartition(int seed, int x, int y, int pc, boolean small) {
        if (small) { x <<= 1; y <<= 1; }
        seed += (pc - 1) * 1024;
        int r = hash52(seed);
        int s1 = r & 15, s2 = (r >>> 4) & 15, s3 = (r >>> 8) & 15, s4 = (r >>> 12) & 15, s5 = (r >>> 16) & 15, s6 = (r >>> 20) & 15,
            s7 = (r >>> 24) & 15, s8 = (r >>> 28) & 15, s9 = (r >>> 18) & 15, s10 = (r >>> 22) & 15, s11 = (r >>> 26) & 15, s12 = ((r >>> 30) | (r << 2)) & 15;
        s1 *= s1; s2 *= s2; s3 *= s3; s4 *= s4; s5 *= s5; s6 *= s6; s7 *= s7; s8 *= s8; s9 *= s9; s10 *= s10; s11 *= s11; s12 *= s12;
        int sh1, sh2;
        if ((seed & 1) != 0) { sh1 = (seed & 2) != 0 ? 4 : 5; sh2 = pc == 3 ? 6 : 5; }
        else { sh1 = pc == 3 ? 6 : 5; sh2 = (seed & 2) != 0 ? 4 : 5; }
        int sh3 = (seed & 0x10) != 0 ? sh1 : sh2;
        s1 >>= sh1; s2 >>= sh2; s3 >>= sh1; s4 >>= sh2; s5 >>= sh1; s6 >>= sh2; s7 >>= sh1; s8 >>= sh2;
        s9 >>= sh3; s10 >>= sh3; s11 >>= sh3; s12 >>= sh3;
        int a = (s1 * x + s2 * y + (r >>> 14)) & 63;
        int b = (s3 * x + s4 * y + (r >>> 10)) & 63;
        int c = (s5 * x + s6 * y + (r >>> 6)) & 63;
        int d = (s7 * x + s8 * y + (r >>> 2)) & 63;
        if (pc < 4) d = 0;
        if (pc < 3) c = 0;
        if (a >= b && a >= c && a >= d) return 0;
        if (b >= c && b >= d) return 1;
        if (c >= d) return 2;
        return 3;
    }

    // ---------- кінцеві точки ----------
    static int clamp255(int x) { return x < 0 ? 0 : (x > 255 ? 255 : x); }

    /** bit_transfer_signed: r[0]=offset(a), r[1]=base(b). */
    static void bitTransfer(int a, int b, int[] r) {
        b = (b >> 1) | (a & 0x80);
        a = (a >> 1) & 0x3F;
        if ((a & 0x20) != 0) a -= 0x40;
        r[0] = a; r[1] = b;
    }

    /** Повертає false для HDR/невідомих режимів. e0, e1 = {r,g,b,a}. */
    static boolean decodeCem(int c, int[] v, int o, int[] e0, int[] e1) {
        int[] t = new int[2];
        switch (c) {
            case 0: e0[0] = e0[1] = e0[2] = v[o]; e0[3] = 255; e1[0] = e1[1] = e1[2] = v[o + 1]; e1[3] = 255; return true;
            case 1: {
                int l0 = (v[o] >> 2) | (v[o + 1] & 0xC0), l1 = Math.min(255, l0 + (v[o + 1] & 0x3F));
                e0[0] = e0[1] = e0[2] = l0; e0[3] = 255; e1[0] = e1[1] = e1[2] = l1; e1[3] = 255; return true;
            }
            case 4: e0[0] = e0[1] = e0[2] = v[o]; e0[3] = v[o + 2]; e1[0] = e1[1] = e1[2] = v[o + 1]; e1[3] = v[o + 3]; return true;
            case 5: {
                bitTransfer(v[o + 1], v[o], t); int x1 = t[0], y1 = t[1];
                bitTransfer(v[o + 3], v[o + 2], t); int x3 = t[0], y3 = t[1];
                e0[0] = e0[1] = e0[2] = y1; e0[3] = y3;
                int l1 = clamp255(y1 + x1); e1[0] = e1[1] = e1[2] = l1; e1[3] = clamp255(y3 + x3); return true;
            }
            case 6:
                e0[0] = (v[o] * v[o + 3]) >> 8; e0[1] = (v[o + 1] * v[o + 3]) >> 8; e0[2] = (v[o + 2] * v[o + 3]) >> 8; e0[3] = 255;
                e1[0] = v[o]; e1[1] = v[o + 1]; e1[2] = v[o + 2]; e1[3] = 255; return true;
            case 10:
                e0[0] = (v[o] * v[o + 3]) >> 8; e0[1] = (v[o + 1] * v[o + 3]) >> 8; e0[2] = (v[o + 2] * v[o + 3]) >> 8; e0[3] = v[o + 4];
                e1[0] = v[o]; e1[1] = v[o + 1]; e1[2] = v[o + 2]; e1[3] = v[o + 5]; return true;
            case 8: case 12: {
                int a = (c == 12) ? v[o + 6] : 255, b = (c == 12) ? v[o + 7] : 255;
                int s0 = v[o] + v[o + 2] + v[o + 4], s1 = v[o + 1] + v[o + 3] + v[o + 5];
                if (s1 >= s0) {
                    e0[0] = v[o]; e0[1] = v[o + 2]; e0[2] = v[o + 4]; e0[3] = a;
                    e1[0] = v[o + 1]; e1[1] = v[o + 3]; e1[2] = v[o + 5]; e1[3] = b;
                } else {
                    e0[0] = (v[o + 1] + v[o + 5]) >> 1; e0[1] = (v[o + 3] + v[o + 5]) >> 1; e0[2] = v[o + 5]; e0[3] = b;
                    e1[0] = (v[o] + v[o + 4]) >> 1; e1[1] = (v[o + 2] + v[o + 4]) >> 1; e1[2] = v[o + 4]; e1[3] = a;
                }
                return true;
            }
            case 9: case 13: {
                bitTransfer(v[o + 1], v[o], t); int x0 = t[0], y0 = t[1];
                bitTransfer(v[o + 3], v[o + 2], t); int x1 = t[0], y1 = t[1];
                bitTransfer(v[o + 5], v[o + 4], t); int x2 = t[0], y2 = t[1];
                e0[0] = y0; e0[1] = y1; e0[2] = y2; e0[3] = 255;
                e1[0] = clamp255(y0 + x0); e1[1] = clamp255(y1 + x1); e1[2] = clamp255(y2 + x2); e1[3] = 255;
                if (c == 13) { bitTransfer(v[o + 7], v[o + 6], t); e0[3] = t[1]; e1[3] = clamp255(t[1] + t[0]); }
                if (x0 + x1 + x2 < 0) {
                    int[] a0 = {(e1[0] + e1[2]) >> 1, (e1[1] + e1[2]) >> 1, e1[2], e1[3]};
                    int[] a1 = {(e0[0] + e0[2]) >> 1, (e0[1] + e0[2]) >> 1, e0[2], e0[3]};
                    System.arraycopy(a0, 0, e0, 0, 4); System.arraycopy(a1, 0, e1, 0, 4);
                }
                return true;
            }
            default: return false;
        }
    }

    static final int MAGENTA = 0xFFFF00FF;

    /**
     * Декодує один блок bw x bh з data[off..off+16]. out — масив bw*bh ARGB.
     * Повертає 0 = ok, 1 = void-extent, 2 = помилка/HDR (піксель = magenta).
     */
    public static int decodeBlock(byte[] data, int off, int bw, int bh, int[] out) {
        long lo = 0, hi = 0;
        for (int i = 7; i >= 0; i--) { lo = (lo << 8) | (data[off + i] & 0xFF); hi = (hi << 8) | (data[off + 8 + i] & 0xFF); }
        int bm = bits(lo, hi, 0, 11);
        int n = bw * bh;
        if ((bm & 0x1FF) == 0x1FC) {
            int r = (int) ((hi) & 0xFFFF) >> 8, g = (int) ((hi >>> 16) & 0xFFFF) >> 8, b = (int) ((hi >>> 32) & 0xFFFF) >> 8, a = (int) ((hi >>> 48) & 0xFFFF) >> 8;
            int col = (a << 24) | (r << 16) | (g << 8) | b;
            for (int i = 0; i < n; i++) out[i] = col;
            return 1;
        }
        int[] mi = blockMode(bm);
        if (mi == null) { java.util.Arrays.fill(out, 0, n, MAGENTA); return 2; }
        int xw = mi[0], yw = mi[1], D = mi[2], wr = mi[3];
        int nw = xw * yw * (D != 0 ? 2 : 1);
        int wbits = iseBits(nw, wr);
        int pc = bits(lo, hi, 11, 2) + 1;
        if (nw > 64 || wbits > 96 || wbits < 24 || xw > bw || yw > bh || (D != 0 && pc == 4)) { java.util.Arrays.fill(out, 0, n, MAGENTA); return 2; }
        int[] cems = new int[4];
        int cstart, hp = 0, pidx = 0;
        if (pc == 1) { cems[0] = bits(lo, hi, 13, 4); cstart = 17; }
        else {
            pidx = bits(lo, hi, 13, 10);
            hp = 3 * pc - 4;
            int below = 128 - wbits - hp;
            int et = bits(lo, hi, 23, 6) | (bits(lo, hi, below, hp) << 6);
            int base = et & 3;
            if (base == 0) { for (int i = 0; i < pc; i++) cems[i] = (et >> 2) & 15; hp = 0; }
            else for (int i = 0; i < pc; i++) {
                int c = (et >> (2 + i)) & 1, m = (et >> (2 + pc + 2 * i)) & 3;
                cems[i] = ((base - 1 + c) << 2) | m;
            }
            cstart = 29;
        }
        int dpBits = D != 0 ? 2 : 0;
        int nvals = 0;
        for (int i = 0; i < pc; i++) nvals += CEM_N[cems[i]];
        int avail = 128 - wbits - hp - dpBits - cstart;
        int qr = -1;
        for (int r = 19; r >= 0; r--) if (iseBits(nvals, r) <= avail) { qr = r; break; }
        if (nvals > 18 || qr < 0) { java.util.Arrays.fill(out, 0, n, MAGENTA); return 2; }
        int[] ct = new int[nvals], cm = new int[nvals], cv = new int[nvals];
        iseDecode(lo, hi, cstart, nvals, qr, ct, cm);
        for (int i = 0; i < nvals; i++) cv[i] = unqColor(qr, ct[i], cm[i]);
        int[][] e0 = new int[4][4], e1 = new int[4][4];
        int k = 0;
        for (int i = 0; i < pc; i++) {
            if (!decodeCem(cems[i], cv, k, e0[i], e1[i])) { java.util.Arrays.fill(out, 0, n, MAGENTA); return 2; }
            k += CEM_N[cems[i]];
        }
        long rlo = Long.reverse(hi), rhi = Long.reverse(lo);
        int[] wt = new int[nw], wm = new int[nw], ws = new int[nw];
        iseDecode(rlo, rhi, 0, nw, wr, wt, wm);
        for (int i = 0; i < nw; i++) ws[i] = unqWeight(wr, wt[i], wm[i]);
        int plane2 = D != 0 ? bits(lo, hi, 128 - wbits - hp - 2, 2) : 0;
        int[] w1 = new int[xw * yw], w2 = null;
        if (D != 0) { w2 = new int[xw * yw]; for (int i = 0; i < xw * yw; i++) { w1[i] = ws[2 * i]; w2[i] = ws[2 * i + 1]; } }
        else System.arraycopy(ws, 0, w1, 0, nw);
        int Ds = (1024 + bw / 2) / (bw - 1), Dt = (1024 + bh / 2) / (bh - 1);
        boolean small = n < 31;
        for (int y = 0; y < bh; y++) {
            for (int x = 0; x < bw; x++) {
                int gs = ((Ds * x) * (xw - 1) + 32) >> 6, gt = ((Dt * y) * (yw - 1) + 32) >> 6;
                int js = gs >> 4, fs = gs & 15, jt = gt >> 4, ft = gt & 15;
                int v0 = js + jt * xw;
                int w11 = (fs * ft + 8) >> 4, w10 = ft - w11, w01 = fs - w11, w00 = 16 - fs - ft + w11;
                int i1 = (fs != 0 || js + 1 < xw) ? v0 + 1 : v0;
                int i10 = (ft != 0 || jt + 1 < yw) ? v0 + xw : v0;
                int i11 = Math.min(v0 + xw + 1, xw * yw - 1);
                int f1 = (w1[v0] * w00 + w1[Math.min(i1, xw * yw - 1)] * w01 + w1[Math.min(i10, xw * yw - 1)] * w10 + w1[i11] * w11 + 8) >> 4;
                int f2 = 0;
                if (D != 0) f2 = (w2[v0] * w00 + w2[Math.min(i1, xw * yw - 1)] * w01 + w2[Math.min(i10, xw * yw - 1)] * w10 + w2[i11] * w11 + 8) >> 4;
                int p = pc == 1 ? 0 : selectPartition(pidx, x, y, pc, small);
                int px = 0;
                for (int ch = 0; ch < 4; ch++) {
                    int w = (D != 0 && ch == plane2) ? f2 : f1;
                    int c0 = e0[p][ch] * 257, c1 = e1[p][ch] * 257;
                    int c = ((c0 * (64 - w) + c1 * w + 32) >> 6) >> 8;
                    if (c > 255) c = 255;
                    px |= c << ((ch == 3) ? 24 : (ch == 0 ? 16 : (ch == 1 ? 8 : 0)));
                }
                out[y * bw + x] = px;
            }
        }
        return 0;
    }

    // =====================================================================
    //                              КОДУВАЛЬНИК 6x6
    // =====================================================================
    private static final int[][] QV = new int[20][];   // відсортовані значення
    private static final int[][] QT = new int[20][], QM = new int[20][];
    private static final int[][] NEAR = new int[20][]; // найближчий індекс у відсортованому списку для 0..255
    static {
        for (int r = 4; r < 20; r++) {
            int nb = R_NB[r];
            int nt = R_TR[r] != 0 ? 3 : (R_QU[r] != 0 ? 5 : 1);
            int cnt = nt * (1 << nb);
            Integer[] idx = new Integer[cnt];
            int[] val = new int[cnt], tt = new int[cnt], mm = new int[cnt];
            for (int t = 0; t < nt; t++) for (int m = 0; m < (1 << nb); m++) { int i = t * (1 << nb) + m; tt[i] = t; mm[i] = m; val[i] = unqColor(r, t, m); idx[i] = i; }
            java.util.Arrays.sort(idx, (a, b) -> val[a] != val[b] ? Integer.compare(val[a], val[b]) : Integer.compare(a, b));
            QV[r] = new int[cnt]; QT[r] = new int[cnt]; QM[r] = new int[cnt];
            for (int i = 0; i < cnt; i++) { QV[r][i] = val[idx[i]]; QT[r][i] = tt[idx[i]]; QM[r][i] = mm[idx[i]]; }
            NEAR[r] = new int[256];
            for (int x = 0; x < 256; x++) {
                int best = 0, bd = 1 << 30;
                for (int i = 0; i < cnt; i++) { int d = Math.abs(QV[r][i] - x); if (d < bd) { bd = d; best = i; } }
                NEAR[r][x] = best;
            }
        }
    }
    // ваги: 0 = 4 рівні (2 біти), 1 = 5 рівнів (quint)
    private static final int[][] WV = new int[2][], WT = new int[2][], WMm = new int[2][];
    private static final int[] WRANGE = {2, 3};
    static {
        for (int k = 0; k < 2; k++) {
            int r = WRANGE[k];
            int nt = R_QU[r] != 0 ? 5 : 1, nm = 1 << R_NB[r];
            int cnt = nt * nm;
            int[] val = new int[cnt], tt = new int[cnt], mm = new int[cnt]; Integer[] idx = new Integer[cnt];
            for (int t = 0; t < nt; t++) for (int m = 0; m < nm; m++) { int i = t * nm + m; tt[i] = t; mm[i] = m; val[i] = unqWeight(r, t, m); idx[i] = i; }
            java.util.Arrays.sort(idx, (a, b) -> Integer.compare(val[a], val[b]));
            WV[k] = new int[cnt]; WT[k] = new int[cnt]; WMm[k] = new int[cnt];
            for (int i = 0; i < cnt; i++) { WV[k][i] = val[idx[i]]; WT[k][i] = tt[idx[i]]; WMm[k][i] = mm[idx[i]]; }
        }
    }

    /** Записувач 128-бітного блоку. */
    private static final class BitW {
        long lo, hi;
        void set(int pos, int bit) { if (bit == 0) return; if (pos >= 64) hi |= 1L << (pos - 64); else lo |= 1L << pos; }
        void put(int pos, int val, int n) { for (int k = 0; k < n; k++) set(pos + k, (val >> k) & 1); }
    }

    /** ISE-кодування в блок. rev=true — біти пишуться з кінця (ваги). Повертає кількість записаних бітів. */
    private static int iseWrite(BitW w, int start, boolean rev, int[] t, int[] m, int count, int r) {
        final int nb = R_NB[r];
        int[] pos = {0};
        class P { void wr(int val, int n) { for (int k = 0; k < n; k++) { int p = pos[0] + k; w.set(rev ? 127 - (start + p) : start + p, (val >> k) & 1); } pos[0] += n; } }
        P p = new P();
        int total = iseBits(count, r);
        if (R_TR[r] != 0) {
            for (int i = 0; i < count; i += 5) {
                int[] tg = new int[5], mg = new int[5];
                for (int k = 0; k < 5; k++) if (i + k < count) { tg[k] = t[i + k]; mg[k] = m[i + k]; }
                int T = TRIT_ENC[tg[0] + 3 * tg[1] + 9 * tg[2] + 27 * tg[3] + 81 * tg[4]];
                p.wr(mg[0], nb); p.wr(T & 3, 2);
                p.wr(mg[1], nb); p.wr((T >> 2) & 3, 2);
                p.wr(mg[2], nb); p.wr((T >> 4) & 1, 1);
                p.wr(mg[3], nb); p.wr((T >> 5) & 3, 2);
                p.wr(mg[4], nb); p.wr((T >> 7) & 1, 1);
            }
        } else if (R_QU[r] != 0) {
            for (int i = 0; i < count; i += 3) {
                int[] tg = new int[3], mg = new int[3];
                for (int k = 0; k < 3; k++) if (i + k < count) { tg[k] = t[i + k]; mg[k] = m[i + k]; }
                int Q = QUINT_ENC[tg[0] + 5 * tg[1] + 25 * tg[2]];
                p.wr(mg[0], nb); p.wr(Q & 7, 3);
                p.wr(mg[1], nb); p.wr((Q >> 3) & 3, 2);
                p.wr(mg[2], nb); p.wr((Q >> 5) & 3, 2);
            }
        } else {
            for (int i = 0; i < count; i++) p.wr(m[i], nb);
        }
        // біти понад total — завжди нулі за побудовою, але частковий останній блок міг записати зайве
        if (pos[0] > total) {
            for (int q = total; q < pos[0]; q++) { int pp = rev ? 127 - (start + q) : start + q; if (pp >= 64) w.hi &= ~(1L << (pp - 64)); else w.lo &= ~(1L << pp); }
        }
        return total;
    }

    /** Екземпляр кодувальника з робочими буферами (по одному на потік). */
    public static final class Encoder {
        private final float[] P = new float[36 * 4];
        private final float[] lo = new float[4], hi = new float[4], mean = new float[4], axis = new float[4];
        private final double[] cov = new double[16];
        private final int[] qi0 = new int[4], qi1 = new int[4];
        private final int[] bi0 = new int[4], bi1 = new int[4];
        private final float[] e0 = new float[4], e1 = new float[4];
        private final int[] wi = new int[36], bestWi = new int[36];
        private final int[] tt = new int[36], mm = new int[36];
        private final int[] ct = new int[8], cmv = new int[8];
        private double bestSse; private int bestRw; private boolean bestSet;
        private long outLo, outHi;
        private boolean bestAlpha;
        private int bestCr;

        /** px — 36 пікселів ARGB (рядок за рядком). Записує 16 байтів у out[off..]. */
        public void encode(int[] px, byte[] out, int off) {
            boolean same = true, opaque = true;
            for (int i = 1; i < 36; i++) if (px[i] != px[0]) { same = false; break; }
            for (int i = 0; i < 36; i++) if ((px[i] >>> 24) != 255) { opaque = false; break; }
            if (same) {
                int c = px[0];
                long r = ((c >> 16) & 255) * 257L, g = ((c >> 8) & 255) * 257L, b = (c & 255) * 257L, a = ((c >>> 24) & 255) * 257L;
                long lo64 = 0xFFFFFFFFFFFFFDFCL, hi64 = r | (g << 16) | (b << 32) | (a << 48);
                writeBlock(lo64, hi64, out, off); return;
            }
            final int ch = opaque ? 3 : 4;
            for (int i = 0; i < 36; i++) {
                int c = px[i];
                P[i * 4] = (c >> 16) & 255; P[i * 4 + 1] = (c >> 8) & 255; P[i * 4 + 2] = c & 255; P[i * 4 + 3] = (c >>> 24) & 255;
            }
            bestSet = false; bestSse = Double.MAX_VALUE;
            for (int rw = 0; rw < (opaque ? 2 : 1); rw++) tryCandidate(rw, ch, !opaque);
            writeBlock(outLo, outHi, out, off);
        }

        private static void writeBlock(long lo, long hi, byte[] out, int off) {
            for (int i = 0; i < 8; i++) { out[off + i] = (byte) (lo >>> (8 * i)); out[off + 8 + i] = (byte) (hi >>> (8 * i)); }
        }

        private void principal(int ch) {
            for (int c = 0; c < ch; c++) mean[c] = 0;
            for (int i = 0; i < 36; i++) for (int c = 0; c < ch; c++) mean[c] += P[i * 4 + c];
            for (int c = 0; c < ch; c++) mean[c] /= 36f;
            for (int a = 0; a < ch * ch; a++) cov[a] = 0;
            for (int i = 0; i < 36; i++) for (int a = 0; a < ch; a++) { double da = P[i * 4 + a] - mean[a]; for (int b = 0; b < ch; b++) cov[a * ch + b] += da * (P[i * 4 + b] - mean[b]); }
            double[] v = new double[4];
            for (int c = 0; c < ch; c++) v[c] = 1.0 + 0.1 * c;
            for (int it = 0; it < 8; it++) {
                double[] nv = new double[4]; double n2 = 0;
                for (int a = 0; a < ch; a++) { double s = 0; for (int b = 0; b < ch; b++) s += cov[a * ch + b] * v[b]; nv[a] = s; n2 += s * s; }
                if (n2 < 1e-12) break;
                double inv = 1.0 / Math.sqrt(n2);
                for (int a = 0; a < ch; a++) v[a] = nv[a] * inv;
            }
            double nn = 0; for (int c = 0; c < ch; c++) nn += v[c] * v[c];
            nn = Math.sqrt(nn); if (nn < 1e-9) nn = 1;
            for (int c = 0; c < ch; c++) axis[c] = (float) (v[c] / nn);
            float tmin = Float.MAX_VALUE, tmax = -Float.MAX_VALUE;
            for (int i = 0; i < 36; i++) {
                float t = 0; for (int c = 0; c < ch; c++) t += (P[i * 4 + c] - mean[c]) * axis[c];
                if (t < tmin) tmin = t; if (t > tmax) tmax = t;
            }
            for (int c = 0; c < ch; c++) { lo[c] = mean[c] + axis[c] * tmin; hi[c] = mean[c] + axis[c] * tmax; }
        }

        private void tryCandidate(int rwi, int ch, boolean alpha) {
            final int rw = WRANGE[rwi];
            final int ncv = alpha ? 8 : 6, cem = alpha ? 12 : 8;
            final int wbits = iseBits(36, rw);
            final int avail = 128 - wbits - 17;
            int cr = -1;
            for (int r = 19; r >= 0; r--) if (iseBits(ncv, r) <= avail) { cr = r; break; }
            if (cr < 4) return;
            final int[] wv = WV[rwi]; final int nl = wv.length;
            principal(ch);
            double best = Double.MAX_VALUE;
            boolean got = false;
            final float[] wf = new float[nl];
            for (int i = 0; i < nl; i++) wf[i] = wv[i] / 64f;
            for (int iter = 0; iter < 3; iter++) {
                for (int c = 0; c < ch; c++) {
                    int a = Math.round(lo[c]); a = a < 0 ? 0 : (a > 255 ? 255 : a);
                    int b = Math.round(hi[c]); b = b < 0 ? 0 : (b > 255 ? 255 : b);
                    qi0[c] = NEAR[cr][a]; qi1[c] = NEAR[cr][b];
                }
                int s0 = 0, s1 = 0;
                for (int c = 0; c < 3; c++) { s0 += QV[cr][qi0[c]]; s1 += QV[cr][qi1[c]]; }
                boolean swap = s1 < s0;
                for (int c = 0; c < ch; c++) {
                    int a = swap ? qi1[c] : qi0[c], b = swap ? qi0[c] : qi1[c];
                    qi0[c] = a; qi1[c] = b;
                    e0[c] = QV[cr][a]; e1[c] = QV[cr][b];
                }
                double sse = 0;
                for (int i = 0; i < 36; i++) {
                    int bi = 0; float bd = Float.MAX_VALUE;
                    for (int k = 0; k < nl; k++) {
                        float d = 0;
                        for (int c = 0; c < ch; c++) { float x = e0[c] + wf[k] * (e1[c] - e0[c]) - P[i * 4 + c]; d += x * x; }
                        if (d < bd) { bd = d; bi = k; }
                    }
                    wi[i] = bi; sse += bd;
                }
                if (sse < best) {
                    best = sse; got = true;
                    System.arraycopy(qi0, 0, bi0, 0, 4); System.arraycopy(qi1, 0, bi1, 0, 4); System.arraycopy(wi, 0, bestWi, 0, 36);
                }
                // уточнення кінцевих точок методом найменших квадратів
                double saa = 0, sab = 0, sbb = 0;
                double[] ra = new double[4], rb = new double[4];
                for (int i = 0; i < 36; i++) {
                    double wgt = wf[wi[i]], a = 1 - wgt;
                    saa += a * a; sab += a * wgt; sbb += wgt * wgt;
                    for (int c = 0; c < ch; c++) { ra[c] += a * P[i * 4 + c]; rb[c] += wgt * P[i * 4 + c]; }
                }
                double det = saa * sbb - sab * sab;
                if (Math.abs(det) < 1e-6) break;
                for (int c = 0; c < ch; c++) {
                    lo[c] = (float) ((ra[c] * sbb - rb[c] * sab) / det);
                    hi[c] = (float) ((rb[c] * saa - ra[c] * sab) / det);
                }
            }
            if (!got || best >= bestSse) return;
            // збираємо блок
            BitW w = new BitW();
            int bm = (1 << 8) | ((((rw + 2) >> 1) & 3) << 2) | (((rw + 2) & 1) << 4);
            w.put(0, bm, 11);
            w.put(13, cem, 4);
            int n = 0;
            for (int c = 0; c < ch; c++) {
                ct[n] = QT[cr][bi0[c]]; cmv[n] = QM[cr][bi0[c]]; n++;
                ct[n] = QT[cr][bi1[c]]; cmv[n] = QM[cr][bi1[c]]; n++;
            }
            iseWrite(w, 17, false, ct, cmv, n, cr);
            for (int i = 0; i < 36; i++) { tt[i] = WT[rwi][bestWi[i]]; mm[i] = WMm[rwi][bestWi[i]]; }
            iseWrite(w, 0, true, tt, mm, 36, rw);
            outLo = w.lo; outHi = w.hi; bestSse = best; bestSet = true;
        }
    }
}
