@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException

/** Читання зображень (PNG/JPG/WEBP/BMP/DDS/AST), зміна розміру, запис у PNG / JPG / TGA / DDS (DXT1 або DXT5 з мипмапами) / AST (ASTC 6x6, FS26 Mobile). */
object ImageTools {
    class Img(val w: Int, val h: Int, val px: IntArray)

    fun load(bytes: ByteArray, name: String): Img? {
        var data = bytes
        if (name.endsWith(".ast", true)) {
            try { val g = Gs2d.decode(bytes, 0); return Img(g.w, g.h, g.px) }
            catch (e: IllegalArgumentException) { throw IOException("AST: " + e.message) }
        }
        if (name.endsWith(".dds", true)) { val r = Dds.decode(bytes, 0); data = r.png ?: return null }
        val bmp = BitmapFactory.decodeByteArray(data, 0, data.size) ?: return null
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val img = Img(bmp.width, bmp.height, px)
        bmp.recycle()
        return img
    }

    /** Авто-стиснення: розмір (довша сторона), до якого можна зменшити текстуру майже без втрати деталей. level: 0 макс., 1 баланс, 2 якість. */
    fun autoSize(img: Img, level: Int, name: String): Int {
        val n = name.substringAfterLast('/').lowercase()
        val strict = n.contains("normal") || n.contains("_n.") || n.endsWith("_n")
        return ImgFix.autoSize(img.px, img.w, img.h, level, strict)
    }

    /** size > 0: задана довша сторона; 0 = без змін; -2 = авто-стиснення. */
    fun fit(img: Img, size: Int, square: Boolean, level: Int, name: String): Img =
        if (size == -2) resize(img, autoSize(img, level, name), false) else resize(img, size, square)

    fun resize(img: Img, size: Int, square: Boolean): Img {
        if (size <= 0) return img
        val nw: Int; val nh: Int
        if (square) { nw = size; nh = size } else {
            val s = size.toFloat() / maxOf(img.w, img.h)
            nw = maxOf(1, (img.w * s).toInt()); nh = maxOf(1, (img.h * s).toInt())
        }
        if (nw == img.w && nh == img.h) return img
        val src = Bitmap.createBitmap(img.px, img.w, img.h, Bitmap.Config.ARGB_8888)
        val dst = Bitmap.createScaledBitmap(src, nw, nh, true)
        val px = IntArray(nw * nh)
        dst.getPixels(px, 0, nw, 0, 0, nw, nh)
        if (dst !== src) dst.recycle()
        src.recycle()
        return Img(nw, nh, px)
    }

    private fun opaque(px: IntArray): Boolean { for (v in px) if ((v ushr 24) != 255) return false; return true }

    /** ddsMode: null = авто (DXT5 якщо є прозорість, інакше DXT1), true = примусово DXT5, false = примусово DXT1 (прозорість тоді губиться). */
    fun encode(img: Img, fmt: String, ddsMode: Boolean? = null): ByteArray = when (fmt) {
        "PNG" -> if (opaque(img.px)) bitmapBytes(img, Bitmap.CompressFormat.PNG, 100, false) else ImgFix.png(if (ImgFix.fixHalo) ImgFix.bleed(img.px, img.w, img.h) else img.px, img.w, img.h)
        "JPG" -> bitmapBytes(img, Bitmap.CompressFormat.JPEG, 92, false)
        "TGA" -> tga(img)
        "DDS" -> dds(img, ddsMode)
        "AST" -> Gs2d.encode(img.px, img.w, img.h, null)
        else -> throw IllegalArgumentException(fmt)
    }

    private fun bitmapBytes(img: Img, f: Bitmap.CompressFormat, q: Int, alpha: Boolean): ByteArray {
        val b = Bitmap.createBitmap(img.px, img.w, img.h, Bitmap.Config.ARGB_8888)
        b.setHasAlpha(alpha)
        val o = ByteArrayOutputStream()
        b.compress(f, q, o)
        b.recycle()
        return o.toByteArray()
    }

    private fun tga(img: Img): ByteArray {
        val out = ByteArray(18 + img.w * img.h * 4)
        out[2] = 2
        out[12] = (img.w and 255).toByte(); out[13] = (img.w shr 8).toByte()
        out[14] = (img.h and 255).toByte(); out[15] = (img.h shr 8).toByte()
        out[16] = 32; out[17] = 0x28
        var o = 18
        for (v in img.px) {
            out[o++] = v.toByte(); out[o++] = (v shr 8).toByte(); out[o++] = (v shr 16).toByte(); out[o++] = (v ushr 24).toByte()
        }
        return out
    }

    private fun le(o: ByteArray, off: Int, v: Int) {
        o[off] = v.toByte(); o[off + 1] = (v shr 8).toByte(); o[off + 2] = (v shr 16).toByte(); o[off + 3] = (v ushr 24).toByte()
    }

    private fun half(i: Img): Img {
        val nw = maxOf(1, i.w / 2); val nh = maxOf(1, i.h / 2)
        val px = IntArray(nw * nh)
        for (y in 0 until nh) for (x in 0 until nw) {
            var a = 0; var r = 0; var g = 0; var b = 0
            for (dy in 0..1) for (dx in 0..1) {
                val v = i.px[minOf(i.h - 1, y * 2 + dy) * i.w + minOf(i.w - 1, x * 2 + dx)]
                a += v ushr 24; r += (v shr 16) and 255; g += (v shr 8) and 255; b += v and 255
            }
            px[y * nw + x] = ((a / 4) shl 24) or ((r / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
        }
        return Img(nw, nh, px)
    }

    private fun dds(img0: Img, forceAlpha: Boolean? = null): ByteArray {
        val alpha = forceAlpha ?: !opaque(img0.px)
        // колір під прозорими пікселями (інакше чорні ореоли навколо літер/написів)
        val img = if (ImgFix.fixHalo && alpha && !opaque(img0.px)) Img(img0.w, img0.h, ImgFix.bleed(img0.px, img0.w, img0.h)) else img0
        val levels = ArrayList<Img>()
        var cur = img
        levels.add(cur)
        while (cur.w > 1 || cur.h > 1) { cur = half(cur); levels.add(cur) }
        val bs = if (alpha) 16 else 8
        fun sz(i: Img) = ((i.w + 3) / 4) * ((i.h + 3) / 4) * bs
        val total = levels.sumOf { sz(it) }
        val out = ByteArray(128 + total)
        le(out, 0, 0x20534444); le(out, 4, 124); le(out, 8, 0xA1007)
        le(out, 12, img.h); le(out, 16, img.w); le(out, 20, sz(img)); le(out, 28, levels.size)
        le(out, 76, 32); le(out, 80, 4)
        val fc = if (alpha) "DXT5" else "DXT1"
        for (k in 0..3) out[84 + k] = fc[k].code.toByte()
        le(out, 108, 0x1000 or (if (levels.size > 1) 0x400008 else 0))
        var p = 128
        for (l in levels) p = encodeLevel(l, alpha, out, p)
        return out
    }

    private fun encodeLevel(l: Img, alpha: Boolean, out: ByteArray, start: Int): Int {
        var p = start
        val blk = IntArray(16)
        for (by in 0 until (l.h + 3) / 4) for (bx in 0 until (l.w + 3) / 4) {
            for (j in 0 until 4) for (i in 0 until 4) {
                blk[j * 4 + i] = l.px[minOf(l.h - 1, by * 4 + j) * l.w + minOf(l.w - 1, bx * 4 + i)]
            }
            if (alpha) { alphaBlock(blk, out, p); p += 8 }
            colorBlock(blk, out, p); p += 8
        }
        return p
    }

    private fun alphaBlock(blk: IntArray, out: ByteArray, o: Int) {
        var mn = 255; var mx = 0
        for (v in blk) { val a = v ushr 24; if (a < mn) mn = a; if (a > mx) mx = a }
        out[o] = mx.toByte(); out[o + 1] = mn.toByte()
        if (mx == mn) { for (k in 2..7) out[o + k] = 0; return }
        val t = IntArray(8); t[0] = mx; t[1] = mn
        for (i in 1..6) t[i + 1] = ((7 - i) * mx + i * mn) / 7
        var bits = 0L
        for (i in 0 until 16) {
            val a = blk[i] ushr 24
            var best = 0; var bd = 1000
            for (k in 0 until 8) { val d = Math.abs(t[k] - a); if (d < bd) { bd = d; best = k } }
            bits = bits or (best.toLong() shl (3 * i))
        }
        for (k in 0 until 6) out[o + 2 + k] = ((bits shr (8 * k)) and 255L).toByte()
    }

    private fun colorBlock(blk: IntArray, out: ByteArray, o: Int) {
        var minR = 255; var minG = 255; var minB = 255; var maxR = 0; var maxG = 0; var maxB = 0
        for (v in blk) {
            val r = (v shr 16) and 255; val g = (v shr 8) and 255; val b = v and 255
            if (r < minR) minR = r; if (g < minG) minG = g; if (b < minB) minB = b
            if (r > maxR) maxR = r; if (g > maxG) maxG = g; if (b > maxB) maxB = b
        }
        fun q(r: Int, g: Int, b: Int) = (((r * 31 + 127) / 255) shl 11) or (((g * 63 + 127) / 255) shl 5) or ((b * 31 + 127) / 255)
        var c0 = q(maxR, maxG, maxB); var c1 = q(minR, minG, minB)
        if (c0 < c1) { val t = c0; c0 = c1; c1 = t }
        out[o] = c0.toByte(); out[o + 1] = (c0 shr 8).toByte(); out[o + 2] = c1.toByte(); out[o + 3] = (c1 shr 8).toByte()
        if (c0 == c1) { for (k in 4..7) out[o + k] = 0; return }
        fun ex(c: Int) = intArrayOf(((c shr 11) and 31) * 255 / 31, ((c shr 5) and 63) * 255 / 63, (c and 31) * 255 / 31)
        val a = ex(c0); val b = ex(c1)
        val pal = arrayOf(a, b,
            intArrayOf((2 * a[0] + b[0]) / 3, (2 * a[1] + b[1]) / 3, (2 * a[2] + b[2]) / 3),
            intArrayOf((a[0] + 2 * b[0]) / 3, (a[1] + 2 * b[1]) / 3, (a[2] + 2 * b[2]) / 3))
        var bits = 0
        for (i in 0 until 16) {
            val r = (blk[i] shr 16) and 255; val g = (blk[i] shr 8) and 255; val bl = blk[i] and 255
            var best = 0; var bd = Int.MAX_VALUE
            for (k in 0 until 4) {
                val dr = pal[k][0] - r; val dg = pal[k][1] - g; val db = pal[k][2] - bl
                val d = dr * dr + dg * dg + db * db
                if (d < bd) { bd = d; best = k }
            }
            bits = bits or (best shl (2 * i))
        }
        le(out, o + 4, bits)
    }
}

/** Розкидає вибрані файли по відсутніх шляхах результату (за назвою файлу, з перетворенням формату). */
fun distribute(ctx: Context, uris: List<Uri>, zip: File, rep: ConvertReport, maxTex: Int): String {
    val tmpDir = File(zip.parentFile, ".dist").also { it.mkdirs() }
    val adds = LinkedHashMap<String, File>()
    val unmatched = ArrayList<String>()
    val miss = rep.missing.keys.toList()
    for (u in uris) {
        val name = Fs.displayName(ctx, u)
        val base = name.substringBeforeLast('.').lowercase()
        val targets = miss.filter { it !in adds && it.substringAfterLast('/').substringBeforeLast('.').lowercase() == base }
        if (targets.isEmpty()) { unmatched += name; continue }
        val bytes = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
        for (t in targets) {
            val ext = t.substringAfterLast('.', "").lowercase()
            val f = File(tmpDir, "d_${adds.size}.bin")
            try {
                if (ext == "png" || ext == "dds" || ext == "jpg" || ext == "tga" || ext == "ast") {
                    val img = ImageTools.load(bytes, name) ?: throw IOException(tr("не зображення", "не изображение"))
                    val r = ImageTools.resize(img, if (maxTex > 0 && maxOf(img.w, img.h) > maxTex) maxTex else 0, false)
                    f.writeBytes(ImageTools.encode(r, ext.uppercase()))
                } else f.writeBytes(bytes)
                adds[t] = f
            } catch (e: Exception) { unmatched += "$name (${e.message})" }
        }
    }
    if (adds.isNotEmpty()) {
        ZipTools.addMany(zip, adds)
        adds.keys.forEach { rep.missing.remove(it); rep.changes += tr("Додано вручну: $it", "Добавлено вручную: $it") }
    }
    tmpDir.deleteRecursively()
    Session.reportText = rep.render(); Session.rev++
    return "✔ " + tr("Розкладено файлів: ${adds.size}", "Разложено файлов: ${adds.size}") +
        (if (unmatched.isNotEmpty()) "\n" + tr("Не підійшли: ", "Не подошли: ") + unmatched.joinToString(", ") else "")
}

/** Рекурсивно збирає файли вибраної папки (SAF) як (відносний шлях, uri). */
private fun walkTree(ctx: Context, tree: Uri): List<Pair<String, Uri>> {
    val out = ArrayList<Pair<String, Uri>>()
    fun rec(docId: String, path: String) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        ctx.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0); val nm = c.getString(1) ?: continue; val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) rec(id, "$path$nm/") else out += (path + nm) to DocumentsContract.buildDocumentUriUsingTree(tree, id)
            }
        }
    }
    rec(DocumentsContract.getTreeDocumentId(tree), "")
    return out
}

private val TEX_EXT = setOf("png", "dds", "jpg", "jpeg", "tga", "ast")

private fun normExt(name: String): String = name.substringAfterLast('.', "").lowercase().let { if (it == "jpeg") "jpg" else it }

/** Чи підходить файл під вибір «З»: ALL = будь-яка текстура, інакше лише цей формат. */
private fun fromMatches(name: String, from: String): Boolean = if (from == "ALL") normExt(name) in TEX_EXT.map { if (it == "jpeg") "jpg" else it } else normExt(name) == from.lowercase()

/** Пакетно перетворює всі текстури з ZIP або папки у вибраний формат; решта файлів копіюється без змін. Результат — ZIP. */
private fun batchTextures(
    ctx: Context, zipUri: Uri?, treeUri: Uri?, from: String, fmt: String, ddsMode: Boolean?, size: Int, square: Boolean, level: Int,
    progress: (String, Float) -> Unit
): String {
    val label = (if (zipUri != null) Fs.displayName(ctx, zipUri).substringBeforeLast('.') else "folder").ifEmpty { "textures" }
    val outZip = File(Fs.work(ctx), "${label}_$fmt.zip")
    outZip.delete()
    var ok = 0; var copied = 0
    val errs = StringBuilder()
    val items = ArrayList<Pair<String, () -> ByteArray>>()
    var zf: java.util.zip.ZipFile? = null
    var tmpZip: File? = null
    try {
        if (zipUri != null) {
            tmpZip = File(Fs.work(ctx), "batch_src.zip"); Fs.copyUri(ctx, zipUri, tmpZip)
            val z = java.util.zip.ZipFile(tmpZip); zf = z
            val en = z.entries()
            while (en.hasMoreElements()) { val e = en.nextElement(); if (!e.isDirectory) items += e.name to { z.getInputStream(e).use { it.readBytes() } } }
        } else if (treeUri != null) {
            for ((p, u) in walkTree(ctx, treeUri)) items += p to { ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() } }
        }
        java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(java.io.FileOutputStream(outZip), 1 shl 16)).use { zo ->
            for ((i, item) in items.withIndex()) {
                val (name, read) = item
                progress(name, i / items.size.coerceAtLeast(1).toFloat())
                val ext = name.substringAfterLast('.', "").lowercase()
                try {
                    val bytes = read()
                    if (ext in TEX_EXT && fromMatches(name, from) && (normExt(name) != fmt.lowercase() || size != 0)) {
                        val img = ImageTools.load(bytes, name) ?: throw IOException(tr("не вдалося прочитати зображення", "не удалось прочитать изображение"))
                        val out = ImageTools.encode(ImageTools.fit(img, size, square, level, name), fmt, ddsMode)
                        zo.putNextEntry(java.util.zip.ZipEntry(name.substringBeforeLast('.') + "." + fmt.lowercase())); zo.write(out); zo.closeEntry(); ok++
                    } else {
                        zo.putNextEntry(java.util.zip.ZipEntry(name)); zo.write(bytes); zo.closeEntry(); copied++
                    }
                } catch (e: Throwable) { errs.appendLine("$name: ${e.message}") }
            }
        }
        Fs.publish(ctx, outZip, "application/zip", "converted")
    } finally { try { zf?.close() } catch (_: Exception) {}; tmpZip?.delete(); outZip.delete() }
    return "✔ " + tr("Текстур перетворено: $ok, інших файлів скопійовано: $copied → Download/DON1500/converted/${label}_$fmt.zip", "Текстур преобразовано: $ok, других файлов скопировано: $copied → Download/DON1500/converted/${label}_$fmt.zip") + "\n$errs"
}

@Composable
fun ImagesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uris by remember { mutableStateOf(listOf<Uri>()) }
    var fmt by remember { mutableStateOf("PNG") }
    var from by remember { mutableStateOf("ALL") }
    var level by remember { mutableStateOf(1) }
    var halo by remember { mutableStateOf(false) }
    var ddsMode by remember { mutableStateOf<Boolean?>(null) }
    var size by remember { mutableStateOf(1024) }
    var square by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var cur by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var zipUri by remember { mutableStateOf<Uri?>(null) }
    var treeUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l -> uris = l; zipUri = null; treeUri = null }
    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { zipUri = u; treeUri = null; uris = emptyList() } }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) { treeUri = u; zipUri = null; uris = emptyList() } }
    Frame(tr("Конвертер зображень", "Конвертер изображений"), onBack) {
        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text(tr("Вибрати зображення (одне чи кілька)", "Выбрать изображения (одно или несколько)")) }
            Row(Modifier.padding(top = 4.dp)) {
                OutlinedButton(onClick = { zipPicker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text(tr("ZIP з текстурами", "ZIP с текстурами"), fontSize = 12.sp) }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { treePicker.launch(null) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text(tr("Вибрати папку", "Выбрать папку"), fontSize = 12.sp) }
            }
            Text(
                when {
                    zipUri != null -> tr("Вибрано ZIP: ", "Выбран ZIP: ") + Fs.displayName(ctx, zipUri!!)
                    treeUri != null -> tr("Вибрано папку (усі вкладені текстури)", "Выбрана папка (все вложенные текстуры)")
                    else -> tr("Вибрано: ${uris.size}", "Выбрано: ${uris.size}")
                }, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            InfoHint(tr("Читання: PNG, JPG, WEBP, BMP, DDS, AST. Запис: PNG, DDS, JPG, TGA, AST. З ZIP чи папки всі текстури перетворюються у вибраний формат (зі збереженням підпапок), решта файлів копіюється як є; результат — один ZIP.", "Чтение: PNG, JPG, WEBP, BMP, DDS, AST. Запись: PNG, DDS, JPG, TGA, AST. Из ZIP или папки все текстуры преобразуются в выбранный формат (с сохранением подпапок), остальные файлы копируются как есть; результат — один ZIP."))
            Text(tr("З якого формату (З)", "Из какого формата (ИЗ)"), fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                listOf("ALL" to tr("Усі", "Все"), "PNG" to "PNG", "DDS" to "DDS", "AST" to "AST", "JPG" to "JPG", "TGA" to "TGA").forEach { (v, l) ->
                    FilterChip(from == v, { from = v }, { Text(l) }); Spacer(Modifier.width(6.dp))
                }
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                Text(tr("У який формат (В)", "В какой формат (В)"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { if (from != "ALL") { val t = from; from = fmt; fmt = t } }, enabled = from != "ALL" && !busy) { Text("⇄ " + tr("поміняти", "поменять"), fontSize = 12.sp) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                listOf("PNG", "DDS", "AST", "JPG", "TGA").forEach { f -> FilterChip(fmt == f, { fmt = f }, { Text(f) }); Spacer(Modifier.width(6.dp)) }
            }
            Text(tr("Буде: ${if (from == "ALL") "усі текстури" else from} → $fmt", "Будет: ${if (from == "ALL") "все текстуры" else from} → $fmt"), fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
            if (fmt == "DDS") {
                Text(tr("Стиснення DDS", "Сжатие DDS"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                Row {
                    FilterChip(ddsMode == null, { ddsMode = null }, { Text(tr("Авто", "Авто")) }); Spacer(Modifier.width(6.dp))
                    FilterChip(ddsMode == false, { ddsMode = false }, { Text("DXT1") }); Spacer(Modifier.width(6.dp))
                    FilterChip(ddsMode == true, { ddsMode = true }, { Text("DXT5") })
                }
                Text(tr("DXT1 — без прозорості, вдвічі легший. DXT5 — зберігає прозорість. Авто сам вибирає за наявністю альфа-каналу.", "DXT1 — без прозрачности, вдвое легче. DXT5 — сохраняет прозрачность. Авто сам выбирает по наличию альфа-канала."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(tr("Розмір", "Размер"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) { listOf(-2 to tr("Авто-стиснення", "Авто-сжатие"), 0 to tr("Оригінал", "Оригинал"), 32 to "32", 64 to "64", 128 to "128", 256 to "256", 512 to "512", 1024 to "1024", 2048 to "2048", 4096 to "4096").forEach { (v, l) -> FilterChip(size == v, { size = v }, { Text(l, fontSize = 12.sp) }); Spacer(Modifier.width(4.dp)) } }
            if (size == -2) {
                Text(tr("Сила стиснення", "Сила сжатия"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                Row { listOf(0 to tr("Максимум", "Максимум"), 1 to tr("Баланс", "Баланс"), 2 to tr("Якість", "Качество")).forEach { (v, l) -> FilterChip(level == v, { level = v }, { Text(l, fontSize = 12.sp) }); Spacer(Modifier.width(6.dp)) } }
                InfoHint(tr("Програма сама добирає розмір кожної текстури: що менше деталей — то сильніше стискає. Нормалі (normal, _n) стискаються обережніше.", "Программа сама подбирает размер каждой текстуры: чем меньше деталей — тем сильнее сжимает. Нормали (normal, _n) сжимаются осторожнее."))
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(tr("Прибирати чорні ореоли (лише для прозорих наклейок)", "Убирать чёрные ореолы (только для прозрачных наклеек)"), Modifier.weight(1f), fontSize = 13.sp)
                Switch(halo, { halo = it })
            }
            InfoHint(tr("Вмикай, якщо навколо літер видно темну облямівку. Не вмикай для табличок і текстур, де прозорість не використовується (чорне тло може стати світлим).", "Включай, если вокруг букв видна тёмная кайма. Не включай для табличек и текстур, где прозрачность не используется (чёрный фон может стать светлым)."))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(tr("Робити квадрат (128×128, 256×256, 512×512…), розтягуючи", "Делать квадрат (512×512, 1024×1024…), растягивая"), Modifier.weight(1f), fontSize = 13.sp)
                Switch(square, { square = it })
            }
            InfoHint(tr("DDS записується як DXT1 (без прозорості) або DXT5 (з прозорістю), з мипмапами. AST — ASTC 6×6 з мипмапами у контейнері GS2D (FS26 Mobile); кодування великих текстур (4096) займає десятки секунд.", "DDS записывается как DXT1 (без прозрачности) или DXT5 (с прозрачностью), с мипмапами. AST — ASTC 6×6 с мипмапами в контейнере GS2D (FS26 Mobile); кодирование больших текстур (4096) занимает десятки секунд."))
            Button(enabled = (uris.isNotEmpty() || zipUri != null || treeUri != null) && !busy, modifier = Modifier.padding(top = 8.dp), onClick = {
                scope.launch {
                    busy = true; msg = ""; prog = 0f
                    ImgFix.fixHalo = halo
                    msg = withContext(Dispatchers.IO) {
                        if (zipUri != null || treeUri != null) {
                            return@withContext try { batchTextures(ctx, zipUri, treeUri, from, fmt, ddsMode, size, square, level) { n, p -> cur = n; prog = p } }
                            catch (e: Throwable) { "✖ ${e.message}" }
                        }
                        var ok = 0; var skipped = 0
                        val errs = StringBuilder()
                        for ((i, u) in uris.withIndex()) {
                            prog = i / uris.size.toFloat()
                            val name = Fs.displayName(ctx, u); cur = name
                            if (!fromMatches(name, from)) { skipped++; continue }
                            try {
                                val bytes = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
                                val img = ImageTools.load(bytes, name) ?: throw IOException(tr("не вдалося прочитати зображення", "не удалось прочитать изображение"))
                                val out = ImageTools.encode(ImageTools.fit(img, size, square, level, name), fmt, ddsMode)
                                val f = File(Fs.work(ctx), name.substringBeforeLast('.') + "." + fmt.lowercase())
                                f.writeBytes(out)
                                Fs.publish(ctx, f, "application/octet-stream", "converted")
                                ok++
                            } catch (e: Throwable) { errs.appendLine("$name: ${e.message}") }
                        }
                        "✔ $ok / ${uris.size} → Download/DON1500/converted" + (if (skipped > 0) "\n" + tr("Пропущено (не $from): $skipped", "Пропущено (не $from): $skipped") else "") + "\n$errs"
                    }
                    busy = false
                }
            }) { Text(tr("Конвертувати", "Конвертировать")) }
            if (busy) { LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)); Text("${(prog * 100).toInt()}% · $cur", fontSize = 12.sp) }
            if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
        }
    }
}
