package com.don1500.converter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Універсальні виправлення XML модів для FS26 Mobile (за повідомленнями з реального логу гри). Без залежностей від Android. */
public final class ModFix {
    private ModFix() {}

    public static final class Result {
        public final String text; public final int count;
        Result(String text, int count) { this.text = text; this.count = count; }
    }

    private static final Pattern FOLDABLE = Pattern.compile("<foldable\\b[^>]*>(.*?)</foldable>", Pattern.DOTALL);

    /**
     * «'vehicle.foldable.foldingParts' is not supported anymore»: старий вигляд
     * &lt;foldable&gt;&lt;foldingParts&gt;…&lt;/foldingParts&gt;&lt;/foldable&gt; загортається в foldingConfigurations/foldingConfiguration.
     */
    public static Result fixFolding(String xml) {
        Matcher m = FOLDABLE.matcher(xml);
        StringBuilder sb = new StringBuilder(); int last = 0, n = 0;
        while (m.find()) {
            String inner = m.group(1);
            if (inner.contains("<foldingConfigurations") || !inner.contains("<foldingParts")) continue;
            int a = inner.indexOf("<foldingParts");
            int endTag = inner.lastIndexOf("</foldingParts>");
            int b;
            if (endTag >= 0) b = endTag + "</foldingParts>".length();
            else { int e = inner.indexOf("/>", a); if (e < 0) continue; b = e + 2; }
            // самозакрита <foldingParts .../> — теж підтримуємо
            String block = inner.substring(a, b);
            String wrapped = "<foldingConfigurations>\n            <foldingConfiguration>\n                " + block + "\n            </foldingConfiguration>\n        </foldingConfigurations>";
            String newInner = inner.substring(0, a) + wrapped + inner.substring(b);
            int s = m.start(1), e2 = m.end(1);
            sb.append(xml, last, s).append(newInner); last = e2; n++;
        }
        if (n == 0) return new Result(xml, 0);
        sb.append(xml, last, xml.length());
        return new Result(sb.toString(), n);
    }

    private static final Pattern DASHBOARD_FONT = Pattern.compile("\\s+font=\"DIGIT_BOLD\"");

    /** «Unknown font 'DIGIT_BOLD'»: такого шрифту в FS26 Mobile немає — прибираємо атрибут (діє шрифт за замовчуванням). */
    public static Result fixFonts(String xml) {
        Matcher m = DASHBOARD_FONT.matcher(xml);
        int n = 0; while (m.find()) n++;
        return n == 0 ? new Result(xml, 0) : new Result(DASHBOARD_FONT.matcher(xml).replaceAll(""), n);
    }

    private static final Pattern TYPE = Pattern.compile("<type\\b[^>]*>.*?</type>", Pattern.DOTALL);
    private static final Pattern SPEC = Pattern.compile("[ \\t]*<specialization\\s+name=\"([^\"]+)\"\\s*/>[ \\t]*\\r?\\n?");

    /**
     * «Specialization 'attacherJoints' already exists for vehicle type …»: власні типи техніки в modDesc повторюють специфікації,
     * які вже є в батьківському типі (підтверджено логом гри: baseTipper уже містить attacherJoints), або дублюють одна одну.
     */
    public static Result fixVehicleTypes(String modDesc) {
        Matcher m = TYPE.matcher(modDesc);
        StringBuilder sb = new StringBuilder(); int last = 0, n = 0;
        while (m.find()) {
            String block = m.group();
            String parent = attr(block, "parent");
            java.util.Set<String> inherited = new java.util.HashSet<>();
            if ("baseTipper".equals(parent)) inherited.add("attacherJoints");
            Matcher sm = SPEC.matcher(block);
            StringBuilder nb = new StringBuilder(); int l2 = 0; int removed = 0;
            java.util.Set<String> seen = new java.util.HashSet<>();
            while (sm.find()) {
                String name = sm.group(1);
                if (inherited.contains(name) || !seen.add(name)) { nb.append(block, l2, sm.start()); l2 = sm.end(); removed++; }
            }
            if (removed == 0) continue;
            nb.append(block, l2, block.length());
            sb.append(modDesc, last, m.start()).append(nb); last = m.end(); n += removed;
        }
        if (n == 0) return new Result(modDesc, 0);
        sb.append(modDesc, last, modDesc.length());
        return new Result(sb.toString(), n);
    }

    private static String attr(String tagBlock, String name) {
        int end = tagBlock.indexOf('>');
        Matcher m = Pattern.compile("\\b" + name + "=\"([^\"]*)\"").matcher(tagBlock.substring(0, Math.max(0, end)));
        return m.find() ? m.group(1) : "";
    }
}
