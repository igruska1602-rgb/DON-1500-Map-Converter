package com.don1500.converter

import java.io.*
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.util.zip.*

data class Issue(val level: String, val file: String, val msg: String)
class Options(
    val renameFs: Boolean, val trimLang: Boolean, val maxTex: Int = 0,
    val target: String = "FS26", val donors: List<File> = emptyList(), val donorByName: Boolean = true,
    val signNick: String = "", val signEnabled: Boolean = false,
    /** Формат текстур у результаті: PNG (як раніше), AST (FS26 Mobile) або DDS. */
    val texFmt: String = "PNG",
    /** Які текстури міняти: ALL, PNG, DDS або AST. */
    val texFrom: String = "ALL",
    /** Перетворювати й іконки (файли з «icon» у назві). */
    val texIcons: Boolean = false,
    /** Сила авто-стиснення (maxTex = -2): 0 максимум, 1 баланс, 2 якість. */
    val texLevel: Int = 1,
    /** Прибирати темні ореоли навколо літер (затікання кольору під прозорі пікселі). */
    val texHalo: Boolean = false,
    /** Режим «Виправити мод»: універсальні виправлення (ModFix) без правил FS25→FS26. Текстури міняються лише якщо texFmt != "KEEP" ("KEEP" = не чіпати). */
    val fixOnly: Boolean = false
)

class ConvertReport {
    var sourceName = ""
    var outName = ""
    var type = ""
    var analyzeOnly = false
    var entries = 0
    var textureRewrites = 0
    var ddsConverted = 0
    var verified = false
    var cancelled = false
    var savedTo = ""
    val changes = mutableListOf<String>()
    val issues = mutableListOf<Issue>()
    val missing = linkedMapOf<String, String>() // шлях -> звідки згадується
    val missingData = linkedMapOf<String, String>() // \$data-посилання, яких немає в донорі

    val errors get() = issues.count { it.level == "ERROR" }
    val warnings get() = issues.count { it.level == "WARN" }
    val critical get() = errors > 0 || missing.isNotEmpty()

    private fun cat(p: String): String = when (p.substringAfterLast('.', "").lowercase()) {
        "png", "dds", "jpg", "jpeg", "tga" -> tr("Текстури", "Текстуры")
        "i3d", "shapes" -> tr("Моделі", "Модели")
        "xml" -> tr("Конфігурації XML", "Конфигурации XML")
        "ogg", "wav", "mp3" -> tr("Звуки", "Звуки")
        else -> tr("Інше", "Прочее")
    }

    fun render(): String = buildString {
        appendLine("DON-1500 Converter — " + tr("ЗВІТ", "ОТЧЁТ"))
        appendLine(tr("Джерело", "Источник") + ": $sourceName")
        if (!analyzeOnly) appendLine(tr("Результат", "Результат") + ": $outName")
        appendLine(tr("Тип", "Тип") + ": $type")
        appendLine(tr("Файлів в архіві", "Файлов в архиве") + ": $entries")
        appendLine()
        when {
            cancelled -> appendLine(tr("⛔ Конвертацію скасовано.", "⛔ Конвертация отменена."))
            analyzeOnly && critical -> appendLine(tr("⚠ Лише аналіз (файли не змінювались). Знайдено проблеми: помилок $errors, відсутніх файлів ${missing.size}.", "⚠ Только анализ (файлы не менялись). Найдены проблемы: ошибок $errors, отсутствующих файлов ${missing.size}."))
            analyzeOnly -> appendLine(tr("✔ Лише аналіз. Критичних проблем не знайдено.", "✔ Только анализ. Критичных проблем не найдено."))
            critical -> appendLine(tr("✖ Є критичні проблеми: помилок $errors, відсутніх файлів ${missing.size}. Мод НЕ можна вважати готовим.", "✖ Есть критичные проблемы: ошибок $errors, отсутствующих файлов ${missing.size}. Мод НЕЛЬЗЯ считать готовым."))
            else -> appendLine(tr("✔ Критичних помилок не знайдено. Архів перевірено на цілісність${if (verified) "" else " (перевірка не виконана)"}.", "✔ Критичных ошибок не найдено. Архив проверен на целостность${if (verified) "" else " (проверка не выполнена)"}."))
        }
        appendLine(tr("Сумісність у грі FS26 Mobile цим звітом НЕ підтверджується — перевірте в грі й надішліть log.txt.", "Совместимость в игре FS26 Mobile этим отчётом НЕ подтверждается — проверьте в игре и пришлите log.txt."))
        if (savedTo.isNotEmpty()) appendLine(tr("Збережено", "Сохранено") + ": $savedTo")
        appendLine()
        appendLine(tr("Змінено: рядків-посилань на текстури $textureRewrites, DDS→PNG: $ddsConverted", "Изменено: ссылок на текстуры $textureRewrites, DDS→PNG: $ddsConverted"))
        appendLine("=== " + tr("ЗМІНИ", "ИЗМЕНЕНИЯ") + " (${changes.size}) ===")
        changes.take(150).forEach { appendLine("• $it") }
        if (changes.size > 150) appendLine("… +${changes.size - 150}")
        appendLine()
        appendLine("=== " + tr("ВІДСУТНІ ФАЙЛИ", "ОТСУТСТВУЮЩИЕ ФАЙЛЫ") + " (${missing.size}) ===")
        missing.entries.groupBy { cat(it.key) }.forEach { (c, list) ->
            appendLine("[$c] ${list.size}")
            list.take(60).forEach { appendLine("  ${it.key}  ← ${it.value}") }
            if (list.size > 60) appendLine("  … +${list.size - 60}")
        }
        appendLine()
        run {
            val src = (if (Donor.count > 0) Donor.name + ", " else "") + tr("вбудована база (${KnownFiles.count})", "встроенная база (${KnownFiles.count})")
            appendLine("=== " + tr("НЕ ЗНАЙДЕНО У ГРІ (\$data/…)", "НЕ НАЙДЕНО В ИГРЕ (\$data/…)") + " (${missingData.size}) — $src ===")
            if (missingData.isEmpty()) appendLine(tr("Усі посилання \$data/… підтверджено (донор і/або вбудована база).", "Все ссылки \$data/… подтверждены (донор и/или встроенная база)."))
            missingData.entries.take(80).forEach { appendLine("  ${it.key}  ← ${it.value}") }
            if (missingData.size > 80) appendLine("  … +${missingData.size - 80}")
        }
        appendLine()
        appendLine("=== " + tr("ПОПЕРЕДЖЕННЯ ТА ПОМИЛКИ", "ПРЕДУПРЕЖДЕНИЯ И ОШИБКИ") + " (${issues.size}) ===")
        issues.take(150).forEach { appendLine("[${it.level}] ${it.file}: ${it.msg}") }
        if (issues.size > 150) appendLine("… +${issues.size - 150}")
    }
}

object Converter {
    /** Експеримент FS23→FS26: додавати detail-maps (Custommap detailDiffuse/Normal/Specular) матеріалам i3d, що прийшли з FS23. У грі не перевірено. */
    @JvmField var detailMaps: Boolean = false
    private const val MAX_TEXT = 150L * 1024 * 1024
    private val ddsRe = Regex("\\.dds(?=[\"'<])", RegexOption.IGNORE_CASE)
    private val texExtRe = Regex("\\.(dds|png|ast)(?=[\"'<])", RegexOption.IGNORE_CASE)

    /** Яким має стати розширення текстури з розширенням ext (null — не чіпаємо). Єдине правило і для файлів, і для посилань. */
    private fun fileTarget(ext: String, iconRaw: Boolean, opt: Options, dataLayer: Boolean = false): String? {
        if (opt.texFmt == "KEEP") return null
        // Шари даних карти (висоти, ваги, infoLayer, щільності) — НЕ текстури: ніколи не в AST і не стискати (інакше гра: «Failed to load height map»).
        if (dataLayer) return if (ext == "dds" && (opt.target == "FS26" || opt.target == "FS23")) "png" else null
        val icon = iconRaw && !opt.texIcons
        val sel = opt.texFrom == "ALL" || opt.texFrom.equals(ext, true)
        val legacy = if (ext == "dds" && (opt.target == "FS26" || opt.target == "FS23")) "png" else null
        return when (opt.texFmt) {
            "AST", "ASTP" -> if (opt.target == "FS26" && !icon && sel && (ext == "png" || ext == "dds")) "ast" else legacy
            "DDS" -> if (!icon && sel && (ext == "png" || ext == "ast")) "dds" else null
            else -> if (ext == "ast" && sel) "png" else legacy
        }
    }

    private fun isIconName(rel: String) = rel.substringAfterLast('/').lowercase().contains("icon")
    private val dataLayerRe = Regex("(?i)(_dem|_weight|infolayer|densitymap)")
    private fun isDataLayer(rel: String) = dataLayerRe.containsMatchIn(rel.substringAfterLast('/'))

    /** Лінійний пошук (без «ледачих» регулярок: на величезних i3d карт вони можуть працювати практично нескінченно). */
    private fun rewriteTexRefs(t: String, opt: Options, rep: ConvertReport, rel: String): String {
        if (opt.texFmt == "KEEP") return t
        if (!t.contains(".dds", true) && !t.contains(".png", true) && !t.contains(".ast", true)) return t
        var n = 0
        val sb = StringBuilder(t.length + 64)
        var last = 0
        for (m in texExtRe.findAll(t)) {
            val i = m.range.first
            var st = i
            while (st > 0 && i - st < 600) { val c = t[st - 1]; if (c == '"' || c == '\'' || c == '<' || c == '>') break; st-- }
            val p = t.substring(st, i)
            val e = m.groupValues[1].lowercase()
            // ASTP: файли стають .ast, а посилання в xml/i3d лишаються .png (як у справжніх файлах FS26)
            val nt = if (opt.texFmt == "ASTP") (if (e == "dds" && (opt.target == "FS26" || opt.target == "FS23")) "png" else null) else fileTarget(e, isIconName(p), opt, isDataLayer(p))
            val isData = p.startsWith("\$data", true)
            if (nt == null || nt == e || (isData && !(e == "dds" && nt == "png"))) continue
            sb.append(t, last, i).append('.').append(nt); last = m.range.last + 1; n++
        }
        if (n == 0) return t
        sb.append(t, last, t.length)
        rep.textureRewrites += n; rep.changes += tr("$rel: посилань на текстури змінено: $n", "$rel: ссылок на текстуры изменено: $n")
        return sb.toString()
    }

    private val attrRe = Regex("\\b\\w*[Ff]ilename\\s*=\\s*\"([^\"]+)\"")
    private val elemRe = Regex("<(?:filename|image|xmlFilename|iconFilename)>\\s*([^<]+?)\\s*</")

    private val tl = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "h", 'ґ' to "g", 'д' to "d", 'е' to "e", 'є' to "ye", 'ж' to "zh",
        'з' to "z", 'и' to "y", 'і' to "i", 'ї' to "yi", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n",
        'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "kh", 'ц' to "ts",
        'ч' to "ch", 'ш' to "sh", 'щ' to "shch", 'ь' to "", 'ы' to "y", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ъ' to ""
    )

    /** FS25_DON_1500.zip → FS26_DON_1500.zip; кирилицю транслітеруємо, ім'я має починатися з літери. */
    fun outputName(src: String, target: String = "FS26"): String {
        var b = src.substringBeforeLast('.')
        b = b.map { c ->
            val t = tl[c.lowercaseChar()]
            if (t == null) c.toString() else if (c.isUpperCase()) t.replaceFirstChar { it.uppercaseChar() } else t
        }.joinToString("")
        b = b.replace(Regex("[^A-Za-z0-9_]+"), "_").trim('_')
        b = b.replace(Regex("^(?i)FS(19|22|25|26|23)_?"), "").trim('_')
        if (b.isEmpty()) b = "MOD"
        if (b[0].isDigit()) b = "MOD_$b"
        return "${target}_$b.zip"
    }

    fun run(src: File, out: File?, opt: Options, isCancelled: () -> Boolean = { false }, progress: (String, Float) -> Unit): ConvertReport {
        ImgFix.fixHalo = opt.texHalo
        val rep = ConvertReport()
        rep.sourceName = src.name
        rep.analyzeOnly = out == null
        rep.outName = out?.name ?: outputName(src.name)
        val zf = try { ZipFile(src) } catch (e: Exception) {
            rep.issues += Issue("ERROR", src.name, tr("Не вдалося відкрити архів (пошкоджений або не ZIP): ${e.message}", "Не удалось открыть архив (повреждён или не ZIP): ${e.message}"))
            return rep
        }
        try { zf.use { process(it, src, out, opt, rep, isCancelled, progress) } }
        catch (e: Exception) {
            rep.issues += Issue("ERROR", src.name, tr("Збій під час обробки: ${e.message}", "Сбой при обработке: ${e.message}"))
        }
        return rep
    }

    private fun strictUtf8(b: ByteArray): String? = try {
        Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString()
    } catch (e: CharacterCodingException) { null }

    private fun isJunk(rel: String) =
        rel.startsWith("__MACOSX/") || rel.endsWith(".DS_Store") || rel.endsWith("Thumbs.db")

    private fun norm(p: String): String? {
        val st = ArrayList<String>()
        for (s in p.replace('\\', '/').split('/')) {
            when (s) { "", "." -> {}; ".." -> { if (st.isEmpty()) return null; st.removeAt(st.size - 1) }; else -> st.add(s) }
        }
        return st.joinToString("/")
    }

    fun refsIn(text: String, isXml: Boolean, includeData: Boolean = false): List<String> {
        val r = ArrayList<String>()
        attrRe.findAll(text).forEach { r += it.groupValues[1] }
        if (isXml) elemRe.findAll(text).forEach { r += it.groupValues[1] }
        return r.filter { it.isNotBlank() && !it.contains("://") && (!it.contains('$') || (includeData && it.startsWith("\$data/"))) }
    }

    private fun fixModDesc(src: String, opt: Options, rep: ConvertReport, descV: String?): String {
        var t = src
        val m = Regex("<modDesc\\b[^>]*>").find(t)
        if (m == null) {
            rep.issues += Issue("ERROR", "modDesc.xml", tr("Не знайдено тег <modDesc>", "Не найден тег <modDesc>"))
            return t
        }
        var tag = m.value
        val old = Regex("descVersion\\s*=\\s*\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
        if (opt.target == "FS26") {
            tag = Regex("\\s+(descVersion|titleId)\\s*=\\s*\"[^\"]*\"").replace(tag, "")
            tag = tag.replaceFirst("<modDesc", "<modDesc descVersion=\"2\" titleId=\"fs26mobile\"")
            t = t.replaceRange(m.range, tag)
            rep.changes += "modDesc.xml: descVersion ${old ?: "—"} → 2, titleId=\"fs26mobile\""
        } else {
            // descVersion="75" перевірено у трьох незалежних джерелах для FS23 Mobile (не з ваших
            // файлів, тому позначаємо звідки саме); донор, якщо є, має пріоритет над цим значенням.
            val use = descV ?: "75"
            if (use != old) {
                tag = Regex("\\s+descVersion\\s*=\\s*\"[^\"]*\"").replace(tag, "")
                tag = tag.replaceFirst("<modDesc", "<modDesc descVersion=\"$use\"")
                t = t.replaceRange(m.range, tag)
                val src = if (descV != null) tr("з донора FS23", "из донора FS23") else tr("перевірений гайд FS23", "проверенный гайд FS23")
                rep.changes += "modDesc.xml: descVersion ${old ?: "—"} → $use ($src)"
            }
        }
        if (opt.signEnabled && opt.signNick.isNotBlank()) t = sign(t, opt.signNick, rep)
        if (opt.renameFs) {
            val before = t
            t = Regex("(?s)<title>.*?</title>").replace(t) { it.value.replace("FS25", opt.target).replace("FS 25", "FS " + opt.target.removePrefix("FS")) }
            if (t != before) rep.changes += tr("modDesc.xml: назву в <title> FS25 → FS26", "modDesc.xml: название в <title> FS25 → FS26")
        }
        if (opt.trimLang) {
            val before = t
            t = Regex("(?s)[ \\t]*<(de|fr|es|it|pl|cz|cs|hu|nl|pt|tr|jp|kr|zh|ct|fi|da|sv|ro)>.*?</\\1>[ \\t]*\\r?\\n?").replace(t, "")
            if (t != before) rep.changes += tr("modDesc.xml: прибрано зайві мови (залишено en/ru/uk/br)", "modDesc.xml: убраны лишние языки (оставлено en/ru/uk/br)")
        }
        return t
    }

    // ===== FS23 Mobile: перевірені правила з гайдів (descVersion=75, лог-перевірені заміни для map.xml / map.i3d). =====
    // У грі є тільки data/maps/map і data/maps/mapDE — усі інші (mapUS, mapFR, mapAlpine, mapEU) замінюються на map.
    private val fs23MapFolder = Regex("(\\" + "\$data/maps/map)(?!DE)([A-Za-z]+)(/)")
    private val fs23Hotspots = Regex("(?s)<hotspots>.*?</hotspots>")
    private val fs23LicensePlates = Regex("(?m)^[ \\t]*<licensePlates\\b[^>]*/>[ \\t]*\\r?\\n?")
    private val fs23Trigger = Regex("<trigger\\s+position=\"([^\"]+)\"\\s+categoryIndex=\"(\\d+)\"\\s+pageIndex=\"\\d+\"\\s*/>")
    private val fs23NavCollision = Regex("<navigationCollision\\s+revision=\"1\"\\s*/>")
    private val fs23HelpIds = mapOf("1" to "helpLine_FirstSteps_Shop", "2" to "helpLine_ImproveYield_Fertilizing", "4" to "helpLine_CropOverview_GrapesOlives", "6" to "helpLine_Animals_General", "8" to "helpLine_FirstSteps_Farmer")
    private val fs23TerrainTex = Regex("(/textures/terrain/)([A-Za-z0-9]+?)(_(?:diffuse|normal)\\.png)")
    private val fs23TexMap = mapOf(
        "concrete01" to "asphalt01", "concrete02" to "asphalt02", "concrete03" to "asphalt03",
        "asphalt04" to "asphalt03", "dirt02" to "dirt01", "dirt03" to "dirt01", "dirt04" to "dirt01",
        "dirtDark01" to "dirt01", "forestGround01" to "dirt01", "forestGround02" to "dirt01",
        "forestGround03" to "dirt01", "forestGround04" to "dirt01", "grassDirt01" to "dirt01",
        "grass04" to "grass03", "grassDry01" to "grass03", "grassDry02" to "grass03",
        "grassDry03" to "grass03", "grassDry04" to "grass03", "grassDryPatchy" to "grass03",
        "gravel04" to "gravel03", "gravelDirt" to "gravel01", "gravelDust" to "gravel01",
        "pathway" to "gravel01", "pathwayGravel" to "gravel01", "riverBed" to "gravel01",
        "cobblestone" to "gravel01", "animalMud04" to "animalMud03", "mud01" to "animalMud03"
    )

    /** Застосовує механічні, перевірені логами гри правила FS23 Mobile до тексту одного XML/i3D файлу. */
    private fun applyFs23Rules(text: String, rel: String, rep: ConvertReport): String {
        var t = text
        var n = fs23MapFolder.findAll(t).count { it.groupValues[2] != "DE" }
        if (n > 0) { t = fs23MapFolder.replace(t) { m -> if (m.groupValues[2] == "DE") m.value else "${m.groupValues[1]}${m.groupValues[3]}" }; rep.changes += tr("$rel: шляхів \$data/maps/mapXX/ → map/: $n (FS23: mapUS/mapFR/mapAlpine у грі немає)", "$rel: путей \$data/maps/mapXX/ → map/: $n (FS23: mapUS/mapFR/mapAlpine в игре нет)") }
        if (Regex("(?i)^map[A-Za-z0-9]*\\.xml$").matches(rel.substringAfterLast('/'))) {
            val beforeH = t; t = fs23Hotspots.replace(t, "<hotspots/>")
            if (t != beforeH) rep.changes += tr("$rel: <hotspots> очищено (FS23 Mobile вимагає порожній блок)", "$rel: <hotspots> очищен (FS23 Mobile требует пустой блок)")
            val beforeL = t; t = fs23LicensePlates.replace(t, "")
            if (t != beforeL) rep.changes += tr("$rel: <licensePlates> видалено (номерних знаків у FS23 Mobile немає)", "$rel: <licensePlates> удалён (номерных знаков в FS23 Mobile нет)")
            var zc = 0
            t = fs23Trigger.replace(t) { m ->
                zc++; val pos = m.groupValues[1]; val cat = m.groupValues[2]
                val help = fs23HelpIds[cat] ?: fs23HelpIds["1"]!!
                "<zone position=\"$pos\" radius=\"50.00\" helpId=\"$help\"/>"
            }
            if (zc > 0) rep.changes += tr("$rel: <trigger> → <zone> (новий формат helpline): $zc", "$rel: <trigger> → <zone> (новый формат helpline): $zc")
            val beforeN = t; t = fs23NavCollision.replace(t, "<navigationCollision revision=\"2\"/>")
            if (t != beforeN) rep.changes += tr("$rel: navigationCollision revision 1 → 2", "$rel: navigationCollision revision 1 → 2")
        }
        var tc = 0
        t = fs23TerrainTex.replace(t) { m ->
            val repl = fs23TexMap[m.groupValues[2]]
            if (repl != null) { tc++; "${m.groupValues[1]}$repl${m.groupValues[3]}" } else m.value
        }
        if (tc > 0) rep.changes += tr("$rel: замін текстур ґрунту за таблицею FS23: $tc", "$rel: замен текстур грунта по таблице FS23: $tc")
        return t
    }

    // ===== FS26 Mobile: перевірені логами правила (гайд "FS26 Mobile: MT Manager", реальні карти). =====
    // Текстури землі в грі лежать прямо у $data/maps/textures/terrain/ (без mapEU/mapUS/mapAlpine).
    private val fs26MapTexPath = Regex("(\\" + "\$data/maps/)map(?:EU|US|Alpine|AS|FR)(/textures/)")
    private val fs26FillPlanes = Regex("\"maps/map(?:EU|US|Alpine|AS|FR)/fillPlanes/")
    private val fs26Displacement = Regex("_displacement\\.png")
    private val fs26TerrainTexName = Regex("(terrain/)([A-Za-z0-9]+?)((?:01|02|03|04)?_(?:diffuse|normal|height)\\.png)")
    // Довші назви йдуть РАНІШЕ коротших (щоб gravelPebbles не "з'їла" частина gravel) — порядок важливий.
    private val fs26TexMap = linkedMapOf(
        "dirtMud" to "dirt", "mud" to "dirt", "sand" to "dirt",
        "forestMoss" to "dirtForest", "forestLeaves" to "dirtForest", "forestNeedels" to "dirtForest",
        "forestGrass" to "grass",
        "forestRocksRoots" to "forestRoots", "pebblesForestGround" to "forestRoots", "rockyForestGround" to "forestRoots",
        "asphaltCracks" to "asphalt", "asphaltDirt" to "asphalt", "tarmac" to "asphalt",
        "concreteGravel" to "concrete", "concretePebbles" to "concrete", "concreteShattered" to "concrete",
        "gravelPebbles" to "gravelPebblesMossPatchy", "gravelDirt" to "gravelPebblesMossPatchy",
        "gravelMoss" to "gravelPebblesMossPatchy", "gravelAlpine" to "gravelPebblesMossPatchy",
        "gravel" to "gravelSmall"
    )
    private val fs26TreeMap = linkedMapOf(
        "oak" to "americanElm", "boxelder" to "americanElm", "chineseElm" to "americanElm",
        "goldenRain" to "americanElm", "japaneseZelkova" to "americanElm", "betulaErmanii" to "americanElm",
        "lodgepolePine" to "pine", "pinusSylvestris" to "pine"
    )
    private val fs26TreePath = Regex("(\\" + "\$data/maps/trees/)([A-Za-z]+?)(/\\2)")

    /** Застосовує механічні, перевірені логами правила FS26 Mobile до тексту одного XML/i3D файлу. */
    private fun applyFs26Rules(text: String, rel: String, rep: ConvertReport): String {
        var t = text
        val beforeP = t; t = fs26MapTexPath.replace(t, "\$1\$2")
        if (t != beforeP) rep.changes += tr("$rel: \$data/maps/mapXX/textures/ → \$data/maps/textures/ (FS26: без підпапки регіону)", "$rel: \$data/maps/mapXX/textures/ → \$data/maps/textures/ (FS26: без подпапки региона)")
        val beforeF = t; t = fs26FillPlanes.replace(t) { "\"\$data/fillPlanes/" }
        if (t != beforeF) rep.changes += tr("$rel: шлях fillPlanes виправлено на \$data/fillPlanes/", "$rel: путь fillPlanes исправлен на \$data/fillPlanes/")
        val beforeD = t; t = fs26Displacement.replace(t, "_height.png")
        if (t != beforeD) rep.changes += tr("$rel: _displacement.png → _height.png (не використовується на мобільному)", "$rel: _displacement.png → _height.png (не используется на мобильном)")
        var tc = 0
        t = fs26TerrainTexName.replace(t) { m ->
            val name = m.groupValues[2]
            val repl = fs26TexMap.entries.firstOrNull { name.startsWith(it.key) }
            if (repl != null) { tc++; "${m.groupValues[1]}${name.replaceFirst(repl.key, repl.value)}${m.groupValues[3]}" } else m.value
        }
        if (tc > 0) rep.changes += tr("$rel: замін текстур ґрунту/гравію за таблицею FS26: $tc", "$rel: замен текстур грунта/гравия по таблице FS26: $tc")
        var trc = 0
        t = fs26TreePath.replace(t) { m ->
            val sp = m.groupValues[2]
            val repl = fs26TreeMap[sp]
            if (repl != null) { trc++; "${m.groupValues[1]}$repl/$repl" } else m.value
        }
        if (trc > 0) rep.changes += tr("$rel: замін видів дерев (FS26 підтримує обмежений набір): $trc", "$rel: замен видов деревьев (FS26 поддерживает ограниченный набор): $trc")
        if (Regex("(?i)^map[A-Za-z0-9]*\\.xml$").matches(rel.substringAfterLast('/'))) {
            val memRe = Regex("(?s)(<vertexBufferMemoryUsage>)0(</vertexBufferMemoryUsage>.*?<indexBufferMemoryUsage>)0(</indexBufferMemoryUsage>.*?<textureMemoryUsage>)0(</textureMemoryUsage>)")
            if (memRe.containsMatchIn(t)) {
                t = memRe.replace(t) { m -> m.groupValues[1] + "18969856" + m.groupValues[2] + "3127552" + m.groupValues[3] + "103022592" + m.groupValues[4] }
                rep.changes += tr("$rel: нульова пам'ять замінена на перевірені значення mapEU (карта могла зависати на завантаженні)", "$rel: нулевая память заменена на проверенные значения mapEU (карта могла зависать на загрузке)")
            }
        }
        return t
    }

    private val STORED_EXT = setOf("png", "ogg", "jpg", "jpeg", "mp3", "zip", "mp4")
    private fun lvl(n: String) = if (n.substringAfterLast('.', "").lowercase() in STORED_EXT) 0 else 6

    /** Видимий підпис (author) + прихований маркер для перевірки нашою ж програмою. Гру це не обмежує і не захищає від видалення. */
    private fun sign(xml: String, nick0: String, rep: ConvertReport): String {
        val badChars = Regex("[<>&\"]")
        val nick = badChars.replace(nick0.take(40), "")
        var t = xml
        var sum = 0L
        for (c in nick) sum = sum * 31 + c.code
        val sig = (sum and 0xFFFFFFFL).toString(16)
        val marker = "<!-- DON1500-SIGNATURE nick=\"" + nick + "\" sig=\"" + sig + "\" -->"
        val existing = Regex("<!--\\s*DON1500-SIGNATURE[^>]*-->")
        t = if (existing.containsMatchIn(t)) existing.replace(t, marker)
        else Regex("(<modDesc\\b[^>]*>)").replace(t, "$1\n    " + Regex.escapeReplacement(marker))
        val authorTag = Regex("<author>.*?</author>", RegexOption.DOT_MATCHES_ALL)
        t = if (authorTag.containsMatchIn(t)) authorTag.replace(t, "<author>" + nick + "</author>")
        else t.replaceFirst(marker, marker + "\n    <author>" + nick + "</author>")
        rep.changes += tr("Підпис «" + nick + "» додано (author + мітка DON1500-SIGNATURE)", "Подпись «" + nick + "» добавлена (author + метка DON1500-SIGNATURE)")
        return t
    }

    private fun process(z: ZipFile, src: File, out: File?, opt: Options, rep: ConvertReport, isCancelled: () -> Boolean, progress: (String, Float) -> Unit) {
        val files = ArrayList<Pair<String, ZipEntry>>()
        val en = z.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (e.isDirectory) continue
            val n = e.name.replace('\\', '/').trimStart('/')
            if (n.split('/').any { it == ".." }) {
                rep.issues += Issue("ERROR", e.name, tr("Небезпечний шлях в архіві (..) — пропущено", "Опасный путь в архиве (..) — пропущено")); continue
            }
            files += n to e
        }
        rep.entries = files.size
        var mdPath = files.map { it.first }.filter { it.substringAfterLast('/') == "modDesc.xml" }
            .minByOrNull { p -> p.count { it == '/' } }
        var mdOriginalName: String? = null
        if (mdPath == null) {
            // Офіційні шаблони GIANTS іноді звуть його sample_modDesc.xml / modDesc_template.xml тощо —
            // шукаємо файл із "moddesc" у назві й перейменовуємо на правильне ім'я у результаті.
            val alt = files.map { it.first }
                .filter { Regex("(?i)moddesc").containsMatchIn(it.substringAfterLast('/')) && it.endsWith(".xml", true) }
                .minByOrNull { p -> p.count { it == '/' } }
            if (alt != null) { mdOriginalName = alt.substringAfterLast('/'); mdPath = alt }
        }
        val gen = if (mdPath == null) Repack.synthesize(files.map { it.first }, src.name) else null
        if (mdPath == null && gen == null) {
            rep.type = tr("невідомо", "неизвестно")
            rep.issues += Issue("ERROR", src.name, tr("Немає ні modDesc.xml, ні map.xml — не вдалося визначити, що це за мод/карта", "Нет ни modDesc.xml, ни map.xml — не удалось определить, что это за мод/карта"))
            return
        }
        val virtualMd: String? = gen?.first
        if (virtualMd != null) rep.changes += tr("modDesc.xml створено автоматично за map.xml (дані гри / розпакована карта)", "modDesc.xml создан автоматически по map.xml (данные игры / распакованная карта)")
        if (mdOriginalName != null) rep.changes += tr("modDesc знайдено як «$mdOriginalName» (офіційний шаблон карти) — перейменовано на modDesc.xml у результаті", "modDesc найден как «$mdOriginalName» (официальный шаблон карты) — переименован в modDesc.xml в результате")
        val root = if (mdPath != null) mdPath.substringBeforeLast('/', "") else gen!!.second.first
        if (mdPath == null) {
            val icon = gen!!.second.second
            rep.changes += if (icon != null) tr("Знайдено іконку карти: $icon", "Найдена иконка карты: $icon") else tr("⚠ Іконку карти не знайдено автоматично — додайте iconFilename вручну, якщо карта не з'явиться коректно", "⚠ Иконка карты не найдена автоматически — добавьте iconFilename вручную, если карта не появится корректно")
        }
        val prefix = if (root.isEmpty()) "" else "$root/"
        if (root.isNotEmpty()) rep.changes += tr("Верхню папку «$root» прибрано: modDesc.xml тепер у корені архіву", "Верхняя папка «$root» убрана: modDesc.xml теперь в корне архива")

        if (out != null) {
            val free = (out.parentFile ?: out).usableSpace
            if (free < src.length() + 64L * 1024 * 1024) {
                rep.issues += Issue("ERROR", out.name, tr("Недостатньо вільного місця: ${Fs.human(free)}", "Недостаточно свободного места: ${Fs.human(free)}")); return
            }
        }

        val mdText = if (mdPath != null) z.getInputStream(z.getEntry(files.first { it.first == mdPath }.second.name)).use { it.readBytes() }.toString(Charsets.UTF_8) else virtualMd!!
        val luaCount = files.count { it.first.endsWith(".lua", true) }
        rep.type = when {
            "<maps>" in mdText -> tr("Карта", "Карта")
            luaCount > 0 || "<extraSourceFiles>" in mdText -> tr("Скриптовий мод", "Скриптовый мод")
            else -> tr("Техніка / обладнання / об'єкти", "Техника / оборудование / объекты")
        }
        if (luaCount > 0) rep.issues += Issue("WARN", "*.lua", tr("Скрипти ($luaCount) автоматично не конвертуються — потрібна ручна перевірка API FS26 Mobile", "Скрипты ($luaCount) автоматически не конвертируются — нужна ручная проверка API FS26 Mobile"))

        val outNames = HashSet<String>()
        var outside = 0
        for ((n, _) in files) {
            if (!n.startsWith(prefix)) { outside++; continue }
            var rel = n.removePrefix(prefix)
            if (mdOriginalName != null && n == mdPath) rel = "modDesc.xml"
            if (isJunk(rel)) continue
            run {
                val e0 = rel.substringAfterLast('.', "").lowercase()
                val nt0 = fileTarget(e0, isIconName(rel), opt, isDataLayer(rel))
                outNames += if (nt0 != null && nt0 != e0) rel.dropLast(e0.length) + nt0 else rel
            }
        }
        if (outside > 0) rep.issues += Issue("WARN", "", tr("$outside файл(ів) поза папкою мода — не включено", "$outside файл(ов) вне папки мода — не включено"))
        val dupRe = Regex("^(.*)\\s?\\(\\d+\\)(\\.[^/.]+)$")
        for (n in outNames.toList()) {
            val m = dupRe.find(n) ?: continue
            val orig = m.groupValues[1].trimEnd() + m.groupValues[2]
            if (orig in outNames) rep.issues += Issue("WARN", n, tr("Схоже на дублікат «$orig» — перевірте й видаліть зайве вручну", "Похоже на дубликат «$orig» — проверьте и удалите лишнее вручную"))
        }

        val d23 = if (opt.target == "FS23") DonorLib.descVersion(opt.donors) else null
        if (opt.target == "FS23") rep.issues += Issue("WARN", "FS23", tr("Ціль FS23: descVersion, DDS→PNG, шляхи \$data/maps/, hotspots/trigger/navigationCollision і таблиця текстур ґрунту застосовані за перевіреними на реальних файлах правилами. Повну сумісність у грі це все одно не гарантує — перевірте log.txt.", "Цель FS23: descVersion, DDS→PNG, пути \$data/maps/, hotspots/trigger/navigationCollision и таблица текстур грунта применены по проверенным на реальных файлах правилам. Полную совместимость в игре это всё равно не гарантирует — проверьте log.txt."))
        val zout = out?.let { ZipOutputStream(BufferedOutputStream(FileOutputStream(it), 1 shl 16)).apply { setLevel(Deflater.BEST_SPEED) } }
        val written = HashSet<String>()
        val refs = LinkedHashSet<Pair<String, String>>()
        fun put(name: String, bytes: ByteArray) {
            if (zout == null) return
            if (!written.add(name)) { rep.issues += Issue("WARN", name, tr("Дублікат запису — пропущено", "Дубликат записи — пропущено")); return }
            zout.setLevel(lvl(name)); zout.putNextEntry(ZipEntry(name)); zout.write(bytes); zout.closeEntry()
        }
        // Кодування текстур (PNG/DDS/AST) — найповільніша частина: робимо його паралельно на кількох ядрах, запис в ZIP — лише з головного потоку.
        class TexRes(val iw: Int, val ih: Int, val rw: Int, val rh: Int, val out: ByteArray?)
        class TexJob(val rel: String, val ext: String, val tgt: String, val newName: String, val bytes: ByteArray, val fut: java.util.concurrent.Future<TexRes>)
        // AST-кодувальник (Gs2d.encode) уже сам багатопотоковий — для AST зовнішній пул = 1, щоб не перевантажувати ядра й пам'ять.
        val par = if (opt.texFmt == "ASTP" || opt.texFmt == "AST") 1 else (Runtime.getRuntime().maxMemory() / (300L shl 20)).toInt().coerceIn(1, 4).coerceAtMost(Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
        val pool = java.util.concurrent.Executors.newFixedThreadPool(par)
        val jobs = java.util.ArrayDeque<TexJob>()
        fun finishJob(j: TexJob) {
            try {
                val r = j.fut.get()
                if (r.out == null) put(j.rel, j.bytes)
                else if (j.newName in written) rep.issues += Issue("WARN", j.newName, tr("Файл уже існує — текстуру не перетворено", "Файл уже существует — текстура не преобразована"))
                else { put(j.newName, r.out); rep.ddsConverted++; rep.changes += "${j.ext.uppercase()}→${j.tgt.uppercase()}: ${j.rel} (${r.iw}x${r.ih} → ${r.rw}x${r.rh})" }
            } catch (ex: Throwable) {
                val msg = (ex.cause ?: ex).message
                rep.issues += Issue("ERROR", j.rel, tr("Не вдалося перетворити в ${j.tgt.uppercase()}: $msg. Оригінал збережено", "Не удалось преобразовать в ${j.tgt.uppercase()}: $msg. Оригинал сохранён"))
                outNames.remove(j.newName); outNames += j.rel; put(j.rel, j.bytes)
            }
        }
        try {
            val total = files.size.coerceAtLeast(1)
            val totalBytes = files.filter { it.first.startsWith(prefix) }.sumOf { it.second.size.coerceAtLeast(0L) }.coerceAtLeast(1L)
            var doneBytes = 0L
            val nameSet = files.mapTo(HashSet<String>()) { it.first }
            // Імена матеріалів із FS22-кольорових конфігурацій техніки (<material name="kuzov" shaderParameter=…>) — для materialSlotName в i3d.
            val slotNames = HashSet<String>()
            if (opt.target == "FS26") for ((fp, fe) in files) {
                if (fp.endsWith(".xml") && fp != "modDesc.xml" && fe.size in 1L..2_000_000L) {
                    try {
                        val tx = z.getInputStream(fe).use { String(it.readBytes(), Charsets.UTF_8) }
                        if (tx.contains("shaderParameter=")) Regex("<material\\s+name=\"([^\"]+)\"\\s+shaderParameter=").findAll(tx).forEach { slotNames.add(it.groupValues[1]) }
                    } catch (_: Exception) { }
                }
            }
            var i = 0
            for ((n, e) in files) {
                i++
                if (isCancelled()) { rep.cancelled = true; break }
                if (!n.startsWith(prefix)) continue
                var rel = n.removePrefix(prefix)
                if (mdOriginalName != null && n == mdPath) rel = "modDesc.xml"
                if (isJunk(rel)) { rep.changes += tr("Службовий файл пропущено: $rel", "Служебный файл пропущен: $rel"); continue }
                doneBytes += e.size.coerceAtLeast(0L)
                progress("[$i/$total] $rel", (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f))
                val ext = rel.substringAfterLast('.', "").lowercase()
                val dataLayer = isDataLayer(rel)
                val nt = fileTarget(ext, isIconName(rel), opt, dataLayer)
                val compress = opt.maxTex == -2 && !dataLayer && (ext == "png" || ext == "dds" || ext == "ast") && (opt.texIcons || !isIconName(rel))
                when {
                    compress || (nt != null && nt != ext && !(ext == "dds" && nt == "png")) -> {
                        val tgt = nt ?: ext
                        val newName = rel.dropLast(ext.length) + tgt
                        if (zout != null) {
                            val bytes = z.getInputStream(e).use { it.readBytes() }
                            val fut = pool.submit(java.util.concurrent.Callable {
                                val img = ImageTools.load(bytes, rel) ?: throw IOException(tr("не вдалося прочитати зображення", "не удалось прочитать изображение"))
                                val want = if (dataLayer) 0 else when { opt.maxTex == -2 -> ImageTools.autoSize(img, opt.texLevel, rel); opt.maxTex > 0 && maxOf(img.w, img.h) > opt.maxTex -> opt.maxTex; else -> 0 }
                                val rs = ImageTools.resize(img, if (want in 1 until maxOf(img.w, img.h)) want else 0, false)
                                if (tgt == ext && rs === img) TexRes(img.w, img.h, rs.w, rs.h, null)
                                else TexRes(img.w, img.h, rs.w, rs.h, ImageTools.encode(rs, tgt.uppercase()))
                            })
                            jobs.addLast(TexJob(rel, ext, tgt, newName, bytes, fut))
                            while (jobs.size > par * 2) finishJob(jobs.removeFirst())
                        }
                    }
                    ext == "dds" && nt == "png" -> {
                        val bytes = z.getInputStream(e).use { it.readBytes() }
                        val pngName = rel.dropLast(4) + ".png"
                        if (zout == null) {
                            val err = Dds.probe(bytes)
                            if (err != null) { rep.issues += Issue("ERROR", rel, tr("DDS не вдасться перетворити: $err", "DDS не удастся преобразовать: $err")); outNames.remove(pngName) }
                        } else {
                            val r = Dds.decode(bytes, if (opt.maxTex < 0) 0 else opt.maxTex)
                            if (r.png != null) {
                                if (pngName in written) rep.issues += Issue("WARN", pngName, tr("PNG уже існує — DDS не перетворювався", "PNG уже существует — DDS не преобразовывался"))
                                else { put(pngName, r.png); rep.ddsConverted++; rep.changes += "DDS→PNG: $rel (${r.w}x${r.h})" }
                            } else {
                                rep.issues += Issue("ERROR", rel, tr("DDS не вдалося перетворити: ${r.error}. Оригінал збережено; потрібен PNG: $pngName", "DDS не удалось преобразовать: ${r.error}. Оригинал сохранён; нужен PNG: $pngName"))
                                outNames.remove(pngName); put(rel, bytes)
                            }
                        }
                    }
                    (ext == "xml" || ext == "i3d") && e.size > 15_000_000L && e.size <= MAX_TEXT -> {
                        // Великий файл (наприклад map.i3d): обробка ПОТОКОМ по шматках — без завантаження всього тексту в пам'ять
                        progress(tr("$rel (${Fs.human(e.size)}) — великий файл, потокова обробка…", "$rel (${Fs.human(e.size)}) — большой файл, потоковая обработка…"), (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f))
                        if (zout != null) {
                            val utf8ok = try {
                                val dec = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                                InputStreamReader(z.getInputStream(e), dec).use { r -> val buf = CharArray(1 shl 16); while (r.read(buf) >= 0) { if (isCancelled()) break } }
                                true
                            } catch (ex: CharacterCodingException) { false }
                            if (!utf8ok) {
                                rep.issues += Issue("WARN", rel, tr("Не UTF-8 — скопійовано без змін", "Не UTF-8 — скопировано без изменений"))
                                if (written.add(rel)) { zout.setLevel(lvl(rel)); zout.putNextEntry(ZipEntry(rel)); z.getInputStream(e).use { it.copyTo(zout, 1 shl 16) }; zout.closeEntry() }
                            } else if (!written.add(rel)) {
                                rep.issues += Issue("WARN", rel, tr("Дублікат запису — пропущено", "Дубликат записи — пропущено"))
                            } else {
                                val sub = ConvertReport()
                                zout.setLevel(1); zout.putNextEntry(ZipEntry(rel))
                                val sink = object : FilterOutputStream(zout) {
                                    override fun write(b: ByteArray, off: Int, len: Int) { this.out.write(b, off, len) }
                                    override fun close() {}
                                }
                                val w = BufferedWriter(OutputStreamWriter(sink, Charsets.UTF_8), 1 shl 16)
                                fun tf(chunk: String): String {
                                    var t = chunk
                                    if (opt.texFmt == "PNG" && (opt.target == "FS26" || opt.target == "FS23")) t = ddsRe.replace(t) { sub.textureRewrites++; ".png" }
                                    t = rewriteTexRefs(t, opt, sub, rel)
                                    if (!opt.fixOnly && opt.target == "FS23") t = applyFs23Rules(t, rel, sub)
                                    if (!opt.fixOnly && opt.target == "FS26") t = applyFs26Rules(t, rel, sub)
                                    return t
                                }
                                // Сторож: якщо великий файл не рухається > 20 с — показує в статусі етап, пам'ять і місце в коді (для діагностики зависання).
                                val worker = Thread.currentThread()
                                val phase = java.util.concurrent.atomic.AtomicReference("читання")
                                val lastAct = java.util.concurrent.atomic.AtomicLong(System.currentTimeMillis())
                                val wdDone = java.util.concurrent.atomic.AtomicBoolean(false)
                                val wd = Thread {
                                    while (!wdDone.get()) {
                                        try { Thread.sleep(5000) } catch (_: InterruptedException) { break }
                                        val idle = System.currentTimeMillis() - lastAct.get()
                                        if (!wdDone.get() && idle > 20_000) {
                                            val rtm = Runtime.getRuntime()
                                            val st = worker.stackTrace.take(5).joinToString(" ← ") { it.className.substringAfterLast('.') + "." + it.methodName + ":" + it.lineNumber }
                                            progress("⚠ $rel: ${idle / 1000} с без руху · етап: ${phase.get()} · пам'ять ${(rtm.totalMemory() - rtm.freeMemory()) shr 20}/${rtm.maxMemory() shr 20} МБ · $st", (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f))
                                        }
                                    }
                                }
                                wd.isDaemon = true; wd.start()
                                try {
                                InputStreamReader(z.getInputStream(e), Charsets.UTF_8).use { r ->
                                    val buf = CharArray(1 shl 20)
                                    val carry = StringBuilder()
                                    var first = true
                                    var charsDone = 0L
                                    var lastBeat = System.currentTimeMillis()
                                    while (true) {
                                        if (isCancelled()) break
                                        phase.set("розпакування")
                                        val n = r.read(buf)
                                        lastAct.set(System.currentTimeMillis())
                                        if (n < 0) break
                                        charsDone += n
                                        carry.append(buf, 0, n)
                                        val now = System.currentTimeMillis()
                                        if (now - lastBeat > 700) {
                                            lastBeat = now
                                            val inFile = charsDone.coerceAtMost(e.size)
                                            progress("$rel — ${Fs.human(inFile)} / ${Fs.human(e.size)}", ((doneBytes - e.size.coerceAtLeast(0L) + inFile).toFloat() / totalBytes).coerceIn(0f, 1f))
                                        }
                                        var cut = carry.lastIndexOf("\n")
                                        if (cut < 0) cut = carry.lastIndexOf("\r")
                                        if (cut < 0 && carry.length > 1_000_000) cut = carry.lastIndexOf(">")
                                        if (cut < 0) continue
                                        var part = carry.substring(0, cut + 1)
                                        carry.delete(0, cut + 1)
                                        if (first) { first = false; if (part.startsWith("\uFEFF")) part = part.substring(1) }
                                        phase.set("обробка тексту ${part.length / 1024} КБ")
                                        val outPart = tf(part)
                                        lastAct.set(System.currentTimeMillis())
                                        phase.set("запис")
                                        w.write(outPart)
                                        lastAct.set(System.currentTimeMillis())
                                    }
                                    if (carry.isNotEmpty()) { var part = carry.toString(); if (first && part.startsWith("\uFEFF")) part = part.substring(1); w.write(tf(part)) }
                                }
                                } finally { wdDone.set(true); wd.interrupt() }
                                w.flush()
                                zout.closeEntry()
                                rep.textureRewrites += sub.textureRewrites
                                val seen = HashSet<String>()
                                for (c in sub.changes) if (seen.add(c.replace(Regex("\\d+"), "#"))) rep.changes += c
                                rep.issues += Issue("WARN", rel, tr("Великий файл (${Fs.human(e.size)}) — оброблено потоком, посилання в ньому не перевірялись (для швидкості)", "Большой файл (${Fs.human(e.size)}) — обработан потоком, ссылки в нём не проверялись (для скорости)"))
                            }
                        }
                    }
                    (ext == "xml" || ext == "i3d") && e.size <= MAX_TEXT -> {
                        val bigFile = e.size > 15_000_000L
                        if (bigFile) progress(tr("$rel (${Fs.human(e.size)}) — великий файл, обробка займе час…", "$rel (${Fs.human(e.size)}) — большой файл, обработка займёт время…"), (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f))
                        val raw = z.getInputStream(e).use { it.readBytes() }
                        val text = strictUtf8(raw)
                        if (text == null) {
                            rep.issues += Issue("WARN", rel, tr("Не UTF-8 — скопійовано без змін", "Не UTF-8 — скопировано без изменений"))
                            put(rel, raw)
                        } else {
                            var t: String = text
                            val hadBom = t.startsWith("\uFEFF")
                            if (hadBom) t = t.substring(1)
                            if (rel == "modDesc.xml" && !opt.fixOnly) t = fixModDesc(t, opt, rep, d23)
                            if (opt.texFmt == "PNG" && (opt.target == "FS26" || opt.target == "FS23")) {
                                var cnt = 0
                                t = ddsRe.replace(t) { cnt++; ".png" }
                                if (cnt > 0) { rep.textureRewrites += cnt; rep.changes += tr("$rel: посилань .dds→.png: $cnt", "$rel: ссылок .dds→.png: $cnt") }
                            }
                            t = rewriteTexRefs(t, opt, rep, rel)
                            if (opt.target == "FS26" && !bigFile) {
                                if (t.contains("<foldable")) { val r = ModFix.fixFolding(t); if (r.count > 0) { t = r.text; rep.changes += tr("$rel: foldingParts → foldingConfigurations (${r.count})", "$rel: foldingParts → foldingConfigurations (${r.count})") } }
                                if (t.contains("DIGIT_BOLD")) { val r = ModFix.fixFonts(t); if (r.count > 0) { t = r.text; rep.changes += tr("$rel: прибрано невідомий шрифт DIGIT_BOLD (${r.count})", "$rel: убран неизвестный шрифт DIGIT_BOLD (${r.count})") } }
                                if (ext == "i3d" && (t.contains("customShaderVariation") || t.contains("\\") || t.contains("main_component") || slotNames.isNotEmpty())) { val r = ModFix.fixI3d(t, detailMaps, slotNames); if (r.count > 0) { t = r.text; rep.changes += tr("$rel: i3d під FS26 (шейдер-варіації, параметри FS22, шляхи${if (detailMaps) ", detail-maps" else ""}): ${r.count}", "$rel: i3d под FS26 (шейдер-вариации, параметры FS22, пути${if (detailMaps) ", detail-maps" else ""}): ${r.count}") } }
                                if (ext == "xml" && rel != "modDesc.xml") {
                                    if (t.contains("<simpleIC") || t.contains("MaterialConfiguration") || t.contains("<baseMaterial") || t.contains("<!-->") || t.contains("<audioMemoryUsage") || t.contains("<rimColorConfiguration")) { val r = ModFix.fixVehicleXml(t); if (r.count > 0) { t = r.text; rep.changes += tr("$rel: XML техніки під FS26 (кольори, simpleIC, коментарі): ${r.count}", "$rel: XML техники под FS26 (цвета, simpleIC, комментарии): ${r.count}") } }
                                    if (t.contains("isCareWheel")) { val r = ModFix.fixWheelXml(t); if (r.count > 0) { t = r.text; rep.changes += tr("$rel: колесо — прибрано isCareWheel", "$rel: колесо — убран isCareWheel") } }
                                    if (t.contains(".wav\"")) { var wc = 0; t = Regex("file=\"([^\"]+)\\.wav\"").replace(t) { m -> if (nameSet.contains(m.groupValues[1] + ".ogg")) { wc++; "file=\"" + m.groupValues[1] + ".ogg\"" } else m.value }; if (wc > 0) rep.changes += tr("$rel: звук .wav → .ogg: $wc", "$rel: звук .wav → .ogg: $wc") }
                                }
                                if (rel == "modDesc.xml" && t.contains("<vehicleTypes")) { val r = ModFix.fixVehicleTypes(t); if (r.count > 0) { t = r.text; rep.changes += tr("$rel: прибрано дублі специфікацій у vehicleTypes (${r.count})", "$rel: убраны дубли специализаций в vehicleTypes (${r.count})") } }
                            }
                            if (!opt.fixOnly && opt.target == "FS23") t = applyFs23Rules(t, rel, rep)
                            if (!opt.fixOnly && opt.target == "FS26") t = applyFs26Rules(t, rel, rep)
                            if (hadBom) rep.changes += tr("$rel: прибрано BOM", "$rel: убран BOM")
                            if (!bigFile) refsIn(t, ext == "xml", true).forEach { refs += rel to it }
                            else rep.issues += Issue("WARN", rel, tr("Великий файл (${Fs.human(e.size)}) — посилання в ньому не перевірялись (для швидкості)", "Большой файл (${Fs.human(e.size)}) — ссылки в нём не проверялись (для скорости)"))
                            put(rel, if (t == text) raw else t.toByteArray(Charsets.UTF_8))
                        }
                    }
                    ext == "lua" && zout != null -> {
                        val raw = z.getInputStream(e).use { it.readBytes() }
                        if (raw.size < 20_000_000 && Regex("\\.dds", RegexOption.IGNORE_CASE).containsMatchIn(raw.toString(Charsets.ISO_8859_1)))
                            rep.issues += Issue("WARN", rel, tr("Скрипт згадує .dds — перевірте вручну", "Скрипт упоминает .dds — проверьте вручную"))
                        put(rel, raw)
                    }
                    else -> {
                        if (zout != null) {
                            if (!written.add(rel)) { rep.issues += Issue("WARN", rel, tr("Дублікат запису — пропущено", "Дубликат записи — пропущено")) }
                            else {
                                zout.setLevel(lvl(rel)); zout.putNextEntry(ZipEntry(rel))
                                val sz = e.size.coerceAtLeast(0L)
                                if (sz > 10_000_000L) {
                                    // Великий бінарний файл (.shapes, .gdm тощо) — оновлюємо відсоток прямо під час копіювання, а не лише до/після.
                                    val buf = ByteArray(1 shl 16)
                                    var copied = 0L; var lastShown = -1
                                    z.getInputStream(e).use { ins ->
                                        while (true) {
                                            val n = ins.read(buf); if (n < 0) break
                                            zout.write(buf, 0, n); copied += n
                                            val within = if (sz > 0) (copied.toFloat() / sz) else 0f
                                            val overall = ((doneBytes - sz + copied).toFloat() / totalBytes).coerceIn(0f, 1f)
                                            val pct = (within * 100).toInt()
                                            if (pct != lastShown) { lastShown = pct; progress("$rel — ${Fs.human(copied)} / ${Fs.human(sz)}", overall) }
                                        }
                                    }
                                } else z.getInputStream(e).use { it.copyTo(zout, 1 shl 16) }
                                zout.closeEntry()
                            }
                        }
                    }
                }
            }
            if (rep.cancelled) jobs.clear() else while (jobs.isNotEmpty()) { progress(tr("Завершення кодування текстур… (залишилось ${jobs.size})", "Завершение кодирования текстур… (осталось ${jobs.size})"), 1f); finishJob(jobs.removeFirst()) }
            if (virtualMd != null) {
                var vt = fixModDesc(virtualMd, opt, rep, d23)
                if (opt.texFmt == "PNG" && (opt.target == "FS26" || opt.target == "FS23")) vt = ddsRe.replace(vt) { ".png" }
                vt = rewriteTexRefs(vt, opt, rep, "modDesc.xml")
                refsIn(vt, true, true).forEach { refs += "modDesc.xml" to it }
                outNames += "modDesc.xml"
                put("modDesc.xml", vt.toByteArray(Charsets.UTF_8))
            }
        } finally { pool.shutdownNow(); zout?.close() }
        if (rep.cancelled) {
            out?.delete()
            rep.issues += Issue("WARN", rep.sourceName, tr("Скасовано користувачем; незавершений архів видалено", "Отменено пользователем; незавершённый архив удалён"))
            return
        }

        // Перевірка посилань
        val lower = HashMap<String, String>()
        outNames.forEach { lower[it.lowercase()] = it }
        for ((from, ref) in refs) {
            if (ref.startsWith("\$data/")) {
                val okDonor = Donor.count > 0 && Donor.has(ref)
                val okKnown = KnownFiles.has(ref)
                if (!okDonor && !okKnown) rep.missingData.putIfAbsent(ref, from)
                continue
            }
            val c1 = norm(ref)
            val dir = from.substringBeforeLast('/', "")
            val c2 = norm(if (dir.isEmpty()) ref else "$dir/$ref")
            if ((c1 != null && c1 in outNames) || (c2 != null && c2 in outNames)) continue
            if (opt.texFmt == "AST" || opt.texFmt == "ASTP") {
                // .png-посилання задовольняє файл .ast з тією ж назвою (гра сама підставляє .ast)
                fun twin(p: String?): String? = p?.let { q -> if (q.endsWith(".png", true)) q.dropLast(4) + ".ast" else null }
                if ((twin(c1) != null && twin(c1)!! in outNames) || (twin(c2) != null && twin(c2)!! in outNames)) continue
            }
            val ci = listOfNotNull(c1, c2).firstNotNullOfOrNull { lower[it.lowercase()] }
            if (ci != null) rep.issues += Issue("WARN", from, tr("Регістр не збігається: «$ref» ≠ «$ci» (на Android регістр важливий)", "Регистр не совпадает: «$ref» ≠ «$ci» (на Android регистр важен)"))
            else rep.missing.putIfAbsent(c1 ?: ref, from)
        }

        if (out != null && !opt.fixOnly && opt.donors.isNotEmpty() && rep.missing.isNotEmpty()) {
            progress(tr("Беремо відсутні файли з донорів…", "Берём отсутствующие файлы из доноров…"), 1f)
            try { DonorFill.fill(File(out.parentFile, ".fill").also { it.mkdirs() }, out, rep, opt) }
            catch (e: Exception) { rep.issues += Issue("ERROR", out.name, tr("Збій добору з донора: ${e.message}", "Сбой добора из донора: ${e.message}")) }
        }

        if (out != null) {
            progress(tr("Перевірка архіву…", "Проверка архива…"), 1f)
            val err = ZipTools.verify(out)
            if (err != null) rep.issues += Issue("ERROR", out.name, tr("Вихідний ZIP не пройшов перевірку: $err", "Выходной ZIP не прошёл проверку: $err"))
            else {
                val ok = try { ZipFile(out).use { it.getEntry("modDesc.xml") != null } } catch (e: Exception) { false }
                if (!ok) rep.issues += Issue("ERROR", out.name, tr("У результаті немає modDesc.xml в корені", "В результате нет modDesc.xml в корне"))
                rep.verified = ok
            }
        }
    }
}
