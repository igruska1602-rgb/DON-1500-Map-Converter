@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.don1500.converter

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

private val SWAP_EXT = setOf("png", "dds", "jpg", "jpeg", "tga")

private class TexEntry(val path: String, var sizeBytes: Long, var w: Int = 0, var h: Int = 0)

/**
 * Головна "авто-заміна": скановує ZIP-донор (будь-якої вкладеності папок) і підмінює в targetZip
 * усі текстури, чия НАЗВА файлу (без шляху й розширення) збігається з донором. Усе читається і
 * пишеться потоково — жодного разу весь ZIP не тримається в пам'яті, тому підходить і для тисяч файлів.
 */
private fun autoReplaceFromDonor(donorZip: File, targetZip: File, entries: List<TexEntry>): Triple<Int, Int, String?> {
    val byBase = HashMap<String, TexEntry>()
    for (t in entries) byBase[t.path.substringAfterLast('/').substringBeforeLast('.').lowercase()] = t
    val adds = LinkedHashMap<String, File>()
    val tmp = File(targetZip.parentFile, ".donorswap_" + System.currentTimeMillis()).also { it.mkdirs() }
    var matched = 0; var failed = 0
    try {
        ZipFile(donorZip).use { dz ->
            val en = dz.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                val ext = e.name.substringAfterLast('.', "").lowercase()
                if (ext !in SWAP_EXT) continue
                val base = e.name.substringAfterLast('/').substringBeforeLast('.').lowercase()
                val hit = byBase[base] ?: continue
                try {
                    val raw = dz.getInputStream(e).use { it.readBytes() }
                    val img = ImageTools.load(raw, e.name) ?: continue
                    val resized = if (hit.w > 0 && hit.h > 0) ImageTools.resize(img, maxOf(hit.w, hit.h), hit.w == hit.h) else img
                    val outExt = hit.path.substringAfterLast('.', "").uppercase().let { if (it == "JPEG") "JPG" else it }
                    val f = File(tmp, "d_${adds.size}.bin"); f.writeBytes(ImageTools.encode(resized, outExt))
                    adds[hit.path] = f; matched++
                } catch (ex: Exception) { failed++ }
            }
        }
        if (adds.isNotEmpty()) ZipTools.addMany(targetZip, adds)
        return Triple(matched, failed, null)
    } catch (e: Exception) {
        return Triple(matched, failed, e.message)
    } finally {
        tmp.deleteRecursively()
    }
}

/** Заголовок/розміри картинки без повного декодування (швидко, для списку). */
private fun peekSize(bytes: ByteArray, name: String): Pair<Int, Int> {
    if (name.endsWith(".dds", true)) {
        if (bytes.size >= 20 && bytes[0] == 'D'.code.toByte() && bytes[1] == 'D'.code.toByte()) {
            fun le(o: Int) = (bytes[o].toInt() and 255) or ((bytes[o + 1].toInt() and 255) shl 8) or ((bytes[o + 2].toInt() and 255) shl 16) or ((bytes[o + 3].toInt() and 255) shl 24)
            return le(16) to le(12)
        }
        return 0 to 0
    }
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
    return o.outWidth to o.outHeight
}

private fun thumb(bytes: ByteArray, name: String): Bitmap? = try {
    if (name.endsWith(".dds", true)) {
        val r = Dds.decode(bytes, 96)
        r.png?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
    } else {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > 192 && o.outHeight / sample > 192) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }
} catch (e: Throwable) { null }

@Composable
fun TextureSwapScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var zip by remember { mutableStateOf<File?>(null) }
    var zipName by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(listOf<TexEntry>()) }
    var thumbs by remember { mutableStateOf(mapOf<String, Bitmap>()) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var msg by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    val searchFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var target by remember { mutableStateOf<TexEntry?>(null) }
    var rev by remember { mutableStateOf(0) }

    fun rescan() = scope.launch {
        val z = zip ?: return@launch
        busy = true; prog = 0f
        val list = withContext(Dispatchers.IO) {
            val out = ArrayList<TexEntry>()
            ZipFile(z).use { zf ->
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.isDirectory) continue
                    val ext = e.name.substringAfterLast('.', "").lowercase()
                    if (ext !in SWAP_EXT) continue
                    out += TexEntry(e.name, e.size)
                }
            }
            out.sortedBy { it.path }
        }
        entries = list
        busy = false; rev++
    }

    val openZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""; prog = 0f; entries = emptyList(); thumbs = emptyMap()
            try {
                val name = Fs.displayName(ctx, uri)
                val dest = File(Fs.work(ctx), "swap_" + name)
                withContext(Dispatchers.IO) { Fs.copyUri(ctx, uri, dest) { } }
                try { ZipFile(dest).close() } catch (e: Exception) { dest.delete(); throw java.io.IOException(tr("Це не ZIP або файл пошкоджений", "Это не ZIP или файл повреждён")) }
                zip = dest; zipName = name
            } catch (e: Exception) { msg = "✖ ${e.message}" }
            busy = false
            rescan()
        }
    }

    fun loadThumbs(visible: List<TexEntry>) = scope.launch {
        val z = zip ?: return@launch
        val need = visible.filter { it.path !in thumbs }.take(60)
        if (need.isEmpty()) return@launch
        val got = withContext(Dispatchers.IO) {
            val m = HashMap<String, Bitmap>()
            ZipFile(z).use { zf ->
                for (t in need) {
                    try {
                        val e = zf.getEntry(t.path) ?: continue
                        val bytes = zf.getInputStream(e).use { it.readBytes() }
                        val (w, h) = peekSize(bytes, t.path); t.w = w; t.h = h
                        thumb(bytes, t.path)?.let { m[t.path] = it }
                    } catch (_: Throwable) { }
                }
            }
            m
        }
        thumbs = thumbs + got
    }

    val replacePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val t = target; val z = zip
        if (uri != null && t != null && z != null) scope.launch {
            busy = true; msg = ""
            msg = withContext(Dispatchers.IO) {
                try {
                    val name = Fs.displayName(ctx, uri)
                    val raw = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val img = ImageTools.load(raw, name) ?: throw java.io.IOException(tr("Не вдалося прочитати зображення", "Не удалось прочитать изображение"))
                    val resized = if (t.w > 0 && t.h > 0 && (img.w != t.w || img.h != t.h)) ImageTools.resize(img, maxOf(t.w, t.h), t.w == t.h) else img
                    val ext = t.path.substringAfterLast('.', "").uppercase().let { if (it == "JPEG") "JPG" else it }
                    val out = ImageTools.encode(resized, ext)
                    ZipTools.addOrReplace(z, t.path, out)
                    thumbs = thumbs - t.path
                    "✔ " + tr("Замінено: ${t.path}", "Заменено: ${t.path}")
                } catch (e: Exception) { "✖ ${e.message}" }
            }
            target = null; busy = false; rescan()
        }
    }

    var donorDlg by remember { mutableStateOf(false) }
    fun runDonorZip(donorFile: File, label: String) = scope.launch {
        val z = zip ?: return@launch
        busy = true; msg = ""; prog = -1f
        msg = withContext(Dispatchers.IO) {
            val (okN, badN, err) = autoReplaceFromDonor(donorFile, z, entries)
            if (err != null) "✖ $label: $err"
            else "✔ " + tr("З «$label» замінено: $okN", "Из «$label» заменено: $okN") + (if (badN > 0) tr(", з помилкою: $badN", ", с ошибкой: $badN") else "")
        }
        thumbs = emptyMap(); prog = 0f; busy = false; rescan()
    }
    val donorZipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; msg = ""
            val f = withContext(Dispatchers.IO) {
                try {
                    val name = Fs.displayName(ctx, uri)
                    val dest = File(Fs.work(ctx), "donorzip_" + name)
                    Fs.copyUri(ctx, uri, dest) { }
                    try { ZipFile(dest).close() } catch (e: Exception) { dest.delete(); return@withContext null }
                    dest to name
                } catch (e: Exception) { null }
            }
            busy = false
            if (f == null) msg = "✖ " + tr("Це не ZIP або файл пошкоджений", "Это не ZIP или файл повреждён") else runDonorZip(f.first, f.second)
        }
    }
    val batchPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val z = zip
        if (uris.isNotEmpty() && z != null) scope.launch {
            busy = true; msg = ""; prog = 0f
            msg = withContext(Dispatchers.IO) {
                try {
                    val byBase = entries.associateBy { it.path.substringAfterLast('/').substringBeforeLast('.').lowercase() }
                    val adds = LinkedHashMap<String, File>()
                    val tmp = File(z.parentFile, ".swapbatch").also { it.mkdirs() }
                    var matched = 0; var unmatched = 0
                    for ((i, u) in uris.withIndex()) {
                        prog = i / uris.size.toFloat()
                        val name = Fs.displayName(ctx, u)
                        val base = name.substringBeforeLast('.').lowercase()
                        val hit = byBase[base]
                        if (hit == null) { unmatched++; continue }
                        try {
                            val raw = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
                            val img = ImageTools.load(raw, name) ?: throw java.io.IOException("decode")
                            val resized = if (hit.w > 0 && hit.h > 0) ImageTools.resize(img, maxOf(hit.w, hit.h), hit.w == hit.h) else img
                            val ext = hit.path.substringAfterLast('.', "").uppercase().let { if (it == "JPEG") "JPG" else it }
                            val f = File(tmp, "b_${adds.size}.bin"); f.writeBytes(ImageTools.encode(resized, ext))
                            adds[hit.path] = f; matched++
                        } catch (e: Exception) { unmatched++ }
                    }
                    if (adds.isNotEmpty()) ZipTools.addMany(z, adds)
                    tmp.deleteRecursively()
                    thumbs = emptyMap()
                    "✔ " + tr("Замінено за назвою: $matched. Без збігу: $unmatched", "Заменено по имени: $matched. Без совпадения: $unmatched")
                } catch (e: Exception) { "✖ ${e.message}" }
            }
            busy = false; rescan()
        }
    }

    val shown = remember(entries, filter) {
        if (filter.isBlank()) entries else {
            val f = filter.trim().lowercase()
            val extra = SEARCH_SYNONYMS.entries.firstOrNull { f.contains(it.key) || it.key.contains(f) }?.value
            entries.filter { e -> val p = e.path.lowercase(); p.contains(f) || (extra != null && extra.any { w -> p.contains(w) }) }
        }
    }
    LaunchedEffect(shown, rev) { loadThumbs(shown) }

    Frame(tr("Заміна текстур", "Замена текстур"), onBack) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal = 12.dp)) {
                InfoHint(tr("Відкрийте готову карту чи мод (ZIP). Торкніться текстури, щоб замінити її своєю картинкою — розмір і формат підженуться автоматично. Або киньте купу файлів чи ZIP із текстурами: ті, чия назва збігається з назвою файлу в моді, заміняться одразу всі.", "Откройте готовую карту или мод (ZIP). Коснитесь текстуры, чтобы заменить её своей картинкой — размер и формат подгонятся автоматически. Или киньте кучу файлов или ZIP с текстурами: те, чьё имя совпадает с именем файла в моде, заменятся все сразу."))
                if (!searchOpen) Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(enabled = !busy, onClick = { openZip.launch(arrayOf("*/*")) }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) {
                        Icon(Icons.Filled.FolderZip, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(tr("Відкрити ZIP", "Открыть ZIP"), fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    if (zip != null) OutlinedButton(enabled = !busy, onClick = { donorDlg = true }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) {
                        Icon(Icons.Filled.DriveFileMove, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(tr("Авто з донора", "Авто из донора"), fontSize = 13.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    if (zip != null) IconButton(onClick = { searchOpen = true }) { Icon(Icons.Filled.Search, null) }
                } else {
                    OutlinedTextField(filter, { filter = it }, Modifier.fillMaxWidth().padding(top = 8.dp).focusRequester(searchFocus), singleLine = true,
                        placeholder = { Text(tr("Пошук за назвою", "Поиск по имени"), fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Filled.Search, null) },
                        trailingIcon = { IconButton(onClick = { if (filter.isEmpty()) searchOpen = false else filter = "" }) { Icon(Icons.Filled.Close, null) } })
                    LaunchedEffect(Unit) { searchFocus.requestFocus() }
                }
                if (zipName.isNotEmpty()) Text(zipName + " · " + tr("текстур: ${entries.size}", "текстур: ${entries.size}"), fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                if (busy) { if (prog < 0f) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) else LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) }
                if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp)
            }
            // Підписи розділів (земля/культури/дерева…) навмисно НЕ показуються — вони лишаються лише
            // "під капотом" для пошуку (SEARCH_SYNONYMS): напишіть "гравій", "дерево" тощо в пошук вище.
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                items(shown, key = { it.path }) { t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        val bmp = thumbs[t.path]
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize())
                            else Text("…", fontSize = 10.sp)
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(t.path, fontSize = 12.sp, maxLines = 2)
                            Text((if (t.w > 0) "${t.w}×${t.h} · " else "") + Fs.human(t.sizeBytes), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(enabled = !busy, onClick = { target = t; replacePicker.launch(arrayOf("image/*", "*/*")) }) { Text(tr("Замінити", "Заменить")) }
                    }
                }
                if (zip != null && shown.isEmpty()) item { Text(tr("Нічого не знайдено за фільтром або в архіві немає текстур.", "Ничего не найдено по фильтру или в архиве нет текстур."), fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp)) }
            }
            if (zip != null) Row(Modifier.padding(12.dp)) {
                Button(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        msg = withContext(Dispatchers.IO) {
                            try { "✔ " + Fs.publish(ctx, zip!!, "application/zip", "texture_swap") } catch (e: Exception) { "✖ ${e.message}" }
                        }
                        busy = false
                    }
                }) { Text(tr("Зберегти ZIP у Download", "Сохранить ZIP в Download")) }
            }
        }
    }

    if (donorDlg) {
        val libFS26 = remember { DonorLib.list(ctx, "FS26") }
        val libFS23 = remember { DonorLib.list(ctx, "FS23") }
        AlertDialog(
            onDismissRequest = { donorDlg = false },
            title = { Text(tr("Автозаміна з донора", "Автозамена из донора")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tr("Програма сама знайде у донорі файли з такими самими назвами, як у вашому моді, і підмінить їх усі одразу — хоч би й тисячі. Жодних ручних дій на кожну текстуру.", "Программа сама найдёт в доноре файлы с такими же именами, как в вашем моде, и подменит их все сразу — хоть тысячи. Никаких ручных действий на каждую текстуру."), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { donorDlg = false; donorZipPicker.launch(arrayOf("*/*")) }) { Text(tr("📂 Вибрати ZIP-донор з файлів", "📂 Выбрать ZIP-донор из файлов")) }
                    if (libFS26.isNotEmpty() || libFS23.isNotEmpty()) {
                        Text(tr("Або з бібліотеки донорів (розділ «Донори»):", "Или из библиотеки доноров (раздел «Доноры»):"), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                        libFS26.forEach { f -> TextButton(onClick = { donorDlg = false; runDonorZip(f, "FS26: " + f.name) }) { Text("FS26 — " + f.name, fontSize = 13.sp) } }
                        libFS23.forEach { f -> TextButton(onClick = { donorDlg = false; runDonorZip(f, "FS23: " + f.name) }) { Text("FS23 — " + f.name, fontSize = 13.sp) } }
                    } else Text(tr("Бібліотека донорів поки порожня (розділ «Донори» на головному екрані).", "Библиотека доноров пока пуста (раздел «Доноры» на главном экране)."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    TextButton(onClick = { donorDlg = false; batchPicker.launch(arrayOf("*/*")) }) { Text(tr("Чи вибрати до ~50 файлів вручну", "Или выбрать до ~50 файлов вручную"), fontSize = 13.sp) }
                    Text(tr("Для великої кількості файлів не вибирайте їх по одному вручну — Android може впасти. Користуйтесь ZIP-донором вище.", "Для большого количества файлов не выбирайте их по одному вручную — Android может упасть. Пользуйтесь ZIP-донором выше."), fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = { TextButton(onClick = { donorDlg = false }) { Text(tr("Закрити", "Закрыть")) } }
        )
    }
}

private data class Cat(val key: String, val uk: String, val ru: String, val words: List<String>)

private val CATS = listOf(
    Cat("ground", "Земля, ґрунт, асфальт", "Земля, грунт, асфальт", listOf("ground", "dirt", "terrain", "soil", "sand", "gravel", "asphalt", "road", "stone", "rock", "mud", "grunge", "farmland", "field_", "dirtroad")),
    Cat("crops", "Культури, поля, трава", "Культуры, поля, трава", listOf("wheat", "barley", "corn", "maize", "canola", "rape", "oat", "rye", "sunflower", "soy", "potato", "beet", "cotton", "grass", "straw", "silage", "crop", "hay", "clover", "sugarcane", "spinach")),
    Cat("trees", "Дерева, рослинність", "Деревья, растительность", listOf("tree", "leaf", "leaves", "bush", "foliage", "forest", "wood", "branch", "plant", "flower")),
    Cat("effects", "Ефекти, частинки", "Эффекты, частицы", listOf("effect", "particle", "smoke", "dust", "spark", "fx_", "_fx", "glow", "lens", "decal", "splash", "fillplane", "fertiliz")),
    Cat("vehicle", "Техніка, кабіна, колеса", "Техника, кабина, колёса", listOf("wheel", "cab", "engine", "exhaust", "chassis", "body", "paint", "brand", "logo", "wrap")),
    Cat("ui", "Іконки, інтерфейс", "Иконки, интерфейс", listOf("icon", "overview", "hud", "gui", "menu", "store", "shop")),
)

/** Пошук українською/російською: слово → англійські ключові слова з CATS, якими насправді названі файли. */
private val SEARCH_SYNONYMS: Map<String, List<String>> = buildMap {
    fun byKey(k: String) = CATS.first { it.key == k }.words
    listOf("земля", "ґрунт", "грунт", "гравій", "гравия", "асфальт", "камінь", "камень", "пісок", "песок", "дорога", "поле", "ґрунтова").forEach { put(it, byKey("ground")) }
    listOf("культура", "культури", "культуры", "пшениця", "пшеница", "ячмінь", "ячмень", "кукурудза", "кукуруза", "соняшник", "подсолнух", "соя", "картопля", "картофель", "буряк", "свекла", "трава", "солома", "сіно", "сено").forEach { put(it, byKey("crops")) }
    listOf("дерево", "дерева", "деревья", "листя", "листья", "кущ", "куст", "ліс", "лес", "гілка", "ветка", "квітка", "цветок").forEach { put(it, byKey("trees")) }
    listOf("ефект", "ефекти", "эффект", "эффекты", "дим", "дым", "пил", "пыль", "іскра", "искра", "бризки", "брызги").forEach { put(it, byKey("effects")) }
    listOf("техніка", "техника", "колесо", "колеса", "кабіна", "кабина", "двигун", "двигатель", "фарба", "краска", "логотип").forEach { put(it, byKey("vehicle")) }
    listOf("іконка", "иконка", "інтерфейс", "интерфейс", "меню", "магазин").forEach { put(it, byKey("ui")) }
}

private fun categoryOf(path: String): Pair<String, String> {
    val p = path.lowercase()
    for (c in CATS) if (c.words.any { p.contains(it) }) return c.key to tr(c.uk, c.ru)
    return "other" to tr("Інше", "Прочее")
}

private fun groupTextures(list: List<TexEntry>): List<Pair<String, List<TexEntry>>> {
    val byKey = list.groupBy { categoryOf(it.path) }
    val order = CATS.map { it.key } + "other"
    return order.mapNotNull { k ->
        val entry = byKey.entries.firstOrNull { it.key.first == k }
        if (entry == null) null else (entry.key.second + " (" + entry.value.size + ")") to entry.value
    }
}
