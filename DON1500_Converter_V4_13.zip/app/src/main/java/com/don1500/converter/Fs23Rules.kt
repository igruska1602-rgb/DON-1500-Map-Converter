package com.don1500.converter

/**
 * Правила FS22 → FS23 Mobile (з інструкції автора «Depends»).
 * Тут лише детерміновані, безпечні заміни. Усе, що автоматично зробити ненадійно
 * (видалення шарів землі, дерева без аналога, позиції станцій), іде у звіт як попередження.
 */
object Fs23Rules {
    private val D = "\$data"
    private val oldMapRe = Regex(Regex.escape(D) + "/maps/map(?:US|FR|Alpine)/")
    private val groundRe = Regex(Regex.escape(D) + "/maps/textures/terrain/ground/")
    private val layerTexRe = Regex(Regex.escape(D) + "/maps/(?:map/)?textures/terrain/([A-Za-z]+?)(\\d*)_(diffuse|normal)\\.png")
    private val cacheRe = Regex("(^|/)map\\.i3d\\.terrain\\.(weights|nmap|occluders|lod\\.type)\\.cache$", RegexOption.IGNORE_CASE)

    private val foliage = listOf(
        "$D/foliage/decoFoliage/decoFoliageUS.xml" to "$D/foliage/decoFoliage/decoFoliage.xml",
        "$D/foliage/decoFoliage/decoFoliageFR.xml" to "$D/foliage/decoFoliage/decoFoliage.xml",
        "$D/foliage/decoBush/decoBushFR.xml" to "$D/foliage/decoBush/decoBush.xml",
        "$D/foliage/meadow/meadowDLC.xml" to "$D/foliage/meadow/meadowUS.xml",
        "$D/foliage/meadow/meadowFR.xml" to "$D/foliage/meadow/meadowUS.xml",
        "$D/foliage/groundFoliage/groundFoliage.xml" to "$D/foliage/decoFoliage/decoFoliage.xml"
    )

    fun isCache(rel: String) = cacheRe.containsMatchIn(rel)

    /** Знайти папку карти (maps/<mapXX>/map.xml). */
    fun mapDirOf(rels: List<String>): String? =
        rels.firstNotNullOfOrNull { Regex("^maps/([^/]+)/map\\.xml$").find(it)?.groupValues?.get(1) }

    private fun mapLayer(base: String, num: String): String? = when (base) {
        "concrete", "asphalt" -> "asphalt" + (if (num.isEmpty()) "01" else num)
        "dirt", "forestGround", "grassDirt" -> "dirt01"
        "grass" -> if (num == "04") "grass03" else "grass$num"
        "gravel", "animalMud" -> base + num
        "pathway", "riverBed", "gravelDirt" -> "gravel01"
        else -> null
    }

    /** Текстові правила для xml/i3d однієї карти. */
    fun fixText(rel: String, text: String, rep: ConvertReport): String {
        var t = text
        val name = rel.substringAfterLast('/')
        val inMap = rel.startsWith("maps/")

        // 0. Шляхи в $data/maps/mapUS|mapFR|mapAlpine → map (у FS23 Mobile є лише map і mapDE)
        var n = 0
        t = oldMapRe.replace(t) { n++; "$D/maps/map/" }
        t = groundRe.replace(t) { n++; "$D/maps/map/textures/terrain/ground/" }
        if (n > 0) rep.changes += tr("$rel: шляхів \$data/maps/mapXX → map: $n", "$rel: путей \$data/maps/mapXX → map: $n")

        if (name.endsWith(".i3d")) t = fixI3d(rel, t, rep)

        if (inMap && name == "map.xml") t = fixMapXml(rel, t, rep)

        if (name == "trafficSystem.xml") {
            val b = t
            t = Regex("\\s+licensePlates=\"[^\"]*\"").replace(t, "")
            if (t != b) rep.changes += tr("$rel: прибрано licensePlates", "$rel: убран licensePlates")
        }

        if (name == "farmlands.xml") {
            val b = t
            t = Regex("<farmlands\\b(?![^>]*infoLayerName)").replace(t) { "<farmlands infoLayerName=\"farmlands\"" }
            t = Regex("<farmland\\b(?![^>]*defaultFarmProperty)").replace(t) { "<farmland defaultFarmProperty=\"true\"" }
            t = Regex("npcName=\"[^\"]*\"").replace(t) { "npcIndex=\"1\"" }
            if (t != b) rep.changes += tr("$rel: infoLayerName, defaultFarmProperty=\"true\" для всіх ферм, npcIndex", "$rel: infoLayerName, defaultFarmProperty=\"true\" для всех ферм, npcIndex")
            rep.issues += Issue("WARN", rel, tr("Інструкція радить взяти farmlands.xml з гри (24 ферми) — візьміть з донора, якщо поля не орються", "Инструкция советует взять farmlands.xml из игры (24 фермы) — возьмите из донора, если поля не пашутся"))
        }

        if (inMap && name == "vehicles.xml" && !Regex("<vehicle\\b").containsMatchIn(t)) {
            t = STARTER_VEHICLES
            rep.changes += tr("$rel: порожній — додано стартову техніку (трактор + плуг)", "$rel: пустой — добавлена стартовая техника (трактор + плуг)")
            rep.issues += Issue("WARN", rel, tr("Стартова техніка стоїть у точці 12 / 0.5 / 30 — перевірте, що це не під землею/у воді на вашій карті", "Стартовая техника стоит в точке 12 / 0.5 / 30 — проверьте, что это не под землёй/в воде на вашей карте"))
        }
        return t
    }

    private fun fixI3d(rel: String, src: String, rep: ConvertReport): String {
        var t = src
        // Рослини
        var f = 0
        for ((a, b) in foliage) if (t.contains(a)) { t = t.replace(a, b); f++ }
        if (f > 0) rep.changes += tr("$rel: шляхів рослин (foliage) замінено: $f", "$rel: путей растений (foliage) заменено: $f")

        // Текстури шарів землі
        val unknown = LinkedHashSet<String>()
        var tex = 0
        t = layerTexRe.replace(t) { m ->
            val base = m.groupValues[1]; val num = m.groupValues[2]; val kind = m.groupValues[3]
            val mapped = mapLayer(base, num)
            if (mapped == null) { unknown += base + num; m.value }
            else { tex++; "$D/maps/map/textures/terrain/" + mapped + "_" + kind + ".png" }
        }
        if (tex > 0) rep.changes += tr("$rel: текстур шарів землі замінено на наявні в грі: $tex", "$rel: текстур слоёв земли заменено на имеющиеся в игре: $tex")
        if (unknown.isNotEmpty()) rep.issues += Issue("WARN", rel, tr("Текстури шарів без відомої заміни (перевірте за таблицею в інструкції, розділ 7.1): ", "Текстуры слоёв без известной замены (проверьте по таблице в инструкции, раздел 7.1): ") + unknown.take(12).joinToString(", "))

        val layers = Regex("<Layer\\s").findAll(t).count()
        if (layers > 17) rep.issues += Issue("WARN", rel, tr("Шарів землі: $layers. Для мобільної гри залишайте 12–17 (розділ 7.1) — видалення шарів робиться вручну, бо номери fileId не можна зачепити", "Слоёв земли: $layers. Для мобильной игры оставляйте 12–17 (раздел 7.1) — удаление слоёв делается вручную, так как номера fileId нельзя задеть"))
        if (t.contains("FoliageMultiLayer") && Regex("name=\"stone\"").containsMatchIn(t))
            rep.issues += Issue("WARN", rel, tr("Є шар «stone» (FoliageMultiLayer) — у FS23 Mobile його немає: видаліть блок, його <File> і densityMap_stones.gdm (розділ 7.3)", "Есть слой «stone» (FoliageMultiLayer) — в FS23 Mobile его нет: удалите блок, его <File> и densityMap_stones.gdm (раздел 7.3)"))
        if (Regex("(oak|spruce)\\w*(LOD|Branch|Trunk)").containsMatchIn(t))
            rep.issues += Issue("WARN", rel, tr("Дуб/ялина: замініть на americanElm* / pine* за таблицею розділу 7.4 (автоматично не робиться)", "Дуб/ель: замените на americanElm* / pine* по таблице раздела 7.4 (автоматически не делается)"))

        // Група fields (розділ 7.6)
        if (rel.substringAfterLast('/') == "map.i3d" && !t.contains("name=\"fields\"")) {
            val sceneEnd = t.lastIndexOf("</Scene>")
            val uaEnd = t.lastIndexOf("</UserAttributes>")
            if (sceneEnd >= 0 && uaEnd >= 0 && sceneEnd < uaEnd) {
                val maxId = Regex("nodeId=\"(\\d+)\"").findAll(t).maxOfOrNull { it.groupValues[1].toLong() } ?: 20000L
                val b = maxId + 1
                val groupXml = """
    <TransformGroup name="fields" nodeId="$b">
      <TransformGroup name="field01" translation="40 69.5 55" nodeId="${b + 1}">
        <TransformGroup name="fieldDimensions" translation="-50 0 -30" nodeId="${b + 2}">
          <TransformGroup name="corner01_1" nodeId="${b + 3}">
            <TransformGroup name="corner01_2" translation="100 0 0" nodeId="${b + 4}"/>
            <TransformGroup name="corner01_3" translation="100 0 60" nodeId="${b + 5}"/>
          </TransformGroup>
        </TransformGroup>
        <TransformGroup name="fieldMapIndicator" nodeId="${b + 6}"/>
      </TransformGroup>
    </TransformGroup>
"""
                val attrXml = """
    <UserAttribute nodeId="$b">
      <Attribute name="onCreate" type="scriptCallback" value="FieldUtil.onCreate"/>
    </UserAttribute>
    <UserAttribute nodeId="${b + 1}">
      <Attribute name="fieldAngle" type="integer" value="0"/>
      <Attribute name="fieldDimensionIndex" type="integer" value="0"/>
      <Attribute name="fieldGrassMission" type="boolean" value="false"/>
      <Attribute name="fieldMissionAllowed" type="boolean" value="false"/>
      <Attribute name="nameIndicatorIndex" type="integer" value="1"/>
    </UserAttribute>
"""
                // спершу пізніший індекс, щоб не збити перший
                t = t.substring(0, uaEnd) + attrXml + t.substring(uaEnd)
                t = t.substring(0, sceneEnd) + groupXml + t.substring(sceneEnd)
                rep.changes += tr("$rel: додано групу fields (nodeId $b…${b + 6}), без неї екран карти ламається", "$rel: добавлена группа fields (nodeId $b…${b + 6}), без неё экран карты ломается")
                rep.issues += Issue("WARN", rel, tr("Група fields додана з типовими координатами (40 69.5 55) — підправте під свою карту", "Группа fields добавлена с типовыми координатами (40 69.5 55) — поправьте под свою карту"))
            } else rep.issues += Issue("WARN", rel, tr("Не вдалося безпечно додати групу fields (немає </Scene> або </UserAttributes>) — додайте за розділом 7.6", "Не удалось безопасно добавить группу fields (нет </Scene> или </UserAttributes>) — добавьте по разделу 7.6"))
        }
        if (rel.startsWith("maps/") && Regex("<(Shape|Light)\\b").containsMatchIn(t) && t.length > 40_000_000)
            rep.issues += Issue("WARN", rel, tr("Дуже великий i3d — перевірте вручну", "Очень большой i3d — проверьте вручную"))
        return t
    }

    private fun fixMapXml(rel: String, src: String, rep: ConvertReport): String {
        var t = src
        val b0 = t
        t = Regex("(?s)[ \\t]*<licensePlates\\b[^>]*?/>[ \\t]*\\r?\\n?").replace(t, "")
        t = Regex("(?s)[ \\t]*<licensePlates\\b[^>]*>.*?</licensePlates>[ \\t]*\\r?\\n?").replace(t, "")
        if (t != b0) rep.changes += tr("$rel: прибрано licensePlates", "$rel: убран licensePlates")

        // helpline: trigger → zone
        var hl = 0
        t = Regex("(?s)<helpline\\b.*?</helpline>").replace(t) { blk ->
            Regex("<trigger\\s+position=\"([^\"]*)\"[^>]*/>").replace(blk.value) { m ->
                hl++; "<zone position=\"" + m.groupValues[1] + "\" radius=\"50.00\" helpId=\"helpLine_FirstSteps_Shop\"/>"
            }
        }
        if (hl > 0) rep.changes += tr("$rel: helpline trigger → zone: $hl (helpId = helpLine_FirstSteps_Shop для всіх)", "$rel: helpline trigger → zone: $hl (helpId = helpLine_FirstSteps_Shop для всех)")

        // hotspots порожні
        if (Regex("(?s)<hotspots>.*?</hotspots>").containsMatchIn(t)) {
            t = Regex("(?s)<hotspots>.*?</hotspots>").replace(t) { "<hotspots/>" }
            rep.changes += tr("$rel: hotspots очищено (у FS23 Mobile порожній блок)", "$rel: hotspots очищен (в FS23 Mobile пустой блок)")
        }

        // collectibles / culling / navigationCollision
        val end = t.lastIndexOf("</map>")
        if (end >= 0) {
            val add = StringBuilder()
            if (!t.contains("<collectibles")) { add.append("    <collectibles filename=\"$D/maps/map/collectibles.xml\"/>\n"); rep.changes += "$rel: + <collectibles>" }
            if (!t.contains("<culling")) { add.append("    <culling xzOffset=\"100\" clipDistanceThreshold1=\"150\" clipDistanceThreshold2=\"400\"/>\n"); rep.changes += "$rel: + <culling>" }
            if (!t.contains("<navigationCollision")) { add.append("    <navigationCollision revision=\"2\"/>\n"); rep.changes += "$rel: + <navigationCollision>" }
            if (add.isNotEmpty()) t = t.substring(0, end) + add.toString() + t.substring(end)
        } else rep.issues += Issue("WARN", rel, tr("Не знайдено </map> — collectibles/culling не додано", "Не найден </map> — collectibles/culling не добавлены"))

        for (f in listOf("environment.xml", "fieldGround.xml", "weed.xml", "sound.xml"))
            if (t.contains(f)) rep.issues += Issue("WARN", rel, tr("Інструкція: $f краще взяти оригінальний з гри (донор), власний з FS22 може дати чорне небо/білу землю", "Инструкция: $f лучше взять оригинальный из игры (донор), собственный из FS22 может дать чёрное небо/белую землю"))
        return t
    }

    /** Правки modDesc.xml для FS23 (після загальних). */
    fun fixModDesc(src: String, mapDir: String?, modName: String, rep: ConvertReport): String {
        var t = src
        val knw = Regex("<knw\\b[^>]*>").find(t)
        if (knw != null) {
            var tag = knw.value
            tag = if (Regex("modName\\s*=").containsMatchIn(tag)) Regex("modName\\s*=\\s*\"[^\"]*\"").replace(tag) { "modName=\"$modName\"" }
            else tag.replaceFirst("<knw", "<knw modName=\"$modName\"")
            t = t.replaceRange(knw.range, tag)
            rep.changes += tr("modDesc.xml: <knw modName> = $modName (owner/key не чіпалися)", "modDesc.xml: <knw modName> = $modName (owner/key не тронуты)")
        } else rep.issues += Issue("WARN", "modDesc.xml", tr("Немає тегу <knw …> — візьміть його з робочого мода FS23 Mobile (змінюється лише modName)", "Нет тега <knw …> — возьмите его из рабочего мода FS23 Mobile (меняется только modName)"))

        if (t.contains("<dependencies>")) rep.issues += Issue("WARN", "modDesc.xml", tr("Є <dependencies> — якщо цей мод вбудований у карту, блок треба видалити (розділ 3)", "Есть <dependencies> — если этот мод встроен в карту, блок нужно удалить (раздел 3)"))

        if (mapDir != null) {
            val p = "maps/$mapDir/scripts/MapFrameFix.lua"
            if (!t.contains(p)) {
                val line = "<sourceFile filename=\"$p\"/>"
                t = if (t.contains("<extraSourceFiles>")) t.replaceFirst("<extraSourceFiles>", "<extraSourceFiles>\n        $line")
                else if (t.contains("</modDesc>")) t.replaceFirst("</modDesc>", "    <extraSourceFiles>\n        $line\n    </extraSourceFiles>\n</modDesc>")
                else t
                rep.changes += tr("modDesc.xml: підключено MapFrameFix.lua (обхід вильоту екрана карти)", "modDesc.xml: подключён MapFrameFix.lua (обход вылета экрана карты)")
            }
        } else rep.issues += Issue("WARN", "modDesc.xml", tr("Не знайдено maps/<папка>/map.xml — MapFrameFix.lua не підключено", "Не найден maps/<папка>/map.xml — MapFrameFix.lua не подключён"))
        return t
    }

    fun mapFrameFix(nick: String): String =
        (if (nick.isNotBlank()) "-- $nick\n" else "") + """
-- Обхід вильоту екрана карти FS23 Mobile (розділ 8 інструкції).
-- Це обхід, а не знайдена причина.
local C = InGameMenuMobileMapFrame
if C ~= nil and C.getNumberOfItemsInSection ~= nil then
    local orig = C.getNumberOfItemsInSection
    C.getNumberOfItemsInSection = function(self, ...)
        local ok, res = pcall(orig, self, ...)
        if ok and type(res) == "number" then return res end
        return 0
    end
end
if C ~= nil and C.updatePointsFilterMapping ~= nil then
    local orig2 = C.updatePointsFilterMapping
    C.updatePointsFilterMapping = function(self, ...)
        local ok, res = pcall(orig2, self, ...)
        if not ok then return nil end
        return res
    end
end
""".trimStart()

    private val STARTER_VEHICLES = """<?xml version="1.0" encoding="utf-8" standalone="no" ?>
<vehicles>
    <vehicle filename="data/vehicles/johnDeere/series4755/series4755.xml"
             id="1" farmId="1" propertyState="1"
             xPosition="12.0" yOffset="0.5" zPosition="30.0"
             yRotation="-90" defaultFarmProperty="true" />
    <vehicle filename="data/vehicles/kverneland/ecomat/ecomat.xml"
             id="2" farmId="1" propertyState="1"
             xPosition="16.5" yOffset="0.5" zPosition="30.0"
             yRotation="-90" defaultFarmProperty="true" />
    <attachments rootVehicleId="1">
        <attachment attachmentId="2" inputJointDescIndex="1"
                    jointIndex="1" moveDown="false"/>
    </attachments>
</vehicles>
"""
}

/** Підпис автора: кілька місць у моді. Гру це не обмежує, а видалити його вручну технічно можна. */
object DonMark {
    private val stampable = Regex("^maps/[^/]+/(map\\.xml|farmlands\\.xml|vehicles\\.xml|placeables\\.xml|items\\.xml|map\\.i3d)$")

    fun clean(nick: String): String {
        var n = Regex("[<>&\"]").replace(nick.take(40), "")
        while (n.contains("--")) n = n.replace("--", "-")
        return n.trim()
    }

    fun shouldStamp(rel: String) = stampable.matches(rel)

    /** Коментар-мітка всередині кореневого тегу (як і в modDesc). */
    fun stamp(text: String, nick0: String): String {
        val nick = clean(nick0)
        if (nick.isEmpty() || text.contains("DON1500-MARK")) return text
        val m = Regex("<[A-Za-z][^>]*>").find(text) ?: return text
        if (m.value.endsWith("/>")) return text
        val marker = "<!-- DON1500-MARK $nick -->"
        return text.substring(0, m.range.last + 1) + "\n    " + marker + text.substring(m.range.last + 1)
    }

    fun credits(nick0: String): String {
        val nick = clean(nick0)
        return "$nick\n" +
            "Converted / created with DON-1500 Converter by $nick.\n" +
            "Перетворено / створено програмою DON-1500 Converter, автор: $nick.\n"
    }
}
