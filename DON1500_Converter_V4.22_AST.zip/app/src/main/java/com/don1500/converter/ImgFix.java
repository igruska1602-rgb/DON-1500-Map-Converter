package com.don1500.converter;

import java.io.ByteArrayOutputStream;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/** Допоміжні функції зображень без залежностей від Android: «затікання» кольору під прозорі пікселі, запис PNG, підбір розміру. */
public final class ImgFix {
    private ImgFix() {}

    public static boolean hasAlpha(int[] px) { for (int v : px) if ((v >>> 24) != 255) return true; return false; }

    /**
     * Прибирає темні ореоли навколо написів: у повністю прозорих пікселях колір береться з найближчих видимих сусідів
     * (інакше там чорний, і при зменшенні/стисненні він підмішується до країв літер). Повертає НОВИЙ масив.
     */
    public static int[] bleed(int[] src, int w, int h) {
        int[] px = src.clone();
        int n = w * h;
        boolean[] known = new boolean[n];
        int unknown = 0;
        for (int i = 0; i < n; i++) { known[i] = (px[i] >>> 24) != 0; if (!known[i]) unknown++; }
        if (unknown == 0 || unknown == n) return px;
        int[] fill = new int[n];
        boolean[] newly = new boolean[n];
        int maxPass = Math.max(8, Math.min(64, Math.max(w, h) / 8));
        for (int pass = 0; pass < maxPass && unknown > 0; pass++) {
            int found = 0;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    if (known[i]) continue;
                    int r = 0, g = 0, b = 0, c = 0;
                    for (int dy = -1; dy <= 1; dy++) {
                        int yy = y + dy; if (yy < 0 || yy >= h) continue;
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx; if (xx < 0 || xx >= w) continue;
                            int j = yy * w + xx;
                            if (!known[j]) continue;
                            int v = px[j]; r += (v >> 16) & 255; g += (v >> 8) & 255; b += v & 255; c++;
                        }
                    }
                    if (c > 0) { fill[i] = (r / c << 16) | (g / c << 8) | (b / c); newly[i] = true; found++; }
                }
            }
            if (found == 0) break;
            for (int i = 0; i < n; i++) if (newly[i]) { px[i] = fill[i]; known[i] = true; newly[i] = false; unknown--; }
        }
        return px; // альфа лишається 0, змінюється лише колір
    }

    // ---------- PNG (RGBA 8 біт) ----------
    private static void chunk(ByteArrayOutputStream o, String type, byte[] data, int len) {
        byte[] t = type.getBytes();
        o.write(len >>> 24); o.write(len >>> 16); o.write(len >>> 8); o.write(len);
        o.write(t, 0, 4); o.write(data, 0, len);
        CRC32 c = new CRC32(); c.update(t); c.update(data, 0, len);
        long v = c.getValue(); o.write((int) (v >>> 24)); o.write((int) (v >>> 16)); o.write((int) (v >>> 8)); o.write((int) v);
    }

    /** Кольори прозорих пікселів зберігаються як є (на відміну від Bitmap, який їх обнуляє). */
    public static byte[] png(int[] argb, int w, int h) {
        boolean alpha = hasAlpha(argb);
        int bpp = alpha ? 4 : 3;
        int stride = w * bpp;
        byte[] raw = new byte[(stride + 1) * h];
        byte[] cur = new byte[stride], prev = new byte[stride], best = new byte[stride], tmp = new byte[stride];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int v = argb[y * w + x]; int o = x * bpp;
                cur[o] = (byte) (v >> 16); cur[o + 1] = (byte) (v >> 8); cur[o + 2] = (byte) v;
                if (alpha) cur[o + 3] = (byte) (v >>> 24);
            }
            int bestF = 0; long bestS = Long.MAX_VALUE;
            for (int f = 0; f < 3; f++) {
                long s = 0;
                for (int i = 0; i < stride; i++) {
                    int a = i >= bpp ? cur[i - bpp] & 255 : 0, b = prev[i] & 255, c = cur[i] & 255;
                    int p = f == 0 ? c : (f == 1 ? c - a : c - b);
                    tmp[i] = (byte) p; s += Math.abs((byte) p);
                }
                if (s < bestS) { bestS = s; bestF = f; System.arraycopy(tmp, 0, best, 0, stride); }
            }
            raw[y * (stride + 1)] = (byte) bestF;
            System.arraycopy(best, 0, raw, y * (stride + 1) + 1, stride);
            byte[] sw = prev; prev = cur; cur = sw;
        }
        Deflater d = new Deflater(6);
        d.setInput(raw); d.finish();
        ByteArrayOutputStream z = new ByteArrayOutputStream(raw.length / 2 + 64);
        byte[] buf = new byte[1 << 16];
        while (!d.finished()) { int k = d.deflate(buf); z.write(buf, 0, k); }
        d.end();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] sig = {(byte) 137, 80, 78, 71, 13, 10, 26, 10};
        o.write(sig, 0, 8);
        byte[] ihdr = new byte[13];
        ihdr[0] = (byte) (w >>> 24); ihdr[1] = (byte) (w >>> 16); ihdr[2] = (byte) (w >>> 8); ihdr[3] = (byte) w;
        ihdr[4] = (byte) (h >>> 24); ihdr[5] = (byte) (h >>> 16); ihdr[6] = (byte) (h >>> 8); ihdr[7] = (byte) h;
        ihdr[8] = 8; ihdr[9] = (byte) (alpha ? 6 : 2);
        chunk(o, "IHDR", ihdr, 13);
        byte[] zb = z.toByteArray();
        chunk(o, "IDAT", zb, zb.length);
        chunk(o, "IEND", new byte[0], 0);
        return o.toByteArray();
    }

    // ---------- авто-розмір ----------
    private static int[] boxDown(int[] p, int w, int h, int nw, int nh) {
        int[] o = new int[nw * nh];
        for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
            long r = 0, g = 0, b = 0, a = 0, wsum = 0; int cnt = 0;
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) {
                int v = p[Math.min(h - 1, y * 2 + dy) * w + Math.min(w - 1, x * 2 + dx)];
                int al = v >>> 24; a += al; cnt++;
                r += (long) ((v >> 16) & 255) * al; g += (long) ((v >> 8) & 255) * al; b += (long) (v & 255) * al; wsum += al;
            }
            int rr, gg, bb;
            if (wsum > 0) { rr = (int) ((r + wsum / 2) / wsum); gg = (int) ((g + wsum / 2) / wsum); bb = (int) ((b + wsum / 2) / wsum); }
            else { rr = gg = bb = 0; }
            o[y * nw + x] = (((int) ((a + 2) / 4)) << 24) | (rr << 16) | (gg << 8) | bb;
        }
        return o;
    }

    /**
     * Підбирає найменший розмір (довша сторона), при якому зменшення майже не втрачає деталей.
     * level: 0 = максимальне стиснення, 1 = баланс, 2 = якість. strict — суворіше (карти нормалей).
     */
    public static int autoSize(int[] px, int w, int h, int level, boolean strict) {
        final int m = Math.max(w, h);
        double thr = level <= 0 ? 27.0 : (level == 1 ? 31.0 : 36.0);
        if (strict) thr += 4.0;
        int bestK = 0;
        int[] cur = px; int cw = w, ch = h;
        for (int k = 1; k < 10; k++) {
            int nw = Math.max(1, cw / 2), nh = Math.max(1, ch / 2);
            if (Math.max(nw, nh) < 16) break;
            cur = boxDown(cur, cw, ch, nw, nh); cw = nw; ch = nh;
            double se = 0, ws = 0;
            for (int y = 0; y < h; y++) {
                int sy = Math.min(ch - 1, (int) ((long) y * ch / h));
                for (int x = 0; x < w; x++) {
                    int sx = Math.min(cw - 1, (int) ((long) x * cw / w));
                    int a = px[y * w + x], b = cur[sy * cw + sx];
                    double wt = (a >>> 24) / 255.0;
                    if (wt == 0) continue;
                    int dr = ((a >> 16) & 255) - ((b >> 16) & 255), dg = ((a >> 8) & 255) - ((b >> 8) & 255), db = (a & 255) - (b & 255);
                    int da = (a >>> 24) - (b >>> 24);
                    se += wt * (dr * dr + dg * dg + db * db) / 3.0 + 0.25 * da * da; ws += wt;
                }
            }
            double mse = ws > 0 ? se / ws : 0;
            double psnr = mse < 1e-9 ? 99 : 10 * Math.log10(255.0 * 255.0 / mse);
            if (psnr >= thr) bestK = k; else break;
        }
        return Math.max(1, m >> bestK);
    }
}
