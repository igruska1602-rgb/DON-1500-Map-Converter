package com.don1500.converter;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Контейнер GS2D (.ast) FS26 Mobile: 52-байтний заголовок + ASTC 6x6 блоки, мипи від найменшого до найбільшого,
 * кожен рівень записаний віддзеркаленим по вертикалі. Структура виведена з реальних файлів гри (див. AST_NOTES.md).
 */
public final class Gs2d {
    private Gs2d() {}

    public static final class Img {
        public final int w, h; public final int[] px;
        public Img(int w, int h, int[] px) { this.w = w; this.h = h; this.px = px; }
    }
    public interface Progress { void on(float f); }

    private static final int HDR = 52;
    // порядок блоків ASTC: код формату = 0x1E + індекс (підтверджено лише для 6x6 = 0x22)
    private static final int[][] FOOT = {{4,4},{5,4},{5,5},{6,5},{6,6},{8,5},{8,6},{8,8},{10,5},{10,6},{10,8},{10,10},{12,10},{12,12}};

    private static int le32(byte[] b, int o) { return (b[o] & 255) | ((b[o+1] & 255) << 8) | ((b[o+2] & 255) << 16) | ((b[o+3] & 255) << 24); }
    private static void put32(byte[] b, int o, int v) { b[o] = (byte) v; b[o+1] = (byte) (v >> 8); b[o+2] = (byte) (v >> 16); b[o+3] = (byte) (v >>> 24); }

    private static int[][] levelDims(int w, int h, int levels) {
        int[][] r = new int[levels][2];
        for (int i = 0; i < levels; i++) { r[i][0] = w; r[i][1] = h; w = Math.max(1, w / 2); h = Math.max(1, h / 2); }
        return r;
    }

    /** null = файл підтримується, інакше текст причини. */
    public static String probe(byte[] f) {
        try { parse(f); return null; } catch (IllegalArgumentException e) { return e.getMessage(); }
    }

    private static final class Info { int w, h, levels, bw, bh; int[][] dims; long[] off; }

    private static Info parse(byte[] f) {
        if (f.length < HDR || f[0] != 'G' || f[1] != 'S' || f[2] != '2' || f[3] != 'D') throw new IllegalArgumentException("не GS2D (.ast) файл");
        int ver = le32(f, 4);
        if (ver != 8) throw new IllegalArgumentException("версія GS2D " + ver + " не підтримується (потрібна 8)");
        Info in = new Info();
        in.w = le32(f, 8); in.h = le32(f, 12);
        if (in.w <= 0 || in.h <= 0 || (long) in.w * in.h > 8192L * 8192L) throw new IllegalArgumentException("некоректний розмір " + in.w + "x" + in.h);
        int fmt = f[0x2c] & 255;
        int idx = fmt - 0x1E;
        if (idx < 0 || idx >= FOOT.length) throw new IllegalArgumentException("невідомий код формату 0x" + Integer.toHexString(fmt));
        in.bw = FOOT[idx][0]; in.bh = FOOT[idx][1];
        in.levels = (f[0x15] & 255) + 1;
        in.dims = levelDims(in.w, in.h, in.levels);
        long total = HDR;
        long[] sizes = new long[in.levels];
        for (int i = 0; i < in.levels; i++) sizes[i] = (long) ((in.dims[i][0] + in.bw - 1) / in.bw) * ((in.dims[i][1] + in.bh - 1) / in.bh) * 16;
        for (long s : sizes) total += s;
        if (total != f.length) throw new IllegalArgumentException("незнайомий розклад файлу (розмір " + f.length + " ≠ очікуваних " + total + ") — потрібен зразок такого .ast");
        in.off = new long[in.levels];
        long o = HDR;
        for (int i = in.levels - 1; i >= 0; i--) { in.off[i] = o; o += sizes[i]; } // найменший рівень іде першим
        return in;
    }

    /** Декодує найбільший рівень, не більший за maxDim (0 = найбільший). */
    public static Img decode(byte[] f, int maxDim) {
        final Info in = parse(f);
        int lv = 0;
        if (maxDim > 0) while (lv < in.levels - 1 && Math.max(in.dims[lv][0], in.dims[lv][1]) > maxDim) lv++;
        final int w = in.dims[lv][0], h = in.dims[lv][1];
        final int bx = (w + in.bw - 1) / in.bw, by = (h + in.bh - 1) / in.bh;
        final int[] px = new int[w * h];
        final long base = in.off[lv];
        final int bw = in.bw, bh = in.bh;
        final AtomicInteger next = new AtomicInteger();
        Runnable job = () -> {
            int[] blk = new int[bw * bh];
            int j;
            while ((j = next.getAndIncrement()) < by) {
                for (int i = 0; i < bx; i++) {
                    Astc.decodeBlock(f, (int) (base + ((long) j * bx + i) * 16), bw, bh, blk);
                    for (int y = 0; y < bh; y++) {
                        int py = j * bh + y; if (py >= h) break;
                        int row = (h - 1 - py) * w; // віддзеркалення по вертикалі
                        for (int x = 0; x < bw; x++) { int pxx = i * bw + x; if (pxx >= w) break; px[row + pxx] = blk[y * bw + x]; }
                    }
                }
            }
        };
        runParallel(job);
        return new Img(w, h, px);
    }

    private static void runParallel(Runnable job) {
        int n = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
        Thread[] ts = new Thread[n];
        for (int i = 0; i < n; i++) { ts[i] = new Thread(job); ts[i].start(); }
        for (Thread t : ts) { try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    }

    private static int[] half(int[] p, int w, int h, int nw, int nh, boolean weighted) {
        int[] o = new int[nw * nh];
        for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
            long a = 0, r = 0, g = 0, b = 0, ws = 0; long r0 = 0, g0 = 0, b0 = 0;
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) {
                int v = p[Math.min(h - 1, y * 2 + dy) * w + Math.min(w - 1, x * 2 + dx)];
                int al = v >>> 24; a += al;
                int vr = (v >> 16) & 255, vg = (v >> 8) & 255, vb = v & 255;
                r += (long) vr * al; g += (long) vg * al; b += (long) vb * al; ws += al;   // зважено альфою: прозорі пікселі не темнять кольори
                r0 += vr; g0 += vg; b0 += vb;
            }
            int rr, gg, bb;
            if (weighted && ws > 0) { rr = (int) ((r + ws / 2) / ws); gg = (int) ((g + ws / 2) / ws); bb = (int) ((b + ws / 2) / ws); }
            else { rr = (int) ((r0 + 2) / 4); gg = (int) ((g0 + 2) / 4); bb = (int) ((b0 + 2) / 4); }
            o[y * nw + x] = (((int) ((a + 2) / 4)) << 24) | (rr << 16) | (gg << 8) | bb;
        }
        return o;
    }

    /** ARGB → .ast (ASTC 6x6, повний ланцюжок мипів). */
    public static byte[] encode(int[] argb, int w, int h, Progress pr) {
        List<int[]> lv = new ArrayList<>(); List<int[]> dm = new ArrayList<>();
        final boolean halo = ImgFix.fixHalo && ImgFix.hasAlpha(argb);
        int[] cur = halo ? ImgFix.bleed(argb, w, h) : argb; int cw = w, ch = h;
        lv.add(cur); dm.add(new int[]{cw, ch});
        while (cw > 1 || ch > 1) {
            int nw = Math.max(1, cw / 2), nh = Math.max(1, ch / 2);
            cur = half(cur, cw, ch, nw, nh, halo); cw = nw; ch = nh;
            lv.add(cur); dm.add(new int[]{cw, ch});
        }
        int n = lv.size();
        long[] sz = new long[n]; long total = HDR;
        for (int i = 0; i < n; i++) { sz[i] = (long) ((dm.get(i)[0] + 5) / 6) * ((dm.get(i)[1] + 5) / 6) * 16; total += sz[i]; }
        if (total > Integer.MAX_VALUE - 16) throw new IllegalArgumentException("текстура завелика");
        final byte[] out = new byte[(int) total];
        long blocksAll = (total - HDR) / 16; final AtomicInteger done = new AtomicInteger();
        long o = HDR;
        for (int i = n - 1; i >= 0; i--) { // від найменшого
            final int[] px = lv.get(i); final int lw = dm.get(i)[0], lh = dm.get(i)[1];
            final int bx = (lw + 5) / 6, by = (lh + 5) / 6; final int base = (int) o;
            final AtomicInteger next = new AtomicInteger();
            final long ba = blocksAll;
            Runnable job = () -> {
                Astc.Encoder enc = new Astc.Encoder(); int[] blk = new int[36];
                int j;
                while ((j = next.getAndIncrement()) < by) {
                    for (int bi = 0; bi < bx; bi++) {
                        for (int y = 0; y < 6; y++) {
                            int py = Math.min(lh - 1, j * 6 + y);
                            int srow = (lh - 1 - py) * lw; // віддзеркалення
                            for (int x = 0; x < 6; x++) blk[y * 6 + x] = px[srow + Math.min(lw - 1, bi * 6 + x)];
                        }
                        enc.encode(blk, out, base + (j * bx + bi) * 16);
                    }
                    int d = done.addAndGet(bx);
                    if (pr != null) pr.on(Math.min(1f, d / (float) ba));
                }
            };
            runParallel(job);
            o += sz[i];
        }
        put32(out, 0, 0x44325347); put32(out, 4, 8); put32(out, 8, w); put32(out, 12, h); put32(out, 16, 1);
        if (n == 1) { out[0x14] = 4; out[0x15] = 0; } else { out[0x14] = 3; out[0x15] = (byte) (n - 1); }
        out[0x16] = 1; out[0x17] = 0; put32(out, 0x18, 4);
        try {
            MessageDigest md = MessageDigest.getInstance("MD5"); md.update(out, HDR, out.length - HDR);
            System.arraycopy(md.digest(), 0, out, 0x1c, 16);
        } catch (Exception e) { throw new RuntimeException(e); }
        out[0x2c] = 0x22; out[0x2d] = 0; out[0x2e] = 1; out[0x2f] = 1; out[0x30] = 0; out[0x31] = 0; out[0x32] = 0; out[0x33] = 8;
        return out;
    }

    private static int rd32(byte[] b, int o) { return (b[o] & 255) | ((b[o + 1] & 255) << 8) | ((b[o + 2] & 255) << 16) | ((b[o + 3] & 255) << 24); }
    private static void wr32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }

    /**
     * DDS (DX10, DXGI 10 = RGBA16F, один мип, N шарів) → GS2D формат 0x05: таблиця шляху гусениць (trackArray / motionPathRubber).
     * Розклад знято з 40+ справжніх файлів FS26 Mobile (crawlers_Depends): 0x14=4, 0x15=0, 0x16=кількість шарів, 0x18=4, формат 0x05,
     * далі «00 01 06 00 00 00 18», MD5 даних, дані = сирі half-float RGBA (w·h·8·N байт). Повертає null, якщо DDS не такого виду.
     */
    public static byte[] fromDx10Float(byte[] dds) {
        if (dds == null || dds.length < 148 || dds[0] != 'D' || dds[1] != 'D' || dds[2] != 'S' || dds[3] != ' ') return null;
        if (dds[84] != 'D' || dds[85] != 'X' || dds[86] != '1' || dds[87] != '0') return null;
        if (rd32(dds, 128) != 10) return null;
        int h = rd32(dds, 12), w = rd32(dds, 16), mips = rd32(dds, 28), arr = rd32(dds, 140);
        if (w < 1 || h < 1 || arr < 1 || arr > 255 || mips > 1) return null;
        long n = (long) w * h * 8L * arr;
        if (n > Integer.MAX_VALUE - 64 || dds.length - 148L < n) return null;
        byte[] out = new byte[52 + (int) n];
        out[0] = 'G'; out[1] = 'S'; out[2] = '2'; out[3] = 'D';
        wr32(out, 4, 8); wr32(out, 8, w); wr32(out, 12, h); wr32(out, 16, 1);
        out[0x14] = 4; out[0x15] = 0; out[0x16] = (byte) arr; out[0x17] = 0; wr32(out, 0x18, 4);
        System.arraycopy(dds, 148, out, 52, (int) n);
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            md.update(out, 52, (int) n);
            System.arraycopy(md.digest(), 0, out, 0x1c, 16);
        } catch (java.security.NoSuchAlgorithmException e) { return null; }
        out[0x2c] = 5; out[0x2d] = 0; out[0x2e] = 1; out[0x2f] = 6; out[0x30] = 0; out[0x31] = 0; out[0x32] = 0; out[0x33] = 0x18;
        return out;
    }
}
