# Гусениці (crawlers) FS22/FS23 → FS26 Mobile

Джерело: пакет `crawlers_Depends_1.zip` (справжні crawler-и FS26 Mobile: 50 .i3d, 270+ .ast).

## crawler XML (формат майже той самий)
```xml
<crawler>
  <file name="…Crawler.i3d" leftNode="0|0" rightNode="0|1"/>
  <scrollerNodes><scrollerNode node="0" scrollSpeed="-0.1" scrollLength="1" shaderParameterName="scrollPos" shaderParameterComponent="1"/></scrollerNodes>
  <rotatingParts><rotatingPart node="1" radius="0.468"/> …</rotatingParts>
</crawler>
```
FS22 → FS26: `shaderParameterName="scrollPosition"` → `scrollPos`; `scrollLength="10.4"` → `1` (довжину переносимо в матеріал).

## Матеріал гусениці в i3d
- `customShaderVariation`: FS26 має `motionPathRubber`, `motionPathRubber_vmaskUV2`, `motionPath`, `motionPath_vmaskUV2`, `vmaskUV2`, `vmaskUV2_normalUV3`, `vtxRotate`, `reflector`, `meshScroll`, `meshScroll_vmaskUV2`, `visibilityCut`, `jiggling`, `staticLight`, `uvTransform`. FS22 `motionPathRubber_secondUV_colorMask` → `motionPathRubber_vmaskUV2` (colorMask прибрати, secondUV → vmaskUV2).
- `<Custommap name="mTrackArray">` → `<Custommap name="trackArray">`.
- CustomParameter `scrollPosition`, `prevScrollPosition`, `lengthAndRadius` прибрати; додати `crawlerRealLength` = довжина гусениці в метрах (стара scrollLength; у FS26 це приблизно ширина масиву / 10).

## trackArray: DDS (DX10, RGBA16F) → GS2D-.ast, формат 0x05
Заголовок 52 байти: `GS2D`, ver 8, w, h, 1, 0x14=4, 0x15=0, **0x16 = кількість шарів (arraySize)**, 0x18=4, MD5 даних (0x1C), **0x2C = 0x05**, 0x2D..0x33 = `00 01 06 00 00 00 18`; далі сирі half-float RGBA: w·h·8·шарів байт. Перевірено: з даних справжнього `.ast` + DX10-заголовка наш `Gs2d.fromDx10Float` відтворює файл гри БАЙТ У БАЙТ (mach4R, dxt2500). В одному файлі гри (camoplast) останній байт 0xB7 замість 0x18 — призначення невідоме. Посилання в i3d: `.ast` напряму або `.png` (ASTP), обидва є в грі.
