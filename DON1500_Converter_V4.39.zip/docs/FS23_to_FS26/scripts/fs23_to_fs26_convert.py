#!/usr/bin/env python3
"""
FS23 (FS22-engine, mobile) -> FS26 mobile : single-vehicle converter  (v0.2, XML level + shader-variation fix)

usage:
  python3 fs23_to_fs26_convert.py --src <unzipped FS23 mod> --vehicle mtz82.xml --out <out dir>
          [--title "MTZ-82"] [--brand-name BELARUS --brand-image store/brandBF.png] [--detail-maps]

What it does (see docs/CONVERSION_REPORT.md for WHY each step exists):
  1. sanitize vehicle xml (broken "<!-->" comments), drop FS23-only blocks, rename colour configs, category
  2. collect every file the vehicle needs (xml -> i3d -> textures/shapes, wheels, sounds, store images)
  3. wheels xml: drop isCareWheel, add fs25 wheel.xsd
  4. i3d: "\" -> "/", remove shader variations FS26 does not have, drop FS22-only shader params,
          morphPosition -> morphPos, give mask-coloured materials a colorScale
  5. sound xml: .wav -> .ogg where the .ogg exists
  6. generate FS26-mobile modDesc.xml
  7. validate (xml well-formed + every referenced file exists)
--detail-maps  EXPERIMENTAL (untested in game): add detailDiffuse/Normal/Specular custommaps from $data/shared/detailLibrary
"""
import argparse,os,re,shutil,sys,xml.etree.ElementTree as ET

# ---- knowledge learned from the FS26-mobile log + working FS26 reference mod -------------------------
BAD_VARIATIONS={'colorMask','Decal','uvScroll','windBend'}      # not present in FS26 vehicleShader -> engine: "Can't load resource ...vehicleShader.xml" -> crash
OK_VARIATIONS={'staticLight','staticLight_vertex','tirePressureDeformation','uvTransform','vmaskUV2','additive_colorScale'}  # seen in working FS26 mod
DROP_PARAMS={'RDT','offsetUV','directionBend','prevDirectionBend','blinkOffset','prevMorphPosition'}|{f'colorMat{i}' for i in range(8)}
DROP_BLOCKS=['simpleIC','baseMaterial','audioMemoryUsage']      # script-driven / FS22-only
COLOR_NAMES={'Blue':'Blue','Red':'Red','Black':'Black','Green':'Green','Orange':'Orange','Gray':'Grey','White':'White'}
DETAIL='$data/shared/detailLibrary/'
DETAIL_SETS={  # (diffuse, normal, specular) triples taken from the working FS26 mod
 'paint':(DETAIL+'nonMetallic/metal/metalPaintedOld_diffuse.png',DETAIL+'flat_normal.png',DETAIL+'nonMetallic/metal/metalPaintedOld_specular.png'),
 'rubber':(DETAIL+'nonMetallic/rubber/rubberBlack_diffuse.png',DETAIL+'nonMetallic/rubber/rubber_normal.png',DETAIL+'nonMetallic/rubber/rubber_specular.png'),
 'chrome':(DETAIL+'metallic/clear_diffuse.png',DETAIL+'flat_normal.png',DETAIL+'metallic/clear_specular.png'),
}
OPEN=r'<%s(?=[\s>/])(?:"[^"]*"|[^>"])*>'
log=[]
def say(m): log.append(m); print(m)

def drop_block(s,tag):
    pat=re.compile((OPEN%tag)+r'.*?</%s>[ \t]*\r?\n?'%tag,re.S); n=len(pat.findall(s)); return pat.sub('',s),n

def convert_vehicle_xml(src,vehicle):
    s=open(f'{src}/{vehicle}',encoding='utf-8-sig').read()
    # (a) one-line "<!-->text<!-->" pairs: only the marker text is removed (harmless);
    # (b) a dangling multi-line block "<!-->name<!--  <element>...</element> <!-->" is removed whole.  Never match across unrelated lines.
    s,n1=re.subn(r'<!-->[^\n<]*<!-->','',s)
    s,n2=re.subn(r'[ \t]*<!-->[^\n]*?<!--.*?<!-->[ \t]*\r?\n?','',s,flags=re.S); say(f'sanitize: {n1} one-line + {n2} multi-line malformed "<!-->" comment(s) removed')
    for t in DROP_BLOCKS:
        s,n=drop_block(s,t); say(f'drop <{t}> x{n}')
    s,n=re.subn(r'<(/?)(base|design)Material(\d*)Configuration(s?)\b',lambda m:f'<{m[1]}{m[2]}Color{m[3]}Configuration{m[4]}',s); say(f'rename *MaterialConfiguration -> *ColorConfiguration x{n}')
    def fixcolor(m):
        tag,attrs=m.group(1),m.group(2)
        cm=re.search(r'color="([^"]*)"',attrs)
        if cm:
            v=cm.group(1).split()
            if len(v)>=4: attrs=attrs.replace(cm.group(0),f'color="{" ".join(v[:3])}" material="{int(float(v[3]))}"')
        attrs=re.sub(r'name="\$l10n_(\w+)"',lambda k:f'name="$l10n_ui_color{COLOR_NAMES[k[1]]}"' if k[1] in COLOR_NAMES else k[0],attrs)
        return f'<{tag}{attrs}'
    s=re.sub(r'<((?:base|design)Color\d*Configuration)(\s[^>]*)',fixcolor,s)
    # rim colours: only strip the 4th component (log: "Invalid rgb color '0.35 0.05 0.04 6' in rimColorConfiguration"); names left as in the tested build
    def rim(m):
        v=m.group(2).split(); return f'{m.group(1)}color="{" ".join(v[:3])}"' + (f' material="{int(float(v[3]))}"' if len(v)>=4 else '')
    s=re.sub(r'(<rimColorConfiguration\s[^>]*?)color="([^"]*)"',rim,s)
    s=re.sub(r'<category>[^<]*</category>','<category>tractorsS</category>',s,count=1)
    ET.fromstring(s.encode()); say('vehicle xml is well-formed')
    return s

def refs_in_xml(t):
    r=re.findall(r'(?:filename|xmlFilename|file|image|iconFilename)="([^"$][^"]*)"',t)+re.findall(r'<(?:filename|image)>([^<$]+)</',t)
    return [x.strip().replace('\\','/') for x in r if not x.startswith('http') and '.' in os.path.basename(x)]

def collect(src,vehicle,vxml):
    need=set(); seen=set(); q=[vehicle]
    while q:
        rel=q.pop()
        if rel in seen: continue
        seen.add(rel); p=f'{src}/{rel}'
        if not os.path.exists(p):
            alt=rel[:-4]+'.ogg' if rel.endswith('.wav') else None
            if alt and os.path.exists(f'{src}/{alt}'): need.add(alt)
            elif rel!=vehicle: say(f'MISSING in source: {rel}')
            continue
        need.add(rel); base=os.path.dirname(rel)
        if rel==vehicle: t=vxml
        elif rel.endswith('.xml'): t=open(p,encoding='utf-8-sig',errors='ignore').read()
        elif rel.endswith('.i3d'):
            t=open(p,encoding='latin-1').read()
            for r in re.findall(r'<File [^>]*filename="([^"]+)"',t):
                if not r.startswith('$'): q.append(os.path.normpath(os.path.join(base,r.replace('\\','/'))))
            q.append(rel+'.shapes'); continue
        else: continue
        q+=refs_in_xml(t)
    return need

def patch_i3d_text(s,stats,detail_maps):
    s=re.sub(r'(<File [^>]*filename=")([^"]+)"',lambda m:m[1]+m[2].replace('\\','/')+'"',s)
    def fix(m):
        mat=m.group(0)
        vm=re.search(r' customShaderVariation="([^"]*)"',mat); was_mask=bool(vm and vm.group(1)=='colorMask')
        cm0=re.search(r'<CustomParameter name="colorMat0" value="([^"]*)"',mat); has_diff='<Texture ' in mat
        if vm and vm.group(1) in BAD_VARIATIONS: mat=mat.replace(vm.group(0),''); stats['variations']+=1
        def par(pm):
            n=pm.group(1)
            if n in DROP_PARAMS: stats['params']+=1; return ''
            if n=='morphPosition': stats['morph']+=1; return pm.group(0).replace('morphPosition','morphPos')
            return pm.group(0)
        mat=re.sub(r'[ \t]*<CustomParameter name="([^"]+)" value="[^"]*"\s*/>[ \t]*\r?\n?',par,mat)
        if was_mask and not has_diff and cm0 and 'name="colorScale"' not in mat:
            mat=mat.replace('</Material>','  <CustomParameter name="colorScale" value="%s"/>\n    </Material>'%' '.join(cm0.group(1).split()[:3])); stats['colorScale']+=1
        return mat
    s=re.sub(r'<Material .*?</Material>',fix,s,flags=re.S)
    if detail_maps: s=add_detail_maps(s,stats)
    return s

def add_detail_maps(s,stats):
    ids=[int(x) for x in re.findall(r'<File fileId="(\d+)"',s)]; nxt=[max(ids+[0])+1]; added={}
    def fid(path):
        if path not in added:
            added[path]=nxt[0]; nxt[0]+=1
        return added[path]
    def fix(m):
        mat=m.group(0)
        if 'detailDiffuse' in mat or 'customShaderId=' not in mat: return mat
        name=re.search(r'name="([^"]*)"',mat).group(1).lower()
        k='rubber' if re.search('tire|rubber|tyre',name) else 'chrome' if re.search('chrome|mirror|metal',name) else 'paint'
        d,n,sp=DETAIL_SETS[k]
        add=f'      <Custommap name="detailSpecular" fileId="{fid(sp)}"/>\n      <Custommap name="detailNormal" fileId="{fid(n)}"/>\n      <Custommap name="detailDiffuse" fileId="{fid(d)}"/>\n'
        stats['detail']+=1
        return re.sub(r'(\s*<CustomParameter|\s*</Material>)',lambda x:'\n'+add.rstrip('\n')+x.group(1),mat,count=1)
    s=re.sub(r'<Material .*?</Material>',fix,s,flags=re.S)
    files=''.join(f'    <File fileId="{i}" filename="{p}"/>\n' for p,i in added.items())
    return s.replace('</Files>',files+'  </Files>',1)

def l10n_keys(out):
    u=set()
    for d,_,fs in os.walk(out):
        for f in fs:
            if f.endswith('.xml') and f!='modDesc.xml': u|=set(re.findall(r'\$l10n_(\w+)',open(os.path.join(d,f),encoding='utf-8',errors='ignore').read()))
    return u

def write_moddesc(src,out,vehicle,title,brand,brand_img,icon):
    sm=open(f'{src}/modDesc.xml',encoding='utf-8-sig').read()
    l=sm[sm.find('<l10n>'):sm.find('</l10n>')]
    texts={m.group(1):m.group(0) for m in re.finditer(r'<text name="([^"]+)">.*?</text>',l,re.S)}
    GAME_HAS={'configuration_mudflaps','configuration_roof'}      # log: "Duplicate l10n entry ... Ignoring this definition"
    mine=[texts[k] for k in sorted(l10n_keys(out)) if k in texts and k not in GAME_HAS]
    md=f'''<?xml version="1.0" encoding="utf-8" standalone="no"?>
<modDesc descVersion="2" titleId="fs26mobile" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="https://validation.gdn.giants-software.com/xml/fs25/modDesc.xsd">
    <author>converted</author>
    <version>1.0.0.0</version>
    <title><en>{title}</en></title>
    <description><en>{title} (FS23 to FS26 mobile conversion)</en></description>
    <iconFilename>{icon}</iconFilename>
    <multiplayer supported="true"/>
    <storeItems>
        <storeItem xmlFilename="{vehicle}"/>
    </storeItems>
    <vehicleTypes>
        <type name="mtz" parent="tractor" className="Vehicle" filename="$dataS/scripts/vehicles/Vehicle.lua">
        </type>
    </vehicleTypes>
    <brands>
        <brand name="{brand}" title="{brand}" image="{brand_img}"/>
    </brands>
    <l10n>
{chr(10).join('        '+t.strip() for t in mine)}
    </l10n>
</modDesc>
'''
    ET.fromstring(md.encode()); open(f'{out}/modDesc.xml','w',encoding='utf-8',newline='').write(md)

def validate(out):
    probs=[]
    for d,_,fs in os.walk(out):
        for f in fs:
            p=os.path.join(d,f); rp=os.path.relpath(p,out)
            if f.endswith('.xml'):
                t=open(p,encoding='utf-8-sig',errors='ignore').read()
                try: ET.fromstring(t.encode())
                except Exception as e: probs.append((rp,'XML parse',str(e)[:60])); continue
                for r in set(refs_in_xml(t)):
                    if not r.startswith('$') and not os.path.exists(f'{out}/{r}'): probs.append((rp,'missing',r))
            if f.endswith('.i3d'):
                t=open(p,encoding='latin-1').read()
                for r in set(re.findall(r'<File [^>]*filename="([^"]+)"',t)):
                    if not r.startswith('$') and not os.path.exists(os.path.normpath(os.path.join(d,r))): probs.append((rp,'missing',r))
                for v in set(re.findall(r'customShaderVariation="([^"]*)"',t)):
                    if v in BAD_VARIATIONS: probs.append((rp,'BAD shader variation',v))
    return probs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--src',required=True); ap.add_argument('--vehicle',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--title',default='Converted vehicle'); ap.add_argument('--brand-name',default='NONE'); ap.add_argument('--brand-image',default='store/brand.png')
    ap.add_argument('--icon',default=None); ap.add_argument('--detail-maps',action='store_true')
    a=ap.parse_args(); shutil.rmtree(a.out,ignore_errors=True); os.makedirs(a.out)
    vxml=convert_vehicle_xml(a.src,a.vehicle); open(f'{a.out}/{a.vehicle}','w',encoding='utf-8',newline='').write(vxml)
    need=collect(a.src,a.vehicle,vxml)
    if a.brand_image and os.path.exists(f'{a.src}/{a.brand_image}'): need.add(a.brand_image)
    stats={'variations':0,'params':0,'colorScale':0,'morph':0,'detail':0}; tot=0
    for rel in sorted(need):
        if rel==a.vehicle: continue
        d=f'{a.out}/{rel}'; os.makedirs(os.path.dirname(d),exist_ok=True); sp=f'{a.src}/{rel}'
        if rel.endswith('.i3d'):
            t=open(sp,'rb').read().decode('latin-1'); open(d,'wb').write(patch_i3d_text(t,stats,a.detail_maps).encode('latin-1'))
        elif rel.endswith('.xml') and rel.startswith('wheels/') and re.search(r'<wheel[\s>]',open(sp,encoding='utf-8-sig').read()):
            t=open(sp,encoding='utf-8-sig').read(); t=re.sub(r'\s+isCareWheel="[^"]*"','',t)
            t=t.replace('<wheel>','<wheel xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="https://validation.gdn.giants-software.com/xml/fs25/wheel.xsd">',1)
            open(d,'w',encoding='utf-8',newline='').write(t)
        elif rel.startswith('sounds/') and rel.endswith('.xml'):
            t=open(sp,encoding='utf-8-sig').read(); t=re.sub(r'file="([^"]+)\.wav"',lambda m:f'file="{m[1]}.ogg"' if os.path.exists(f'{a.src}/{m[1]}.ogg') else m[0],t)
            open(d,'w',encoding='utf-8',newline='').write(t)
        else: shutil.copy(sp,d)
        tot+=os.path.getsize(d)
    say(f'copied {len(need)} files, {tot/1e6:.1f} MB; i3d stats: {stats}')
    icon=a.icon or next((f for f in need if f.startswith('store/') and f.lower().endswith('.png') and 'brand' not in f.lower()),'store/icon.png')
    write_moddesc(a.src,a.out,a.vehicle,a.title,a.brand_name,a.brand_image,icon)
    pr=validate(a.out); say(f'validation: {len(pr)} problem(s)'); [say('  '+' | '.join(x)) for x in pr]
    open(f'{a.out}/../conversion_log.txt','w').write('\n'.join(log)); return 1 if pr else 0
if __name__=='__main__': sys.exit(main())
