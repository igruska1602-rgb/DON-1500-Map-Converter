import os,re,sys
from xml.dom import minidom
def check(root):
    root=os.path.abspath(root); problems=[]; low={}
    for d,_,fs in os.walk(root):
        for f in fs: low[os.path.relpath(os.path.join(d,f),root).lower()]=1
    def exists(rel): return os.path.exists(os.path.join(root,rel))
    for d,_,fs in os.walk(root):
        for f in fs:
            p=os.path.join(d,f); rp=os.path.relpath(p,root)
            if f.endswith('.xml'):
                s=open(p,encoding='utf-8-sig',errors='ignore').read()
                try: minidom.parseString(s.encode('utf-8'))
                except Exception as e: problems.append((rp,'XML parse',str(e)[:80])); continue
                refs=re.findall(r'(?:filename|xmlFilename|file|image|iconFilename|config\w*Filename)="([^"$][^"]*)"',s)
                refs+=re.findall(r'<(?:filename|image)>([^<$]+)</',s)
                for r in set(refs):
                    r=r.strip()
                    if r.startswith(('$','http')) or '.' not in os.path.basename(r): continue
                    if not exists(r): problems.append((rp,'missing',r))
                    elif r!=os.path.normpath(r) and False: pass
            if f.endswith('.i3d'):
                s=open(p,encoding='latin-1').read()
                base=os.path.dirname(p)
                for r in set(re.findall(r'<File [^>]*filename="([^"]+)"',s)+re.findall(r'externalShapesFile="([^"]+)"',s)):
                    if r.startswith('$'): continue
                    if not os.path.exists(os.path.normpath(os.path.join(base,r))): problems.append((rp,'missing',r))
                m=re.search(r'<Shape [^>]*externalShapesFile',s)
                if 'externalShapesFile' not in s and os.path.exists(p+'.shapes')==False and '<Shapes' in s: pass
    return problems
if __name__=='__main__':
    pr=check(sys.argv[1]); print(len(pr),'problems')
    for x in pr: print(*x,sep=' | ')
