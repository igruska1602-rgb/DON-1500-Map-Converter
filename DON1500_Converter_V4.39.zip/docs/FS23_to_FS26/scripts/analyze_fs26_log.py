#!/usr/bin/env python3
"""Quick triage of a FS26 Mobile log.txt for ONE mod.   usage: analyze_fs26_log.py log.txt <ModFolderName>
Prints: engine/device, whether the mod loaded, mod-related errors/warnings (deduplicated), shader/i3d failures and
whether the log simply STOPS (= native crash) right after loading the mod's textures."""
import re,sys,collections
log=open(sys.argv[1],encoding='utf-8',errors='ignore').read().splitlines(); mod=sys.argv[2]
ts=re.compile(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+ ')
BENIGN=[r'Warning \(performance\)',r'CPU mip generation',r"Failed to open xml file 'data/effects",r"i3d\s+'data/effects",r"Invalid gs2d file",
        r"is not referenced in variation",r"creationBox\.i3d",r"Failed to find child 1 from node",r"Index not found: (0>2\|1|doorLeft|windowBack)",
        r"Static lights not using",r"Old shape file format",r"Suspension nodes are not allowed",r"Duplicate l10n entry"]   # seen in logs of working mods / base game
def benign(l): return any(re.search(b,l) for b in BENIGN)
print('== engine:',next((l for l in log if 'GIANTS Engine' in l),'?').strip()); print('== device:',' | '.join(l.strip() for l in log[:14] if re.search('CPU:|Memory:|OS:|Device:',l)))
print('== mod listed:',[l for l in log if l.startswith('Available mod') and mod in l][:1]); print('== "Load mod":',any('Load mod: '+mod in l for l in log))
mine=[l for l in log if mod in l and not benign(l)]; c=collections.Counter(ts.sub('',re.sub(r'/storage/\S*/mods/','',l)).strip()[:200] for l in mine)
print(f'== mod-related non-benign lines: {len(mine)} (unique {len(c)})'); [print('  ',n,'x',t) for t,n in c.most_common(25)]
fatal=[l for l in log if re.search(r"Can't load resource|could not be found|not found|Failed to load|Segmentation|SIGSEGV|Fatal|backtrace",l) and not benign(l) and not re.search(r'data/effects|creationBox',l)]
print('== suspicious (non-benign) lines:'); [print('  ',ts.sub('',l)[:220]) for l in fatal[:20]]
i3d_done=[l for l in log if mod in l and re.search(r'\.i3d \(\d+\.\d+ ms\)',l)]; print('== mod i3d files that finished loading:',len(i3d_done)); [print('  ',re.sub(r'.*/mods/','',l)[:120]) for l in i3d_done[:12]]
last=[l for l in log if not re.search(r'Warning \(performance\)|CPU mip',l)][-3:]; print('== last meaningful lines:'); [print('  ',ts.sub('',l)[:220]) for l in last]
tail=log[-1]; print('== log ends inside texture loading (probable native crash):',bool(re.search(r'Texture|mip generation',tail)))
