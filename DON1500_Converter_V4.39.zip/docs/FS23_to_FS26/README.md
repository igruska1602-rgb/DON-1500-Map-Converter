# FS23 → FS26 mobile: пакет знань для проєкту-конвертора

Що тут:
| Файл/папка | Призначення |
|---|---|
| `PROMPT_FOR_CONVERTER_PROJECT.md` | готовий промпт для проєкту-конвертора |
| `docs/CONVERSION_REPORT.md` | **повний звіт**: усі кроки, лог-докази, діагнози, гіпотези, стан, наступні експерименти |
| `docs/RULES_FS23_to_FS26.md` | таблиця правил (що на що міняти) зі статусами ✔/◐/? і гайд по логах |
| `scripts/fs23_to_fs26_convert.py` | конвертор одного транспорту (відтворює збірку test 2; `--detail-maps` = експеримент test 3) |
| `scripts/analyze_fs26_log.py` | розбір log.txt: фатальне vs шум, чи є краш |
| `evidence/` | витяги логу, diff `mtz82.xml` FS23↔FS26, матеріали до/після, звіти старого автоконвертера, факти про робочий FS26-мод |

Швидкий старт:
```
python3 scripts/fs23_to_fs26_convert.py --src <розпакований FS23 мод> --vehicle mtz82.xml --out out/FS26_MTZ82 \
        --title "MTZ-82" --brand-name BELARUS --brand-image store/brandBF.png --icon store/storeMTZ82.png [--detail-maps]
python3 scripts/analyze_fs26_log.py log.txt FS26_MTZ82
```
Папку `out/<Назва>` заархівувати у zip (корінь zip = вміст мода; ім'я zip = ім'я мода в грі).

Стан на 18.11.2026: МТЗ-82 з'являється в магазині і купується (test 2), але **без текстур** — див. звіт, розділ 6–8.
Структура перевірена скриптами; поведінка в грі відома лише з вашого логу.
