# Правила конвертації FS23 mobile → FS26 mobile (база знань конвертора)
Статус: **✔ перевірено грою/логом** · **◐ за зразком FS26, у грі не перевірено** · **? гіпотеза**

## A. modDesc.xml
| FS23 | FS26 mobile | Статус |
|---|---|---|
| `descVersion="75"` | `descVersion="2"` + `titleId="fs26mobile"`, схема `.../fs25/modDesc.xsd` | ◐ (мод завантажується ✔) |
| `<knw>`, `<extraSourceFiles>`, `<specializations>`, `<newcategory>`, скрипти | не використовуються (у зразку нема) | ◐ |
| Переклади `$l10n_*` | лише ті, що використані; `configuration_mudflaps`, `configuration_roof` НЕ дублювати (гра вже має: «Duplicate l10n entry») | ✔ |
| `<vehicleTypes>` | `type name=.. parent="tractor" className="Vehicle" filename="$dataS/scripts/vehicles/Vehicle.lua"` без `moreDesignConfigs` | ◐ |
| дубль `<version>` | один | ✔ |

## B. vehicle xml
| FS23 | FS26 | Статус |
|---|---|---|
| `<category>mtz</category>` (власна) | валідна: `tractorsS` (для знарядь у зразку `mtz` дає «Invalid category», потрібна валідна) | ✔/◐ |
| `<simpleIC>` | видалити; заміна — `interactiveControl` (потрібні clickPoint-вузли в i3d) | ◐ |
| `<baseMaterial>` з `shaderParameter colorMatN` | видалити | ◐ |
| `baseMaterialConfigurations/baseMaterialConfiguration` | `baseColorConfigurations/baseColorConfiguration` | ◐ |
| `designMaterial{N}Configurations` | `designColor{N}Configurations` | ◐ |
| `color="r g b m"` | `color="r g b" material="m"` | ◐ |
| `rimColorConfiguration color="r g b m"` | лише `r g b` (+`material`) — інакше «Invalid rgb color» | ✔ |
| `$l10n_Gray/Blue/...` | `$l10n_ui_colorGrey/Blue/...` (набір у зразку: Black Blue Green Grey Orange Red Silver White) | ◐ |
| `<audioMemoryUsage>` | видалити | ◐ |
| «зламані» коментарі `<!-->..<!--` | видалити (інакше XML не парситься) | ✔ |
| зайвий закриваючий тег | прибрати (`validate`) | ✔ |
| `design9..49`, `designMaterial4..49` (давав скрипт) | у зразку `designN/designColorN` працюють без скрипта | ◐ |

## C. wheels/*.xml
`isCareWheel` — видалити; додати `xmlns:xsi` + `xsi:noNamespaceSchemaLocation=".../fs25/wheel.xsd"`. ◐

## D. i3d (КЛЮЧОВЕ)
| FS23 | FS26 | Статус |
|---|---|---|
| `customShaderVariation="colorMask"` | **такої вариації нема → краш**; прибрати | ✔ (вилет усунуто) |
| `Decal`, `uvScroll`, `windBend` | прибрати (у FS26 є лише: `staticLight`, `staticLight_vertex`, `uvTransform`, `vmaskUV2`, `tirePressureDeformation`, `additive_colorScale`) | ✔ |
| `staticLight`, `tirePressureDeformation` | залишити | ✔ |
| `colorMat0–7`, `RDT`, `offsetUV`, `directionBend`, `prevDirectionBend`, `blinkOffset` | видалити | ◐ |
| `morphPosition` | `morphPos` (4 числа, формат той самий); `prevMorphPosition` видалити | ◐ |
| колір лише з маски (нема `<Texture>`) | `colorScale` (3 числа) — груба заміна з `colorMat0` | ? |
| **нема деталь-мап** | кожен базовий матеріал: `Custommap detailSpecular/detailNormal/detailDiffuse` з `$data/shared/detailLibrary/...` (365/365 у зразку) | ? (причина «без текстур»; експеримент `--detail-maps`) |
| шляхи `shared\x.png` | `shared/x.png` | ✔ |
| `Glossmap` (specular FS23) | у FS26 — `vmask`; розкладка каналів може відрізнятись | ? |
Типові трійки деталь-мап (з робочого зразка): лакований метал `nonMetallic/metal/metalPaintedOld_*` + `flat_normal`; хром `metallic/clear_*`; гума `nonMetallic/rubber/rubberBlack_diffuse`, `rubber_normal`, `rubber_specular`; пластик `nonMetallic/plastic/plasticPainted_*`.

## E. Звук
FS23 `sounds/*.xml` посилається на `.wav`, файли — `.ogg`. Переписуємо на існуючий `.ogg` ✔ (у зразку `.wav` давало «missing»). Шаблони `DEFAULT_MOTOR_*` FS23 і `motorConfigurations` FS26 — **різні**; звук МТЗ-82 не конвертувався ?.

## F. Обмеження мобільної платформи (з логу робочого зразка)
* `Suspension nodes are not allowed on this platform` — вузли підвіски ігноруються (попередження).
* Текстури PNG працюють, але «raw format / CPU mip generation» — лише продуктивність; для оптимізації — DDS з мипмапами.
* Файлів `data/effects/*` та частини `data/*` у мобільній грі нема (багато «Failed to open xml file data/effects…» у базовій грі) — **ігнорувати**, не наша помилка.

## G. Як читати log.txt (скрипт `analyze_fs26_log.py`)
**Фатальне/важливе:** `Can't load resource` (шейдер/вариація); лог обривається посеред текстур без `i3d (NN ms)` для нашого моду; `Error:` з шляхом нашого моду; `Index not found: 0>…` (хибний шлях вузла).
**Не страшне (шум):** `Warning (performance) … raw format`, `CPU mip generation`, `data/effects/* … not found`, `Static lights not using 'lightControl'`, `Old shape file format`, `Suspension nodes are not allowed`, `custommap … not referenced in variation "base"` для `shop*_mat` (базова гра), `creationBox.i3d`.
