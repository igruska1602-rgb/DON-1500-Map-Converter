package com.don1500.converter;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Контейнер GS2D (.ast) FS26 Mobile: 52-байтний заголовок + ASTC 6x6 блоки, мипи від найменшого до найбільшого,
 * кожен рівень записаний віддзеркаленим по вертикалі. Структура виведена з реальних файлів гри (див. AST_NOTES.md).
 */
public final class Gs2d {
    private Gs2d() {}

    public static final class Img {
        public final int w, h; public final int[] px;
        public Img(int w, int h, int[] px) { this.w = w; this.h = h; this.px = px; }
    }
    public interface Progress { void on(float f); }

    private static final int HDR = 52;
    // порядок блоків ASTC: код формату = 0x1E + індекс (підтверджено лише для 6x6 = 0x22)
    private static final int[][] FOOT = {{4,4},{5,4},{5,5},{6,5},{6,6},{8,5},{8,6},{8,8},{10,5},{10,6},{10,8},{10,10},{12,10},{12,12}};

    private static int le32(byte[] b, int o) { return (b[o] & 255) | ((b[o+1] & 255) << 8) | ((b[o+2] & 255) << 16) | ((b[o+3] & 255) << 24); }
    private static void put32(byte[] b, int o, int v) { b[o] = (byte) v; b[o+1] = (byte) (v >> 8); b[o+2] = (byte) (v >> 16); b[o+3] = (byte) (v >>> 24); }

    private static int[][] levelDims(int w, int h, int levels) {
        int[][] r = new int[levels][2];
        for (int i = 0; i < levels; i++) { r[i][0] = w; r[i][1] = h; w = Math.max(1, w / 2); h = Math.max(1, h / 2); }
        return r;
    }

    /** null = файл підтримується, інакше текст причини. */
    public static String probe(byte[] f) {
        try { parse(f); return null; } catch (IllegalArgumentException e) { return e.getMessage(); }
    }

    private static final class Info { int w, h, levels, bw, bh; int[][] dims; long[] off; }

    private static Info parse(byte[] f) {
        if (f.length < HDR || f[0] != 'G' || f[1] != 'S' || f[2] != '2' || f[3] != 'D') throw new IllegalArgumentException("не GS2D (.ast) файл");
        int ver = le32(f, 4);
        if (ver != 8) throw new IllegalArgumentException("версія GS2D " + ver + " не підтримується (потрібна 8)");
        Info in = new Info();
        in.w = le32(f, 8); in.h = le32(f, 12);
        if (in.w <= 0 || in.h <= 0 || (long) in.w * in.h > 8192L * 8192L) throw new IllegalArgumentException("некоректний розмір " + in.w + "x" + in.h);
        int fmt = f[0x2c] & 255;
        int idx = fmt - 0x1E;
        if (idx < 0 || idx >= FOOT.length) throw new IllegalArgumentException("невідомий код формату 0x" + Integer.toHexString(fmt));
        in.bw = FOOT[idx][0]; in.bh = FOOT[idx][1];
        in.levels = (f[0x15] & 255) + 1;
        in.dims = levelDims(in.w, in.h, in.levels);
        long total = HDR;
        long[] sizes = new long[in.levels];
        for (int i = 0; i < in.levels; i++) sizes[i] = (long) ((in.dims[i][0] + in.bw - 1) / in.bw) * ((in.dims[i][1] + in.bh - 1) / in.bh) * 16;
        for (long s : sizes) total += s;
        if (total != f.length) throw new IllegalArgumentException("незнайомий розклад файлу (розмір " + f.length + " ≠ очікуваних " + total + ") — потрібен зразок такого .ast");
        in.off = new long[in.levels];
        long o = HDR;
        for (int i = in.levels - 1; i >= 0; i--) { in.off[i] = o; o += sizes[i]; } // найменший рівень іде першим
        return in;
    }

    /** Декодує найбільший рівень, не більший за maxDim (0 = найбільший). */
    public static Img decode(byte[] f, int maxDim) {
        final Info in = parse(f);
        int lv = 0;
        if (maxDim > 0) while (lv < in.levels - 1 && Math.max(in.dims[lv][0], in.dims[lv][1]) > maxDim) lv++;
        final int w = in.dims[lv][0], h = in.dims[lv][1];
        final int bx = (w + in.bw - 1) / in.bw, by = (h + in.bh - 1) / in.bh;
        final int[] px = new int[w * h];
        final long base = in.off[lv];
        final int bw = in.bw, bh = in.bh;
        final AtomicInteger next = new AtomicInteger();
        Runnable job = () -> {
            int[] blk = new int[bw * bh];
            int j;
            while ((j = next.getAndIncrement()) < by) {
                for (int i = 0; i < bx; i++) {
                    Astc.decodeBlock(f, (int) (base + ((long) j * bx + i) * 16), bw, bh, blk);
                    for (int y = 0; y < bh; y++) {
                        int py = j * bh + y; if (py >= h) break;
                        int row = (h - 1 - py) * w; // віддзеркалення по вертикалі
                        for (int x = 0; x < bw; x++) { int pxx = i * bw + x; if (pxx >= w) break; px[row + pxx] = blk[y * bw + x]; }
                    }
                }
            }
        };
        runParallel(job);
        return new Img(w, h, px);
    }

    private static void runParallel(Runnable job) {
        int n = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
        Thread[] ts = new Thread[n];
        for (int i = 0; i < n; i++) { ts[i] = new Thread(job); ts[i].start(); }
        for (Thread t : ts) { try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    }

    private static int[] half(int[] p, int w, int h, int nw, int nh) {
        int[] o = new int[nw * nh];
        for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
            int a = 0, r = 0, g = 0, b = 0;
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) {
                int v = p[Math.min(h - 1, y * 2 + dy) * w + Math.min(w - 1, x * 2 + dx)];
                a += v >>> 24; r += (v >> 16) & 255; g += (v >> 8) & 255; b += v & 255;
            }
            o[y * nw + x] = (((a + 2) / 4) << 24) | (((r + 2) / 4) << 16) | (((g + 2) / 4) << 8) | ((b + 2) / 4);
        }
        return o;
    }

    /** ARGB → .ast (ASTC 6x6, повний ланцюжок мипів). */
    public static byte[] encode(int[] argb, int w, int h, Progress pr) {
        List<int[]> lv = new ArrayList<>(); List<int[]> dm = new ArrayList<>();
        int[] cur = argb; int cw = w, ch = h;
        lv.add(cur); dm.add(new int[]{cw, ch});
        while (cw > 1 || ch > 1) {
            int nw = Math.max(1, cw / 2), nh = Math.max(1, ch / 2);
            cur = half(cur, cw, ch, nw, nh); cw = nw; ch = nh;
            lv.add(cur); dm.add(new int[]{cw, ch});
        }
        int n = lv.size();
        long[] sz = new long[n]; long total = HDR;
        for (int i = 0; i < n; i++) { sz[i] = (long) ((dm.get(i)[0] + 5) / 6) * ((dm.get(i)[1] + 5) / 6) * 16; total += sz[i]; }
        if (total > Integer.MAX_VALUE - 16) throw new IllegalArgumentException("текстура завелика");
        final byte[] out = new byte[(int) total];
        long blocksAll = (total - HDR) / 16; final AtomicInteger done = new AtomicInteger();
        long o = HDR;
        for (int i = n - 1; i >= 0; i--) { // від найменшого
            final int[] px = lv.get(i); final int lw = dm.get(i)[0], lh = dm.get(i)[1];
            final int bx = (lw + 5) / 6, by = (lh + 5) / 6; final int base = (int) o;
            final AtomicInteger next = new AtomicInteger();
            final long ba = blocksAll;
            Runnable job = () -> {
                Astc.Encoder enc = new Astc.Encoder(); int[] blk = new int[36];
                int j;
                while ((j = next.getAndIncrement()) < by) {
                    for (int bi = 0; bi < bx; bi++) {
                        for (int y = 0; y < 6; y++) {
                            int py = Math.min(lh - 1, j * 6 + y);
                            int srow = (lh - 1 - py) * lw; // віддзеркалення
                            for (int x = 0; x < 6; x++) blk[y * 6 + x] = px[srow + Math.min(lw - 1, bi * 6 + x)];
                        }
                        enc.encode(blk, out, base + (j * bx + bi) * 16);
                    }
                    int d = done.addAndGet(bx);
                    if (pr != null) pr.on(Math.min(1f, d / (float) ba));
                }
            };
            runParallel(job);
            o += sz[i];
        }
        put32(out, 0, 0x44325347); put32(out, 4, 8); put32(out, 8, w); put32(out, 12, h); put32(out, 16, 1);
        if (n == 1) { out[0x14] = 4; out[0x15] = 0; } else { out[0x14] = 3; out[0x15] = (byte) (n - 1); }
        out[0x16] = 1; out[0x17] = 0; put32(out, 0x18, 4);
        try {
            MessageDigest md = MessageDigest.getInstance("MD5"); md.update(out, HDR, out.length - HDR);
            System.arraycopy(md.digest(), 0, out, 0x1c, 16);
        } catch (Exception e) { throw new RuntimeException(e); }
        out[0x2c] = 0x22; out[0x2d] = 0; out[0x2e] = 1; out[0x2f] = 1; out[0x30] = 0; out[0x31] = 0; out[0x32] = 0; out[0x33] = 8;
        return out;
    }
}
